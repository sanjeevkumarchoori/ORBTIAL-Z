export type OrbitClass = 'LEO' | 'MEO' | 'GEO' | 'POLAR' | 'HEO';

export type AssetType = 'OPERATIONAL' | 'INACTIVE' | 'DEBRIS' | 'CONJUNCTION_TARGET';

export interface OrbitalAsset {
  id: string;
  name: string;
  noradId: number;
  type: AssetType;
  orbitClass: OrbitClass;
  altitudeKm: number;
  inclinationDeg: number;
  periodMinutes: number;
  velocityKms: number;
  eccentricity: number;
  raanDeg: number; // Right Ascension of Ascending Node
  argPerigeeDeg: number;
  meanAnomalyDeg: number;
  trueAnomalyDeg?: number;
  color: string;
  size: number;
  operator?: string;
  country?: string;
  launchDate?: string;
}

export interface GeodeticCoords {
  latitude: number;
  longitude: number;
  altitudeKm: number;
}

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface ConjunctionEvent {
  id: string;
  primaryAsset: OrbitalAsset;
  secondaryAsset: OrbitalAsset;
  tcaUtc: string; // Time of Closest Approach
  secondsToTca: number;
  missDistanceMeters: number;
  collisionProbabilityPc: number; // e.g. 1.84e-3
  relativeSpeedKms: number;
  mahalanobisDistance: number;
  enclaveStatus: 'COMPUTING' | 'RESOLVED_OPTIMAL' | 'MANEUVER_DISPATCHED';
  microThrustVectorDeltaV: Vector3D; // mm/s
  zkProofHash: string;
  enclaveSignature: string;
  enclaveHardware: string;
  merkleRoot: string;
}

export interface GroundStation {
  id: string;
  name: string;
  lat: number;
  lon: number;
  country: string;
  frequency: string;
  elevationM: number;
  opticalUplinkActive: boolean;
}

export interface CdmData {
  messageId: string;
  originator: string;
  creationDate: string;
  tca: string;
  missDistanceM: number;
  relativeSpeedKms: number;
  collisionProbability: number;
  primaryObject: {
    name: string;
    catalogId: number;
    semiMajorAxisKm: number;
    eccentricity: number;
    inclinationDeg: number;
    sigmaR: number; // Covariance 1-sigma radial (m)
    sigmaT: number; // In-track (m)
    sigmaN: number; // Cross-track (m)
  };
  secondaryObject: {
    name: string;
    catalogId: number;
    semiMajorAxisKm: number;
    eccentricity: number;
    inclinationDeg: number;
    sigmaR: number;
    sigmaT: number;
    sigmaN: number;
  };
}

export interface EnclaveAttestation {
  enclaveId: string;
  platform: string;
  cpuArchitecture: string;
  hardwareSecurityModule: string;
  cpacfStatus: string;
  firmwareHash: string;
  zeroKnowledgeCircuit: string;
  publicInputsDigest: string;
  proofSnark: {
    pi_a: [string, string];
    pi_b: [[string, string], [string, string]];
    pi_c: [string, string];
  };
  merklePath: string[];
  executionTimeMs: number;
  ephemerisLeakageBytes: 0;
  pcrRegisters: Record<string, string>;
  postQuantum: {
    mlKem1024Ciphertext: string;
    mlDsa87Signature: string;
    algorithmStatus: string;
  };
  mpcFlow: {
    operatorA: {
      name: string;
      role: string;
      classification: string;
      encryptedPayloadSize: string;
      secretsProtected: string[];
    };
    operatorB: {
      name: string;
      role: string;
      classification: string;
      encryptedPayloadSize: string;
      secretsProtected: string[];
    };
    enclaveComputation: {
      enclaveType: string;
      clearanceThresholdMeters: number;
      optimalDeltaVVector: { r: number; t: number; n: number };
      secondaryConjunctionsRisk: string;
    };
  };
}

export interface BPlanePoint {
  bDotT: number; // In-track / transversal axis (m)
  bDotR: number; // Radial axis (m)
}

export interface CovarianceEllipseParams {
  semiMajorM: number;
  semiMinorM: number;
  orientationDeg: number;
  sigma: 1 | 2 | 3;
}

export interface ManeuverSimulationResult {
  deltaVMs: number;
  direction: 'PROGRADE' | 'RETROGRADE' | 'RADIAL_OUT' | 'RADIAL_IN' | 'OPTIMAL_ENCLAVE';
  leadTimeHours: number;
  initialMissDistanceM: number;
  postMissDistanceM: number;
  initialPc: number;
  postPc: number;
  fuelMassKg: number;
  secondaryConjunctions72h: number;
  safetyMarginMeters: number;
  isEnclaveVerified: boolean;
}
