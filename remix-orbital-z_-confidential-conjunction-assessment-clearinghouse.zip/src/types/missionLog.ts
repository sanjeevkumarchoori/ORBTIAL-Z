export type LogCategory = 'CONJUNCTION' | 'ENCLAVE' | 'SCREENING';

export type LogSeverity = 'CRITICAL' | 'WARNING' | 'NOMINAL' | 'INFO';

export interface MissionLogDetails {
  primaryAsset?: string;
  secondaryAsset?: string;
  missDistanceM?: number;
  timeToClosestApproach?: string;
  collisionProbabilityPc?: number;
  microThrustDeltaV?: string;
  zkProofHash?: string;
  enclaveHardware?: string;
  cpacfInstructionCycles?: string;
  assetsScreenedCount?: number;
  executionDurationMs?: number;
  merkleRoot?: string;
  rawPayloadSignature?: string;
}

export interface MissionLogEntry {
  id: string;
  timestamp: string; // ISO UTC string
  category: LogCategory;
  severity: LogSeverity;
  title: string;
  summary: string;
  details?: MissionLogDetails;
}

export type LogFilterCategory = 'ALL' | LogCategory;
