import React, { useState } from 'react';
import {
  X,
  FileSpreadsheet,
  Shield,
  AlertTriangle,
  Cpu,
  Search,
  Filter,
  ChevronDown,
  ChevronUp,
  Download,
  Play,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { MissionLogEntry, LogFilterCategory, LogCategory } from '../../types/missionLog';

interface MissionLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: MissionLogEntry[];
  onTriggerScreening: () => void;
}

export const MissionLogModal: React.FC<MissionLogModalProps> = ({
  isOpen,
  onClose,
  logs,
  onTriggerScreening,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<LogFilterCategory>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedLogIds, setExpandedLogIds] = useState<Record<string, boolean>>({
    'log-001': true, // Auto-expand most critical recent log
  });

  if (!isOpen) return null;

  const toggleExpand = (id: string) => {
    setExpandedLogIds((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const filteredLogs = logs.filter((log) => {
    const matchesCat = selectedCategory === 'ALL' || log.category === selectedCategory;
    const query = searchQuery.toLowerCase();
    const matchesSearch =
      log.title.toLowerCase().includes(query) ||
      log.summary.toLowerCase().includes(query) ||
      (log.details?.primaryAsset && log.details.primaryAsset.toLowerCase().includes(query)) ||
      (log.details?.secondaryAsset && log.details.secondaryAsset.toLowerCase().includes(query)) ||
      (log.details?.zkProofHash && log.details.zkProofHash.toLowerCase().includes(query));
    return matchesCat && matchesSearch;
  });

  const getCategoryCount = (cat: LogFilterCategory) => {
    if (cat === 'ALL') return logs.length;
    return logs.filter((l) => l.category === cat).length;
  };

  const exportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `orbital_z_mission_log_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const getCategoryIcon = (category: LogCategory) => {
    switch (category) {
      case 'CONJUNCTION':
        return <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />;
      case 'ENCLAVE':
        return <Cpu className="w-3.5 h-3.5 text-purple-400" />;
      case 'SCREENING':
        return <Shield className="w-3.5 h-3.5 text-cyan-400" />;
    }
  };

  const getSeverityStyle = (severity: string) => {
    switch (severity) {
      case 'CRITICAL':
        return 'text-rose-400 border-rose-500/40 bg-rose-950/30';
      case 'WARNING':
        return 'text-amber-400 border-amber-500/40 bg-amber-950/30';
      case 'NOMINAL':
        return 'text-emerald-400 border-emerald-500/30 bg-emerald-950/20';
      default:
        return 'text-cyan-400 border-cyan-500/30 bg-cyan-950/20';
    }
  };

  const formatUtcTime = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
    } catch {
      return isoString;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-xl border border-white/15 bg-[#08090d] shadow-2xl overflow-hidden font-mono text-xs">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-[#030305]">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-8 h-8 rounded border border-cyan-500/40 bg-cyan-950/30 text-cyan-400">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-tight">
                MISSION AUDIT & ENCLAVE LOG
              </div>
              <div className="text-[11px] text-slate-400">
                Immutable records of conjunction alerts, hardware enclave state, and autonomous sweeps
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={exportJson}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Download Full Mission Log JSON"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span>Export JSON</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Action & Filter Toolbar */}
        <div className="p-4 border-b border-white/10 bg-white/[0.01] space-y-3">
          {/* Top Row: Search and Run Screening Action */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search event title, asset name, proof hash, or keyword..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded bg-black/50 border border-white/15 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/50"
              />
            </div>

            <button
              onClick={onTriggerScreening}
              className="flex items-center justify-center gap-2 px-3.5 py-1.5 rounded bg-violet-600 hover:bg-violet-500 text-white font-semibold shadow-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Trigger Enclave Sweep</span>
            </button>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
            <Filter className="w-3 h-3 text-slate-500 mr-1 shrink-0" />
            {[
              { id: 'ALL', label: 'All Logs' },
              { id: 'CONJUNCTION', label: 'Conjunction Events' },
              { id: 'ENCLAVE', label: 'Hardware Enclave' },
              { id: 'SCREENING', label: 'Autonomous Screening' },
            ].map((tab) => {
              const isSelected = selectedCategory === tab.id;
              const count = getCategoryCount(tab.id as LogFilterCategory);
              return (
                <button
                  key={tab.id}
                  onClick={() => setSelectedCategory(tab.id as LogFilterCategory)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors whitespace-nowrap cursor-pointer ${
                    isSelected
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'bg-white/[0.03] text-slate-400 hover:text-white border border-transparent hover:border-white/10'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/[0.08] text-slate-300 tabular-nums">
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Scrollable Log Entries List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {filteredLogs.map((log) => {
            const isExpanded = !!expandedLogIds[log.id];
            return (
              <div
                key={log.id}
                className="rounded-lg border border-white/10 bg-white/[0.02] hover:bg-white/[0.03] transition-colors overflow-hidden"
              >
                {/* Clickable Summary Row */}
                <div
                  onClick={() => toggleExpand(log.id)}
                  className="flex items-start justify-between gap-3 p-3.5 cursor-pointer"
                >
                  <div className="flex items-start gap-2.5 flex-1 min-w-0">
                    <div className="pt-0.5 shrink-0">{getCategoryIcon(log.category)}</div>

                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-white font-semibold text-xs truncate">
                          {log.title}
                        </span>

                        <span
                          className={`px-1.5 py-0.5 text-[10px] rounded border font-medium uppercase ${getSeverityStyle(
                            log.severity
                          )}`}
                        >
                          {log.severity}
                        </span>
                      </div>

                      <p className="text-slate-400 text-[11px] leading-relaxed line-clamp-2">
                        {log.summary}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 text-[11px] text-slate-400">
                    <span className="tabular-nums hidden sm:inline">
                      {formatUtcTime(log.timestamp)}
                    </span>
                    <button className="text-slate-400 hover:text-white transition-colors">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Expanded Details Accordion */}
                {isExpanded && log.details && (
                  <div className="px-4 pb-3.5 pt-1 border-t border-white/5 bg-black/40 text-[11px] space-y-2">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                      {log.details.primaryAsset && (
                        <div>
                          <span className="text-slate-500 uppercase">Primary Asset:</span>
                          <div className="text-slate-200 font-medium">
                            {log.details.primaryAsset}
                          </div>
                        </div>
                      )}

                      {log.details.secondaryAsset && (
                        <div>
                          <span className="text-slate-500 uppercase">Secondary Asset:</span>
                          <div className="text-slate-200 font-medium">
                            {log.details.secondaryAsset}
                          </div>
                        </div>
                      )}

                      {log.details.missDistanceM !== undefined && (
                        <div>
                          <span className="text-slate-500 uppercase">Miss Distance:</span>
                          <div className="text-rose-400 font-bold tabular-nums">
                            {log.details.missDistanceM} meters
                          </div>
                        </div>
                      )}

                      {log.details.timeToClosestApproach && (
                        <div>
                          <span className="text-slate-500 uppercase">TCA Window:</span>
                          <div className="text-amber-300 font-bold tabular-nums">
                            {log.details.timeToClosestApproach}
                          </div>
                        </div>
                      )}

                      {log.details.collisionProbabilityPc !== undefined && (
                        <div>
                          <span className="text-slate-500 uppercase">Collision Prob (Pc):</span>
                          <div className="text-amber-300 font-bold tabular-nums">
                            {log.details.collisionProbabilityPc.toExponential(3)}
                          </div>
                        </div>
                      )}

                      {log.details.microThrustDeltaV && (
                        <div>
                          <span className="text-slate-500 uppercase">Micro-Thrust Vector:</span>
                          <div className="text-purple-300 font-bold">
                            {log.details.microThrustDeltaV}
                          </div>
                        </div>
                      )}

                      {log.details.assetsScreenedCount !== undefined && (
                        <div>
                          <span className="text-slate-500 uppercase">Objects Screened:</span>
                          <div className="text-cyan-300 font-bold tabular-nums">
                            {log.details.assetsScreenedCount.toLocaleString()} assets
                          </div>
                        </div>
                      )}

                      {log.details.executionDurationMs !== undefined && (
                        <div>
                          <span className="text-slate-500 uppercase">Enclave Duration:</span>
                          <div className="text-slate-300 tabular-nums">
                            {log.details.executionDurationMs} ms
                          </div>
                        </div>
                      )}

                      {log.details.cpacfInstructionCycles && (
                        <div>
                          <span className="text-slate-500 uppercase">CPACF CPU Cycles:</span>
                          <div className="text-slate-300">
                            {log.details.cpacfInstructionCycles}
                          </div>
                        </div>
                      )}

                      {log.details.enclaveHardware && (
                        <div>
                          <span className="text-slate-500 uppercase">Hardware Engine:</span>
                          <div className="text-purple-300">
                            {log.details.enclaveHardware}
                          </div>
                        </div>
                      )}
                    </div>

                    {log.details.zkProofHash && (
                      <div className="pt-1.5 border-t border-white/5">
                        <span className="text-slate-500 uppercase">zk-SNARK Attestation Hash:</span>
                        <div className="text-violet-400 font-mono text-[10px] break-all select-all">
                          {log.details.zkProofHash}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {filteredLogs.length === 0 && (
            <div className="p-8 text-center text-slate-500 text-xs">
              No mission log entries match your filter or search query.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-white/10 bg-[#030305] text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Enclave Integrity: Continuous Hardware Audit Active</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="tabular-nums">Showing {filteredLogs.length} of {logs.length} logs</span>
            <button
              onClick={onClose}
              className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
