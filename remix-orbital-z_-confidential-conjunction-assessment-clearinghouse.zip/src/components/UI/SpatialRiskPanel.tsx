import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { X, Flame, AlertOctagon, TrendingUp, Compass, Layers } from 'lucide-react';
import { CORRIDORS, ConjunctionCorridor } from '../Earth3D/SpatialRiskHeatmap';

interface SpatialRiskPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCorridor: (corridor: ConjunctionCorridor) => void;
}

interface DensityPoint {
  altitude: number;
  density: number; // 0 to 100
  label?: string;
}

export const SpatialRiskPanel: React.FC<SpatialRiskPanelProps> = ({
  isOpen,
  onClose,
  onSelectCorridor,
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [hoveredPoint, setHoveredPoint] = useState<DensityPoint | null>(null);

  // Generate continuous altitude density profile
  const data: DensityPoint[] = [];
  for (let alt = 300; alt <= 1400; alt += 10) {
    // Peak 1: 530km mega-constellation peak
    const peak1 = 92 * Math.exp(-Math.pow(alt - 530, 2) / (2 * 45 * 45));
    // Peak 2: 790km Cosmos debris peak
    const peak2 = 88 * Math.exp(-Math.pow(alt - 790, 2) / (2 * 50 * 50));
    // Peak 3: 860km Fengyun fragment peak
    const peak3 = 75 * Math.exp(-Math.pow(alt - 860, 2) / (2 * 40 * 40));
    // Peak 4: 700km SSO reconnaissance
    const peak4 = 65 * Math.exp(-Math.pow(alt - 700, 2) / (2 * 35 * 35));
    // Baseline space density
    const baseline = 8 + Math.random() * 2;

    const density = Math.min(100, Math.max(0, peak1 + peak2 + peak3 + peak4 + baseline));
    data.push({ altitude: alt, density });
  }

  useEffect(() => {
    if (!isOpen || !svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const width = 540;
    const height = 180;
    const margin = { top: 20, right: 25, bottom: 35, left: 45 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const g = svg
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // X Scale: Altitude (km)
    const xScale = d3
      .scaleLinear()
      .domain([300, 1400])
      .range([0, innerWidth]);

    // Y Scale: Conjunction Density Score
    const yScale = d3
      .scaleLinear()
      .domain([0, 100])
      .range([innerHeight, 0]);

    // Define D3 Gradient for risk fill
    const defs = svg.append('defs');
    const gradient = defs
      .append('linearGradient')
      .attr('id', 'risk-gradient')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');

    gradient
      .append('stop')
      .attr('offset', '0%')
      .attr('stop-color', '#f43f5e')
      .attr('stop-opacity', 0.65);

    gradient
      .append('stop')
      .attr('offset', '60%')
      .attr('stop-color', '#fbbf24')
      .attr('stop-opacity', 0.25);

    gradient
      .append('stop')
      .attr('offset', '100%')
      .attr('stop-color', '#06b6d4')
      .attr('stop-opacity', 0.02);

    // Area Generator
    const area = d3
      .area<DensityPoint>()
      .x((d) => xScale(d.altitude))
      .y0(innerHeight)
      .y1((d) => yScale(d.density))
      .curve(d3.curveMonotoneX);

    // Line Generator
    const line = d3
      .line<DensityPoint>()
      .x((d) => xScale(d.altitude))
      .y((d) => yScale(d.density))
      .curve(d3.curveMonotoneX);

    // Grid lines
    g.append('g')
      .attr('class', 'grid')
      .attr('opacity', 0.1)
      .call(
        d3
          .axisLeft(yScale)
          .ticks(4)
          .tickSize(-innerWidth)
          .tickFormat(() => '')
      );

    // Render Area
    g.append('path')
      .datum(data)
      .attr('fill', 'url(#risk-gradient)')
      .attr('d', area);

    // Render Line
    g.append('path')
      .datum(data)
      .attr('fill', 'none')
      .attr('stroke', '#f43f5e')
      .attr('stroke-width', 2)
      .attr('d', line);

    // Annotate Critical Corridors on Chart
    const keyCorridors = [
      { alt: 530, label: '530km (Starlink)', yOffset: -6 },
      { alt: 790, label: '790km (Cosmos-2251)', yOffset: -12 },
      { alt: 860, label: '860km (Fengyun-1C)', yOffset: -2 },
    ];

    keyCorridors.forEach((kc) => {
      const x = xScale(kc.alt);
      g.append('line')
        .attr('x1', x)
        .attr('x2', x)
        .attr('y1', 0)
        .attr('y2', innerHeight)
        .attr('stroke', 'rgba(255, 255, 255, 0.25)')
        .attr('stroke-dasharray', '3,3');

      g.append('text')
        .attr('x', x)
        .attr('y', kc.yOffset)
        .attr('text-anchor', 'middle')
        .attr('fill', '#cbd5e1')
        .attr('font-size', '9px')
        .attr('font-family', 'JetBrains Mono, monospace')
        .text(kc.label);
    });

    // Axes
    const xAxis = d3
      .axisBottom(xScale)
      .ticks(6)
      .tickFormat((d) => `${d} km`);
    const yAxis = d3.axisLeft(yScale).ticks(4);

    g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(xAxis)
      .attr('color', 'rgba(255, 255, 255, 0.4)')
      .selectAll('text')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('font-size', '10px');

    g.append('g')
      .call(yAxis)
      .attr('color', 'rgba(255, 255, 255, 0.4)')
      .selectAll('text')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('font-size', '10px');

    // Interactive Hover Tracking Line & Dot
    const hoverLine = g
      .append('line')
      .attr('y1', 0)
      .attr('y2', innerHeight)
      .attr('stroke', '#38bdf8')
      .attr('stroke-width', 1.5)
      .attr('opacity', 0);

    const hoverCircle = g
      .append('circle')
      .attr('r', 4)
      .attr('fill', '#38bdf8')
      .attr('stroke', '#ffffff')
      .attr('stroke-width', 1.5)
      .attr('opacity', 0);

    // Overlay for mouse tracking
    svg
      .append('rect')
      .attr('transform', `translate(${margin.left},${margin.top})`)
      .attr('width', innerWidth)
      .attr('height', innerHeight)
      .attr('fill', 'transparent')
      .on('mousemove', (event) => {
        const [mx] = d3.pointer(event);
        const altVal = xScale.invert(mx);
        const bisect = d3.bisector<DensityPoint, number>((d) => d.altitude).left;
        const idx = Math.min(data.length - 1, Math.max(0, bisect(data, altVal)));
        const pt = data[idx];

        if (pt) {
          hoverLine
            .attr('x1', xScale(pt.altitude))
            .attr('x2', xScale(pt.altitude))
            .attr('opacity', 0.8);

          hoverCircle
            .attr('cx', xScale(pt.altitude))
            .attr('cy', yScale(pt.density))
            .attr('opacity', 1);

          setHoveredPoint(pt);
        }
      })
      .on('mouseleave', () => {
        hoverLine.attr('opacity', 0);
        hoverCircle.attr('opacity', 0);
        setHoveredPoint(null);
      });
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-2xl flex flex-col rounded-xl border border-rose-500/30 bg-[#08090d] shadow-2xl overflow-hidden font-mono text-xs">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-rose-950/20">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center w-8 h-8 rounded border border-rose-500/40 bg-rose-900/30 text-rose-400">
              <Flame className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-tight">
                SPATIAL CONJUNCTION RISK HEATMAP & CORRIDORS
              </div>
              <div className="text-[11px] text-rose-300">
                D3-calculated spatial density & pairwise orbital collision flux
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {/* Top D3 Chart Section */}
          <div className="p-3.5 rounded-lg border border-white/10 bg-black/40 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-300">
              <div className="flex items-center gap-1.5 font-semibold text-white">
                <TrendingUp className="w-3.5 h-3.5 text-rose-400" />
                <span>LEO Spatial Flux Density Profile (300 km – 1,400 km)</span>
              </div>

              {hoveredPoint ? (
                <div className="text-cyan-300">
                  Alt: <span className="text-white font-bold">{hoveredPoint.altitude} km</span> · Risk Flux: <span className="text-rose-400 font-bold">{hoveredPoint.density.toFixed(1)}/100</span>
                </div>
              ) : (
                <span className="text-slate-400">Hover chart to inspect altitude flux</span>
              )}
            </div>

            {/* D3 SVG Container */}
            <div className="w-full flex justify-center overflow-x-auto">
              <svg ref={svgRef} viewBox="0 0 540 180" className="w-full h-auto max-h-[190px]" />
            </div>
          </div>

          {/* Critical Corridors List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <div className="flex items-center gap-1.5 font-semibold text-slate-200">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                <span>Monitored High-Density Conjunction Corridors</span>
              </div>
              <span>Click to view corridor specifications</span>
            </div>

            <div className="grid grid-cols-1 gap-2 max-h-56 overflow-y-auto pr-1">
              {CORRIDORS.map((c) => {
                return (
                  <div
                    key={c.id}
                    onClick={() => onSelectCorridor(c)}
                    className="p-3 rounded-lg border border-white/10 bg-white/[0.02] hover:bg-white/[0.05] hover:border-rose-500/40 transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: c.colorHex }}
                        />
                        <span className="text-xs font-bold text-white group-hover:text-rose-300 transition-colors">
                          {c.name}
                        </span>
                      </div>

                      <span
                        className={`px-1.5 py-0.5 text-[10px] rounded font-semibold uppercase ${
                          c.riskLevel === 'CRITICAL'
                            ? 'bg-rose-950/60 border border-rose-500/40 text-rose-300'
                            : 'bg-amber-950/60 border border-amber-500/40 text-amber-300'
                        }`}
                      >
                        {c.riskLevel}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-white/5 text-[11px] text-slate-400">
                      <div>
                        <span className="text-slate-500">Altitude:</span>
                        <div className="text-slate-200 font-semibold">{c.altitudeKm} km</div>
                      </div>
                      <div>
                        <span className="text-slate-500">Tracked Assets:</span>
                        <div className="text-cyan-300 font-semibold">{c.trackedObjects.toLocaleString()}</div>
                      </div>
                      <div>
                        <span className="text-slate-500">Risk Score:</span>
                        <div className="text-rose-400 font-semibold">{c.densityScore}/100</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-white/10 bg-black/40 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <AlertOctagon className="w-3.5 h-3.5 text-amber-400" />
            <span>3D Heatmap Shell: Active in Earth Viewport</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-semibold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
