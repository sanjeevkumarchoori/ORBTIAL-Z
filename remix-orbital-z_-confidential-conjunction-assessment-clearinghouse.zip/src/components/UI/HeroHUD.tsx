import React, { useState } from 'react';
import { ChevronUp, ChevronDown, Lock, Radio } from 'lucide-react';

interface HeroHUDProps {
  onFocusConjunction: () => void;
}

export const HeroHUD: React.FC<HeroHUDProps> = ({ onFocusConjunction }) => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="absolute top-16 left-4 sm:left-6 z-10 max-w-xl pointer-events-none transition-all duration-300">
      <div className="p-4 sm:p-5 rounded-lg border border-white/10 bg-[#08090d]/85 shadow-2xl pointer-events-auto">
        <div className="flex items-center justify-between gap-4 pb-2 border-b border-white/10">
          <div className="flex items-center gap-2 text-[11px] font-mono tracking-wider text-cyan-400">
            <Radio className="w-3.5 h-3.5" />
            <span>MISSION CRITICAL // CONJUNCTION CLEARINGHOUSE</span>
          </div>

          <button
            onClick={() => setCollapsed(!collapsed)}
            className="flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-white transition-colors"
            title={collapsed ? 'Expand Overview' : 'Collapse Overview'}
          >
            <span>{collapsed ? 'Expand' : 'Hide'}</span>
            {collapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </button>
        </div>

        {!collapsed && (
          <div className="pt-3 space-y-2.5">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white text-balance leading-snug">
              Autonomous Orbital Safety via Zero-Knowledge Telemetry
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Orchestrating autonomous collision avoidance maneuvers across competing sovereign & commercial satellite operators inside an IBM z16 / LinuxONE s390x Confidential Computing hardware enclave—without exposing classified orbital ephemerides.
            </p>

            <div className="pt-1 flex flex-wrap items-center gap-2">
              <button
                onClick={onFocusConjunction}
                className="px-3 py-1.5 text-xs font-semibold text-rose-100 bg-rose-950/80 hover:bg-rose-900 border border-rose-500/40 rounded transition-colors"
              >
                Focus Critical Conjunction (410m)
              </button>

              <div className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono text-slate-400 border border-white/10 rounded bg-white/[0.03]">
                <Lock className="w-3 h-3 text-purple-400" />
                <span>Zero Ephemeris Leakage</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
