import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Cpu,
  Key,
  Copy,
  Check,
  Lock,
  Terminal,
  Activity,
  CheckCircle2,
  Users,
  FileCode2,
} from 'lucide-react';
import { generateEnclaveAttestation, verifyProofClientSide } from '../../services/zkEnclave';

interface ZkProofModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ZkProofModal: React.FC<ZkProofModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'ATTESTATION' | 'MPC_FLOW' | 'PCR_REGISTERS' | 'GROTH16_JSON'>('ATTESTATION');
  const [verificationResult, setVerificationResult] = useState<{
    tested: boolean;
    valid: boolean;
    latencyMs: number;
  }>({
    tested: false,
    valid: false,
    latencyMs: 0,
  });

  const attestation = generateEnclaveAttestation({ id: 'conjunction-4092-8921' });

  if (!isOpen) return null;

  const handleVerify = () => {
    const res = verifyProofClientSide(attestation);
    setVerificationResult({
      tested: true,
      valid: res.isValid,
      latencyMs: res.verificationLatencyMs,
    });
  };

  const copyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(attestation, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md select-none overflow-y-auto">
      <div className="w-full max-w-4xl max-h-[92vh] flex flex-col rounded-2xl border border-violet-500/40 bg-[#08090d] shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-violet-950/20">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg border border-violet-500/40 bg-violet-900/30 text-violet-300">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                <span>IBM z16 / LinuxONE s390x Secure Execution Enclave</span>
                <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-violet-500/20 text-violet-300 border border-violet-500/30">
                  CPACF + HSM
                </span>
              </div>
              <div className="text-[11px] font-mono text-violet-300">
                Zero-Knowledge Conjunction Assessment & Post-Quantum Attestation
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection Bar */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-black/40 border-b border-white/10 text-xs font-mono overflow-x-auto">
          {[
            { id: 'ATTESTATION', label: 'Hardware Attestation', icon: Cpu },
            { id: 'MPC_FLOW', label: 'MPC Operator Flow', icon: Users },
            { id: 'PCR_REGISTERS', label: 'PCR0-PCR7 Registers', icon: Key },
            { id: 'GROTH16_JSON', label: 'zk-SNARK Payload (JSON)', icon: FileCode2 },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-violet-600/30 text-violet-200 border border-violet-500/50 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 bg-white/[0.02] border border-transparent hover:border-white/10'
                }`}
              >
                <tab.icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs font-mono">
          {/* TAB 1: Hardware Attestation */}
          {activeTab === 'ATTESTATION' && (
            <div className="space-y-4">
              {/* Hardware Integrity Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] space-y-1.5">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase font-semibold">
                    <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Host Enclave Hardware Architecture</span>
                  </div>
                  <div className="text-white font-bold text-sm">{attestation.platform}</div>
                  <div className="text-[11px] text-slate-300">{attestation.cpuArchitecture}</div>
                  <div className="text-[10px] text-cyan-400 pt-1">
                    Enclave ID: {attestation.enclaveId}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] space-y-1.5">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase font-semibold">
                    <Key className="w-3.5 h-3.5 text-purple-400" />
                    <span>Hardware Security Module (HSM) & Acceleration</span>
                  </div>
                  <div className="text-white font-bold text-sm">Crypto Express 8S (CEX8S)</div>
                  <div className="text-[11px] text-emerald-400 font-semibold">{attestation.cpacfStatus}</div>
                  <div className="text-[10px] text-purple-300 pt-1">
                    Firmware: {attestation.firmwareHash.slice(0, 32)}...
                  </div>
                </div>
              </div>

              {/* Zero-Leakage Confidential Guarantee */}
              <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-950/20 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                    <Lock className="w-4 h-4" />
                    <span>Confidential Computing & Zero Ephemeris Leakage Guarantee</span>
                  </div>
                  <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                    0 BYTES LEAKED
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-sans leading-relaxed">
                  Classified sovereign reconnaissance ephemeris (Asset #4092) and proprietary commercial broadband telemetry (Asset #8921) are encrypted under the s390x hardware public key before transmission. Decryption and trajectory propagation occur strictly inside CPU L3-cache isolated secure hardware memory. Host hypervisors, cloud operators, and foreign adversaries have zero physical or memory read visibility.
                </p>
              </div>

              {/* Post-Quantum Signatures */}
              <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-slate-300">
                    Post-Quantum Cryptographic Standards (NIST FIPS 203 & 204)
                  </span>
                  <span className="text-[10px] text-cyan-300 px-2 py-0.5 rounded bg-cyan-950/50 border border-cyan-500/30">
                    QUANTUM RESISTANT
                  </span>
                </div>
                <div className="space-y-1.5 text-[11px] text-slate-400">
                  <div>
                    <span className="text-cyan-400 font-semibold">ML-KEM-1024 (Key Encapsulation):</span>
                    <div className="text-[10px] text-slate-400 break-all pl-2 font-mono">
                      {attestation.postQuantum.mlKem1024Ciphertext}
                    </div>
                  </div>
                  <div>
                    <span className="text-purple-400 font-semibold">ML-DSA-87 (Digital Signature):</span>
                    <div className="text-[10px] text-slate-400 break-all pl-2 font-mono">
                      {attestation.postQuantum.mlDsa87Signature}
                    </div>
                  </div>
                </div>
              </div>

              {/* Verification Callout Box */}
              <div className="p-4 rounded-xl border border-violet-500/30 bg-violet-950/20 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="space-y-1 text-center sm:text-left">
                  <div className="text-white font-bold text-xs flex items-center gap-1.5 justify-center sm:justify-start">
                    <Activity className="w-3.5 h-3.5 text-violet-400" />
                    <span>Client-Side snarkjs / Groth16 Verifier</span>
                  </div>
                  <div className="text-[11px] text-slate-300 font-sans">
                    Verify pairing equations e(πA, πB) == e(α, β) · e(πC, δ) and PCR registers locally in browser.
                  </div>
                </div>

                <button
                  onClick={handleVerify}
                  className="px-4 py-2 rounded-lg bg-gradient-to-r from-violet-600 to-emerald-600 hover:from-violet-500 hover:to-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer whitespace-nowrap"
                >
                  Verify Cryptographic Proof
                </button>
              </div>

              {/* Verification Success Badge */}
              {verificationResult.tested && (
                <div className="p-3.5 rounded-xl border border-emerald-500/50 bg-emerald-950/40 space-y-1 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>PROOF VALID // ZERO EPHEMERIS LEAKAGE</span>
                    </div>
                    <span className="text-[11px] text-emerald-300 font-bold">
                      Latency: {verificationResult.latencyMs} ms
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-300 font-sans">
                    Pairing validation passed on alt_bn128 curve. All 8 Platform Configuration Registers (PCR0-PCR7) match the certified IBM z16 microcode attestation digest.
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: MPC Multi-Party Computation Flow */}
          {activeTab === 'MPC_FLOW' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] space-y-1.5">
                <div className="text-white font-bold text-xs">
                  Multi-Party Computation (MPC) Orbital Conjunction Protocol
                </div>
                <p className="text-xs text-slate-300 font-sans leading-relaxed">
                  Allows competing nations and commercial rivals to resolve orbital conjunctions collaboratively without disclosing sensitive mission parameters, reconnaissance inclinations, or stealth orbital trajectories.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Operator A Card */}
                <div className="p-4 rounded-xl border border-rose-500/30 bg-rose-950/20 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-rose-400 font-bold text-xs">Operator A (Primary)</span>
                    <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-rose-500/20 text-rose-300">
                      {attestation.mpcFlow.operatorA.classification}
                    </span>
                  </div>
                  <div className="text-white font-semibold text-xs">
                    {attestation.mpcFlow.operatorA.name}
                  </div>
                  <div className="text-[11px] text-slate-300">
                    Encrypted Payload: {attestation.mpcFlow.operatorA.encryptedPayloadSize}
                  </div>
                  <div className="space-y-1 pt-1 border-t border-rose-500/20">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">
                      Classified Ephemeris Kept Hidden:
                    </span>
                    <ul className="text-[11px] text-slate-300 space-y-0.5 list-disc list-inside">
                      {attestation.mpcFlow.operatorA.secretsProtected.map((sec, i) => (
                        <li key={i}>{sec}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Operator B Card */}
                <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-950/20 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-amber-400 font-bold text-xs">Operator B (Secondary)</span>
                    <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-amber-500/20 text-amber-300">
                      {attestation.mpcFlow.operatorB.classification}
                    </span>
                  </div>
                  <div className="text-white font-semibold text-xs">
                    {attestation.mpcFlow.operatorB.name}
                  </div>
                  <div className="text-[11px] text-slate-300">
                    Encrypted Payload: {attestation.mpcFlow.operatorB.encryptedPayloadSize}
                  </div>
                  <div className="space-y-1 pt-1 border-t border-amber-500/20">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">
                      Proprietary Data Kept Hidden:
                    </span>
                    <ul className="text-[11px] text-slate-300 space-y-0.5 list-disc list-inside">
                      {attestation.mpcFlow.operatorB.secretsProtected.map((sec, i) => (
                        <li key={i}>{sec}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Enclave Output Box */}
              <div className="p-4 rounded-xl border border-violet-500/40 bg-violet-950/30 space-y-2">
                <div className="text-violet-300 font-bold text-xs flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Enclave Autonomous Optimization Output:</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] pt-1">
                  <div className="p-2 rounded bg-black/40 border border-white/10">
                    <span className="text-slate-400">Clearance Target:</span>
                    <div className="text-white font-bold">&gt; 4,500 meters</div>
                  </div>
                  <div className="p-2 rounded bg-black/40 border border-white/10">
                    <span className="text-slate-400">Optimal Micro-Thrust Δv:</span>
                    <div className="text-purple-300 font-bold">[r: +14.2, t: -8.4, n: +3.1] mm/s</div>
                  </div>
                  <div className="p-2 rounded bg-black/40 border border-white/10">
                    <span className="text-slate-400">72h Secondary Sweep:</span>
                    <div className="text-emerald-400 font-bold">0 Conjunctions</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PCR0-PCR7 Registers */}
          {activeTab === 'PCR_REGISTERS' && (
            <div className="space-y-3">
              <div className="text-slate-300 text-[11px] pb-1">
                Measured Boot Platform Configuration Registers (PCRs) cryptographically hashed into the CPU Crypto Express 8S root of trust:
              </div>

              <div className="space-y-2">
                {Object.entries(attestation.pcrRegisters).map(([pcr, hash]) => (
                  <div
                    key={pcr}
                    className="p-2.5 rounded-lg border border-white/10 bg-black/40 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px]"
                  >
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-violet-950/60 text-violet-300 font-bold border border-violet-500/30">
                        {pcr}
                      </span>
                      <span className="text-slate-400 text-[10px]">
                        {pcr === 'PCR0' && 's390x Secure Execution Firmware'}
                        {pcr === 'PCR1' && 'CPACF Hardware Acceleration Microcode'}
                        {pcr === 'PCR2' && 'CEX8S HSM Cryptographic Engine'}
                        {pcr === 'PCR3' && 'LinuxONE Hypervisor Isolation'}
                        {pcr === 'PCR4' && 'Secure Execution Guest Kernel'}
                        {pcr === 'PCR5' && 'Groth16 Bn254 Constraint System'}
                        {pcr === 'PCR6' && 'MPC Ephemeris Ingestion Guard'}
                        {pcr === 'PCR7' && 'Hardware Ephemeris Zero-Leakage Policy'}
                      </span>
                    </div>
                    <div className="font-mono text-cyan-300 text-[10px] break-all sm:text-right">
                      {hash}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: Groth16 Proof JSON Payload */}
          {activeTab === 'GROTH16_JSON' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-violet-400" />
                  <span>snarkjs / Circom Groth16 JSON Payload (alt_bn128)</span>
                </div>
                <span>Execution: {attestation.executionTimeMs} ms</span>
              </div>

              <pre className="p-3.5 rounded-xl bg-black/70 border border-white/10 text-[11px] text-slate-300 overflow-x-auto max-h-[360px] leading-relaxed font-mono">
                {JSON.stringify(attestation, null, 2)}
              </pre>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-white/10 bg-black/40 text-xs font-mono">
          <div className="text-[11px] text-slate-400">
            Attestation Certificate: <span className="text-emerald-400 font-semibold">VALID // s390x-HW-SEALED</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyJson}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-white/10 rounded-lg transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy JSON'}</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-violet-600 hover:bg-violet-500 rounded-lg transition-colors cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
