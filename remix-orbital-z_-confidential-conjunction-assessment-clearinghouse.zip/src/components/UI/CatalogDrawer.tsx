import React, { useState } from 'react';
import { X, Search, Satellite, Filter, Target } from 'lucide-react';
import { SEED_CATALOG } from '../../services/propagator';
import { OrbitalAsset, OrbitClass } from '../../types/orbital';

interface CatalogDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAsset: (asset: OrbitalAsset) => void;
}

export const CatalogDrawer: React.FC<CatalogDrawerProps> = ({
  isOpen,
  onClose,
  onSelectAsset,
}) => {
  const [filterClass, setFilterClass] = useState<OrbitClass | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filteredAssets = SEED_CATALOG.filter((asset) => {
    const matchesClass = filterClass === 'ALL' || asset.orbitClass === filterClass;
    const matchesSearch =
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.noradId.toString().includes(searchQuery) ||
      (asset.operator && asset.operator.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesClass && matchesSearch;
  });

  return (
    <div className="fixed inset-y-0 right-0 z-40 w-full max-w-md bg-[#08090d]/95 border-l border-white/10 shadow-2xl flex flex-col select-none">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10 bg-[#030305]">
        <div className="flex items-center gap-2">
          <Satellite className="w-4 h-4 text-cyan-400" />
          <span className="text-sm font-bold text-white font-mono">
            ORBITAL ASSET CATALOG
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-3 border-b border-white/10 space-y-2 bg-white/[0.01]">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search satellite name, NORAD ID, operator..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded bg-black/50 border border-white/15 text-xs font-mono text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/50"
          />
        </div>

        {/* Orbit Class Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto text-xs font-mono">
          <Filter className="w-3 h-3 text-slate-500 mr-1 shrink-0" />
          {(['ALL', 'LEO', 'MEO', 'GEO'] as const).map((c) => {
            const isSelected = filterClass === c;
            return (
              <button
                key={c}
                onClick={() => setFilterClass(c)}
                className={`px-2 py-0.5 rounded text-[11px] whitespace-nowrap transition-colors ${
                  isSelected
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-white bg-white/[0.03]'
                }`}
              >
                {c}
              </button>
            );
          })}
        </div>
      </div>

      {/* Asset List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {filteredAssets.map((asset) => {
          return (
            <div
              key={asset.id}
              className="p-3 rounded-lg border border-white/10 bg-white/[0.02] hover:bg-white/[0.05] hover:border-cyan-500/30 transition-colors group"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: asset.color }}
                    />
                    <span className="text-xs font-bold text-white font-mono">
                      {asset.name}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    NORAD: {asset.noradId} · {asset.operator}
                  </div>
                </div>

                <button
                  onClick={() => {
                    onSelectAsset(asset);
                    onClose();
                  }}
                  className="flex items-center gap-1 px-2 py-1 text-[11px] font-mono rounded bg-white/5 group-hover:bg-cyan-500/20 group-hover:text-cyan-300 text-slate-300 transition-colors"
                  title="Focus Asset"
                >
                  <Target className="w-3 h-3" />
                  <span>Inspect</span>
                </button>
              </div>

              {/* Orbital Telemetry Specs */}
              <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-white/5 text-[10px] font-mono text-slate-400">
                <div>
                  <span className="text-slate-500">Altitude:</span>
                  <div className="text-slate-200">{asset.altitudeKm} km</div>
                </div>
                <div>
                  <span className="text-slate-500">Inclination:</span>
                  <div className="text-slate-200">{asset.inclinationDeg}°</div>
                </div>
                <div>
                  <span className="text-slate-500">Velocity:</span>
                  <div className="text-cyan-300">{asset.velocityKms} km/s</div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredAssets.length === 0 && (
          <div className="p-8 text-center text-xs font-mono text-slate-500">
            No orbital assets match your filter query.
          </div>
        )}
      </div>

      {/* Drawer Footer */}
      <div className="p-3 border-t border-white/10 bg-[#030305] text-[11px] font-mono text-slate-400 flex items-center justify-between">
        <span>Active Catalog: {SEED_CATALOG.length} Verified TLEs</span>
        <span className="text-emerald-400">PROPAGATOR: 60Hz SGP4</span>
      </div>
    </div>
  );
};
