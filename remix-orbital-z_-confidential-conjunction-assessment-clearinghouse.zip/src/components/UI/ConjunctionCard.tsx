import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  AlertTriangle,
  ShieldCheck,
  ArrowUpRight,
  Zap,
  Target,
  Gauge,
  TrendingUp,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { generate72hPcEvolution, PcEvolutionPoint } from '../../services/bPlaneService';

interface ConjunctionCardProps {
  onInspectProof: () => void;
  onFocusConjunction: () => void;
  onOpenBPlane?: () => void;
}

export const ConjunctionCard: React.FC<ConjunctionCardProps> = ({
  onInspectProof,
  onFocusConjunction,
  onOpenBPlane,
}) => {
  // Real-time countdown to TCA (T-00:14:22)
  const [totalSeconds, setTotalSeconds] = useState(14 * 60 + 22);
  const [isChartExpanded, setIsChartExpanded] = useState(true);
  const [hoveredPoint, setHoveredPoint] = useState<PcEvolutionPoint | null>(null);

  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setTotalSeconds((prev) => (prev > 0 ? prev - 1 : 14 * 60 + 22));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTca = (seconds: number) => {
    const mm = Math.floor(seconds / 60)
      .toString()
      .padStart(2, '0');
    const ss = (seconds % 60).toString().padStart(2, '0');
    return `T-00:${mm}:${ss}`;
  };

  // 72-Hour Prediction Window Pc Evolution Data
  const { points, maxRiskPoint, criticalThresholdPc, advisoryThresholdPc } = useMemo(
    () => generate72hPcEvolution(),
    []
  );

  // SVG Chart Geometry Constants
  const svgWidth = 380;
  const svgHeight = 88;
  const padLeft = 16;
  const padRight = 16;
  const padTop = 14;
  const padBottom = 20;
  const plotWidth = svgWidth - padLeft - padRight;
  const plotHeight = svgHeight - padTop - padBottom;

  const minLog = -7.0;
  const maxLog = -2.6;

  const getX = (hours: number) => {
    return padLeft + ((hours - -72) / 144) * plotWidth;
  };

  const getY = (pc: number) => {
    const logPc = Math.log10(Math.max(1e-7, pc));
    const normalized = (logPc - minLog) / (maxLog - minLog);
    return padTop + (1 - Math.max(0, Math.min(1, normalized))) * plotHeight;
  };

  // Generate SVG path strings
  const linePathD = useMemo(() => {
    return points.reduce((acc, p, i) => {
      const x = getX(p.hoursOffset).toFixed(1);
      const y = getY(p.pc).toFixed(1);
      return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [points]);

  const areaPathD = useMemo(() => {
    const baselineY = (padTop + plotHeight).toFixed(1);
    const startX = getX(-72).toFixed(1);
    const endX = getX(72).toFixed(1);
    return `${linePathD} L ${endX} ${baselineY} L ${startX} ${baselineY} Z`;
  }, [linePathD]);

  const thresholdCriticalY = getY(criticalThresholdPc);
  const thresholdAdvisoryY = getY(advisoryThresholdPc);
  const tcaX = getX(0);
  const tcaY = getY(maxRiskPoint.pc);

  const activePoint = hoveredPoint || maxRiskPoint;

  // Handle pointer interaction across the SVG sparkline
  const handleSvgMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const scale = svgWidth / rect.width;
    const chartX = mouseX * scale;

    // Convert chartX back to hoursOffset
    const hours = -72 + ((chartX - padLeft) / plotWidth) * 144;
    // Find closest data point
    let closest = points[0];
    let minDiff = Infinity;
    for (const p of points) {
      const diff = Math.abs(p.hoursOffset - hours);
      if (diff < minDiff) {
        minDiff = diff;
        closest = p;
      }
    }
    setHoveredPoint(closest);
  };

  return (
    <div className="absolute top-16 right-3 sm:right-6 z-10 w-full max-w-sm sm:max-w-md pointer-events-none transition-all">
      <div className="p-4 sm:p-5 rounded-2xl border border-rose-500/30 bg-[#08090d]/90 shadow-2xl pointer-events-auto space-y-3.5 backdrop-blur-md">
        {/* Incident Alert Header */}
        <div className="flex items-center justify-between gap-3 pb-2.5 border-b border-rose-500/20">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-6 h-6 rounded-md bg-rose-950/80 border border-rose-500/50 text-rose-400">
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-mono font-bold tracking-wider text-rose-400">
              [CRITICAL CONJUNCTION DETECTED]
            </span>
          </div>

          <span className="px-2 py-0.5 text-[10px] font-mono uppercase rounded bg-rose-950/60 border border-rose-500/30 text-rose-300 font-bold">
            Pc: 1.84e-3 (High)
          </span>
        </div>

        {/* Participating Assets */}
        <div className="grid grid-cols-2 gap-2 text-xs font-mono">
          <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/5 space-y-1">
            <div className="flex items-center gap-1.5 text-rose-400 text-[10px] uppercase font-semibold">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              <span>Primary Object</span>
            </div>
            <div className="font-bold text-white text-[11px] truncate">
              Asset #4092
            </div>
            <div className="text-[10px] text-slate-400">
              Sovereign Recon (Classified)
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/5 space-y-1">
            <div className="flex items-center gap-1.5 text-amber-400 text-[10px] uppercase font-semibold">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>Secondary Object</span>
            </div>
            <div className="font-bold text-white text-[11px] truncate">
              Asset #8921
            </div>
            <div className="text-[10px] text-slate-400">
              Commercial Broadband
            </div>
          </div>
        </div>

        {/* Proximity & Countdown Readouts */}
        <div className="grid grid-cols-3 gap-2 px-3 py-2.5 rounded-lg bg-white/[0.02] border border-white/10 font-mono">
          <div>
            <div className="text-[9px] text-slate-400 uppercase">Miss Distance</div>
            <div className="text-sm sm:text-base font-bold text-rose-400 tabular-nums">
              410.2 <span className="text-[10px] text-slate-400 font-normal">m</span>
            </div>
          </div>

          <div>
            <div className="text-[9px] text-slate-400 uppercase">Rel Velocity</div>
            <div className="text-sm sm:text-base font-bold text-cyan-300 tabular-nums">
              14.2 <span className="text-[10px] text-slate-400 font-normal">km/s</span>
            </div>
          </div>

          <div className="text-right">
            <div className="text-[9px] text-slate-400 uppercase">Time to TCA</div>
            <div className="text-sm sm:text-base font-bold text-amber-300 tabular-nums">
              {formatTca(totalSeconds)}
            </div>
          </div>
        </div>

        {/* 72-HOUR PROBABILITY OF COLLISION (Pc) EVOLUTION TREND CHART */}
        <div className="p-3 rounded-xl bg-black/60 border border-white/10 space-y-2">
          {/* Trend Chart Title & Peak Risk Identification Banner */}
          <div className="flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-1.5 text-slate-200 font-semibold">
              <TrendingUp className="w-3.5 h-3.5 text-rose-400" />
              <span>Pc Evolution (72h Window)</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                MAX: 1.84e-3 at TCA
              </span>
              <button
                onClick={() => setIsChartExpanded(!isChartExpanded)}
                className="p-0.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
                title={isChartExpanded ? 'Collapse Chart' : 'Expand Chart'}
              >
                {isChartExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            </div>
          </div>

          {isChartExpanded && (
            <div className="space-y-2 pt-1 font-mono">
              {/* Dynamic Interactive Telemetry Readout for Hovered Point */}
              <div className="flex items-center justify-between px-2 py-1 rounded bg-white/[0.03] border border-white/5 text-[10px]">
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400">Timestamp:</span>
                  <span className="text-white font-bold">{activePoint.label}</span>
                  {activePoint.isMaximumRisk && (
                    <span className="px-1.5 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-500/40 font-bold">
                      [MAXIMUM RISK]
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-slate-400">Pc:</span>
                  <span
                    className={`font-bold tabular-nums ${
                      activePoint.riskLevel === 'CRITICAL'
                        ? 'text-rose-400'
                        : activePoint.riskLevel === 'WARNING'
                        ? 'text-amber-400'
                        : 'text-cyan-300'
                    }`}
                  >
                    {activePoint.pc.toExponential(3)}
                  </span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                      activePoint.riskLevel === 'CRITICAL'
                        ? 'bg-rose-500/20 text-rose-300'
                        : activePoint.riskLevel === 'WARNING'
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {activePoint.riskLevel}
                  </span>
                </div>
              </div>

              {/* High-Resolution SVG Sparkline / Area Chart */}
              <div className="relative overflow-hidden rounded-lg bg-[#040508] border border-white/10 p-1">
                <svg
                  ref={svgRef}
                  viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                  className="w-full h-auto max-h-[88px] block cursor-crosshair select-none"
                  onMouseMove={handleSvgMouseMove}
                  onMouseLeave={() => setHoveredPoint(null)}
                >
                  <defs>
                    {/* Gradient Fill for Risk Surge */}
                    <linearGradient id="pcAreaGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.55" />
                      <stop offset="60%" stopColor="#8b5cf6" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.02" />
                    </linearGradient>
                    <linearGradient id="pcLineGradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#06b6d4" />
                      <stop offset="50%" stopColor="#f43f5e" />
                      <stop offset="100%" stopColor="#06b6d4" />
                    </linearGradient>
                  </defs>

                  {/* Horizontal Threshold Reference Lines */}
                  {/* Alert Threshold: 1e-4 */}
                  <line
                    x1={padLeft}
                    y1={thresholdCriticalY}
                    x2={svgWidth - padRight}
                    y2={thresholdCriticalY}
                    stroke="rgba(244, 63, 94, 0.45)"
                    strokeDasharray="2,2"
                    strokeWidth="1"
                  />
                  <text
                    x={svgWidth - padRight - 2}
                    y={thresholdCriticalY - 2}
                    textAnchor="end"
                    fill="#f43f5e"
                    fontSize="7"
                    fontFamily="monospace"
                  >
                    Alert Threshold (1e-4)
                  </text>

                  {/* Advisory Threshold: 1e-5 */}
                  <line
                    x1={padLeft}
                    y1={thresholdAdvisoryY}
                    x2={svgWidth - padRight}
                    y2={thresholdAdvisoryY}
                    stroke="rgba(251, 191, 36, 0.3)"
                    strokeDasharray="2,3"
                    strokeWidth="0.8"
                  />
                  <text
                    x={padLeft + 2}
                    y={thresholdAdvisoryY - 2}
                    fill="#fbbf24"
                    fontSize="7"
                    fontFamily="monospace"
                  >
                    Advisory (1e-5)
                  </text>

                  {/* Moment of Maximum Risk Indicator: Vertical Marker at TCA (T=0) */}
                  <line
                    x1={tcaX}
                    y1={padTop - 2}
                    x2={tcaX}
                    y2={padTop + plotHeight}
                    stroke="#f43f5e"
                    strokeDasharray="2,2"
                    strokeWidth="1.2"
                  />

                  {/* Area Fill Under Curve */}
                  <path d={areaPathD} fill="url(#pcAreaGradient)" />

                  {/* Main Pc Curve Stroke */}
                  <path
                    d={linePathD}
                    fill="none"
                    stroke="url(#pcLineGradient)"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />

                  {/* Moment of Maximum Risk Peak Marker (TCA) */}
                  <circle cx={tcaX} cy={tcaY} r="4.5" fill="#f43f5e" />
                  <circle cx={tcaX} cy={tcaY} r="7" fill="none" stroke="#f43f5e" strokeWidth="1" opacity="0.6" />
                  <circle cx={tcaX} cy={tcaY} r="2" fill="#ffffff" />

                  {/* Active Hover Cursor Indicator */}
                  {hoveredPoint && (
                    <g>
                      <line
                        x1={getX(hoveredPoint.hoursOffset)}
                        y1={padTop}
                        x2={getX(hoveredPoint.hoursOffset)}
                        y2={padTop + plotHeight}
                        stroke="#38bdf8"
                        strokeWidth="1"
                        strokeDasharray="3,2"
                      />
                      <circle
                        cx={getX(hoveredPoint.hoursOffset)}
                        cy={getY(hoveredPoint.pc)}
                        r="3.5"
                        fill="#38bdf8"
                        stroke="#ffffff"
                        strokeWidth="1"
                      />
                    </g>
                  )}

                  {/* Timeline Axis Time Ticks */}
                  <text x={getX(-72)} y={svgHeight - 6} fill="#64748b" fontSize="8" fontFamily="monospace">
                    -72h
                  </text>
                  <text x={getX(-24)} y={svgHeight - 6} fill="#64748b" fontSize="8" fontFamily="monospace" textAnchor="middle">
                    -24h
                  </text>
                  <text
                    x={tcaX}
                    y={svgHeight - 6}
                    fill="#f43f5e"
                    fontWeight="bold"
                    fontSize="8"
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    TCA (0h)
                  </text>
                  <text x={getX(24)} y={svgHeight - 6} fill="#64748b" fontSize="8" fontFamily="monospace" textAnchor="middle">
                    +24h
                  </text>
                  <text x={getX(72)} y={svgHeight - 6} fill="#64748b" fontSize="8" fontFamily="monospace" textAnchor="end">
                    +72h
                  </text>
                </svg>
              </div>

              {/* Explanatory Context Footer */}
              <div className="flex items-center justify-between text-[9px] text-slate-400 pt-0.5">
                <span>Moment of Max Risk: <span className="text-rose-400 font-bold">T-00:14:22 (TCA)</span></span>
                <span className="text-cyan-300">Hover across curve to inspect 72h window</span>
              </div>
            </div>
          )}
        </div>

        {/* Action Execution Readout */}
        <div className="p-2.5 rounded-lg bg-purple-950/20 border border-purple-500/20 space-y-1 text-xs">
          <div className="flex items-center gap-1.5 text-purple-300 font-mono text-[11px]">
            <Zap className="w-3.5 h-3.5" />
            <span className="font-bold">Autonomous Micro-Thrust Avoidance:</span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed font-sans">
            Optimized burn <span className="font-mono text-purple-200">Δv = [r: +14.2, t: -8.4, n: +3.1] mm/s</span> inside hardware enclave. Zero classified ephemeris exposed.
          </p>
        </div>

        {/* Action Buttons: B-Plane + zk-Proof + Camera */}
        <div className="pt-1 flex flex-col gap-2">
          {onOpenBPlane && (
            <button
              onClick={onOpenBPlane}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold text-cyan-200 bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-500/40 rounded-lg transition-colors cursor-pointer"
            >
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
              <span>Inspect B-Plane Radar & Maneuver Trade-Space</span>
              <ArrowUpRight className="w-3 h-3 ml-auto text-cyan-400" />
            </button>
          )}

          <div className="flex items-center justify-between gap-2 pt-1">
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-mono font-medium">
              <ShieldCheck className="w-4 h-4" />
              <span>COORDINATED</span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={onFocusConjunction}
                className="p-1.5 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-white/10 rounded-lg transition-colors cursor-pointer"
                title="Camera Focus Conjunction Vector"
              >
                <Target className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onInspectProof}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-violet-600 hover:bg-violet-500 border border-violet-400/40 rounded-lg transition-colors cursor-pointer"
              >
                <span>zk-SNARK Proof</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
