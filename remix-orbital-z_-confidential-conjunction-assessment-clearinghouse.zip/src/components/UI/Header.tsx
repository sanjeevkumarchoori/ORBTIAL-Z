import React, { useState, useEffect } from 'react';
import { Shield, Cpu, Activity, FileCheck2, Database, ListOrdered } from 'lucide-react';

interface HeaderProps {
  onOpenZkProof: () => void;
  onOpenCdm: () => void;
  onOpenCatalog: () => void;
  onOpenMissionLog: () => void;
  onOpenBPlane?: () => void;
  logCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenZkProof,
  onOpenCdm,
  onOpenCatalog,
  onOpenMissionLog,
  onOpenBPlane,
  logCount = 8,
}) => {
  const [assetCount, setAssetCount] = useState(48210);

  return (
    <header className="relative z-20 flex items-center justify-between gap-4 px-4 py-2.5 sm:px-6 bg-[#030305]/85 border-b border-white/10 select-none">
      {/* Brand Zone */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="flex items-center justify-center w-8 h-8 rounded border border-cyan-500/40 bg-cyan-950/40 text-cyan-400">
          <Shield className="w-4 h-4 stroke-[2.2]" />
        </div>
        <div className="flex flex-col">
          <span className="text-sm font-bold tracking-tight text-white whitespace-nowrap">
            ORBITAL-Z
          </span>
          <span className="text-[10px] font-mono tracking-wider text-slate-400 uppercase">
            Confidential Conjunction Clearinghouse
          </span>
        </div>
      </div>

      {/* Top Metrics Ribbon */}
      <div className="hidden lg:flex items-center gap-6 text-xs font-mono">
        <div className="flex items-center gap-2 text-slate-300">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-slate-400">Assets Tracked:</span>
          <span className="font-semibold text-white tabular-nums">
            {assetCount.toLocaleString()}+
          </span>
        </div>

        <div className="flex items-center gap-2 text-slate-300">
          <Cpu className="w-3.5 h-3.5 text-purple-400" />
          <span className="text-slate-400">Conjunction Scans:</span>
          <span className="font-semibold text-purple-300 tabular-nums">
            1.2M/sec
          </span>
        </div>

        <div className="flex items-center gap-2 px-2.5 py-1 rounded border border-emerald-500/20 bg-emerald-950/20 text-emerald-400 text-[11px]">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span className="font-medium tracking-wide">
            GLOBAL ENCLAVE SYNCHRONIZED
          </span>
        </div>
      </div>

      {/* Action Zone */}
      <div className="flex items-center gap-2 shrink-0">
        {onOpenBPlane && (
          <button
            onClick={onOpenBPlane}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-cyan-300 hover:text-white bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/30 rounded transition-colors whitespace-nowrap cursor-pointer"
            title="Inspect B-Plane Radar & Maneuver Trade-Space"
          >
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">B-Plane Radar</span>
          </button>
        )}

        <button
          onClick={onOpenMissionLog}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-white/10 hover:border-cyan-500/40 rounded transition-colors whitespace-nowrap cursor-pointer"
          title="Inspect Mission Audit & Enclave Log"
        >
          <ListOrdered className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">Mission Log</span>
          <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-500/30">
            {logCount}
          </span>
        </button>

        <button
          onClick={onOpenCatalog}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-white/10 rounded transition-colors whitespace-nowrap cursor-pointer"
          title="Browse Monitored Space Objects"
        >
          <Database className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">Orbit Catalog</span>
        </button>

        <button
          onClick={onOpenCdm}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-white/10 rounded transition-colors whitespace-nowrap cursor-pointer"
          title="Inspect Conjunction Data Messages (CDM)"
        >
          <FileCheck2 className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">CDM Feed</span>
        </button>

        <button
          onClick={onOpenZkProof}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-violet-600 hover:bg-violet-500 border border-violet-400/40 rounded transition-colors shadow-sm whitespace-nowrap cursor-pointer"
        >
          <Shield className="w-3.5 h-3.5 text-violet-200" />
          <span>zk-Proof Enclave</span>
        </button>
      </div>
    </header>
  );
};
