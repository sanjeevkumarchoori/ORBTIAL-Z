import React from 'react';
import { X, Satellite, Compass, Activity, Shield, Zap } from 'lucide-react';
import { OrbitalAsset } from '../../types/orbital';
import { EARTH_RADIUS_KM } from '../../services/propagator';

interface AssetDetailModalProps {
  asset: OrbitalAsset | null;
  onClose: () => void;
  onFocusAsset: (asset: OrbitalAsset) => void;
  onScreenConjunction: (asset: OrbitalAsset) => void;
}

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({
  asset,
  onClose,
  onFocusAsset,
  onScreenConjunction,
}) => {
  if (!asset) return null;

  const semiMajorAxis = EARTH_RADIUS_KM + asset.altitudeKm;
  const apogee = (semiMajorAxis * (1 + asset.eccentricity) - EARTH_RADIUS_KM).toFixed(1);
  const perigee = (semiMajorAxis * (1 - asset.eccentricity) - EARTH_RADIUS_KM).toFixed(1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-lg rounded-xl border border-white/10 bg-[#08090d] shadow-2xl overflow-hidden font-mono text-xs">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-white/[0.02]">
          <div className="flex items-center gap-2.5">
            <div
              className="flex items-center justify-center w-8 h-8 rounded border"
              style={{
                borderColor: asset.color,
                backgroundColor: `${asset.color}15`,
                color: asset.color,
              }}
            >
              <Satellite className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-tight">{asset.name}</div>
              <div className="text-[11px] text-slate-400">
                NORAD ID: {asset.noradId} · {asset.orbitClass} Orbit
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Metadata Block */}
          <div className="grid grid-cols-2 gap-3 text-[11px]">
            <div className="p-2.5 rounded bg-white/[0.02] border border-white/10">
              <span className="text-slate-500 uppercase">Operator:</span>
              <div className="text-white font-semibold truncate">{asset.operator || 'Unknown'}</div>
            </div>
            <div className="p-2.5 rounded bg-white/[0.02] border border-white/10">
              <span className="text-slate-500 uppercase">Registry / Origin:</span>
              <div className="text-white font-semibold">{asset.country || 'International'}</div>
            </div>
          </div>

          {/* Keplerian Orbital Parameters */}
          <div className="p-3.5 rounded-lg border border-white/10 bg-white/[0.02] space-y-2.5">
            <div className="flex items-center gap-1.5 text-cyan-400 font-semibold text-[11px]">
              <Compass className="w-3.5 h-3.5" />
              <span>Osculating Keplerian Orbital Elements</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-[11px]">
              <div>
                <span className="text-slate-500">Altitude:</span>
                <div className="text-white font-semibold">{asset.altitudeKm} km</div>
              </div>

              <div>
                <span className="text-slate-500">Inclination:</span>
                <div className="text-white font-semibold">{asset.inclinationDeg}°</div>
              </div>

              <div>
                <span className="text-slate-500">Period:</span>
                <div className="text-white font-semibold">{asset.periodMinutes} min</div>
              </div>

              <div>
                <span className="text-slate-500">Velocity:</span>
                <div className="text-cyan-300 font-semibold">{asset.velocityKms} km/s</div>
              </div>

              <div>
                <span className="text-slate-500">Eccentricity:</span>
                <div className="text-white font-semibold">{asset.eccentricity.toFixed(5)}</div>
              </div>

              <div>
                <span className="text-slate-500">RAAN (Ω):</span>
                <div className="text-white font-semibold">{asset.raanDeg}°</div>
              </div>

              <div>
                <span className="text-slate-500">Perigee Alt:</span>
                <div className="text-slate-300">{perigee} km</div>
              </div>

              <div>
                <span className="text-slate-500">Apogee Alt:</span>
                <div className="text-slate-300">{apogee} km</div>
              </div>

              <div>
                <span className="text-slate-500">Arg Perigee (ω):</span>
                <div className="text-slate-300">{asset.argPerigeeDeg}°</div>
              </div>
            </div>
          </div>

          {/* Enclave Protection Note */}
          <div className="flex items-center gap-2 p-2.5 rounded bg-violet-950/20 border border-violet-500/20 text-[11px] text-violet-300">
            <Shield className="w-4 h-4 text-violet-400 shrink-0" />
            <span>
              Enclave Policy: Ephemeris state vectors ingested into confidential hardware enclave for zero-leakage screening.
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between p-4 border-t border-white/10 bg-white/[0.01]">
          <button
            onClick={() => {
              onFocusAsset(asset);
              onClose();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-cyan-950/60 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-200 transition-colors"
          >
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span>Track in 3D Viewport</span>
          </button>

          <button
            onClick={() => {
              onScreenConjunction(asset);
              onClose();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-violet-600 hover:bg-violet-500 text-white font-semibold transition-colors"
          >
            <Zap className="w-3.5 h-3.5 text-violet-200" />
            <span>Screen for Conjunctions</span>
          </button>
        </div>
      </div>
    </div>
  );
};
