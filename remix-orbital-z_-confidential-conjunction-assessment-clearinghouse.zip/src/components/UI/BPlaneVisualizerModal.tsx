import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import {
  X,
  Target,
  Zap,
  ShieldCheck,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Flame,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import {
  calculateBPlaneEncounter,
  simulateAvoidanceManeuver,
} from '../../services/bPlaneService';

interface BPlaneVisualizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCommitManeuver?: (summary: string) => void;
}

export const BPlaneVisualizerModal: React.FC<BPlaneVisualizerModalProps> = ({
  isOpen,
  onClose,
  onCommitManeuver,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Maneuver Trade-Space Parameters
  const [deltaVMs, setDeltaVMs] = useState<number>(0.45);
  const [direction, setDirection] = useState<
    'OPTIMAL_ENCLAVE' | 'PROGRADE' | 'RETROGRADE' | 'RADIAL_OUT' | 'RADIAL_IN'
  >('OPTIMAL_ENCLAVE');
  const [leadTimeHours, setLeadTimeHours] = useState<number>(1.5);

  // Zoom scale for radar canvas (pixels per meter)
  const [zoomScale, setZoomScale] = useState<number>(0.42);
  const [isCommitted, setIsCommitted] = useState<boolean>(false);
  const [committedTimestamp, setCommittedTimestamp] = useState<string | null>(null);

  // Calculate encounter geometry & covariance
  const encounter = useMemo(() => calculateBPlaneEncounter(), []);

  // Calculate maneuver trade-space result
  const maneuver = useMemo(() => {
    return simulateAvoidanceManeuver(deltaVMs, direction, leadTimeHours);
  }, [deltaVMs, direction, leadTimeHours]);

  // Draw 2D B-Plane Radar Canvas
  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const cx = width / 2;
    const cy = height / 2;

    // Clear background
    ctx.fillStyle = '#06070a';
    ctx.fillRect(0, 0, width, height);

    // Range rings (meters)
    const ranges = [100, 250, 500, 750, 1000, 1500, 2000];
    ctx.lineWidth = 1;
    ctx.font = '10px "JetBrains Mono", monospace';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';

    ranges.forEach((rangeM) => {
      const radiusPx = rangeM * zoomScale;
      if (radiusPx < 8 || radiusPx > width * 0.9) return;

      ctx.beginPath();
      ctx.arc(cx, cy, radiusPx, 0, Math.PI * 2);
      ctx.strokeStyle = rangeM === 500 ? 'rgba(6, 182, 212, 0.22)' : 'rgba(255, 255, 255, 0.06)';
      ctx.setLineDash(rangeM === 500 ? [4, 4] : [2, 4]);
      ctx.stroke();
      ctx.setLineDash([]);

      // Range ring label
      ctx.fillText(`${rangeM}m`, cx + radiusPx + 3, cy - 3);
    });

    // UVW / B-Plane Cross-hair Grid Axes
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    // B*T horizontal axis
    ctx.moveTo(15, cy);
    ctx.lineTo(width - 15, cy);
    // B*R vertical axis
    ctx.moveTo(cx, 15);
    ctx.lineTo(cx, height - 15);
    ctx.stroke();

    // Axis labels
    ctx.fillStyle = '#38bdf8';
    ctx.fillText('+B·T (In-Track)', width - 90, cy - 6);
    ctx.fillText('-B·T', 15, cy - 6);
    ctx.fillText('+B·R (Radial Out)', cx + 8, 22);
    ctx.fillText('-B·R', cx + 8, height - 12);

    // 1-Sigma, 2-Sigma, 3-Sigma Position Covariance Uncertainty Ellipses
    const cov = encounter.combinedCovariance;
    const drawEllipse = (
      sigmaMultiplier: number,
      strokeStyle: string,
      fillStyle: string,
      dash: number[] = []
    ) => {
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-cov.thetaRad); // Negative for canvas screen Y inversion

      const a = cov.sigmaMajor * sigmaMultiplier * zoomScale;
      const b = cov.sigmaMinor * sigmaMultiplier * zoomScale;

      ctx.beginPath();
      ctx.ellipse(0, 0, a, b, 0, 0, Math.PI * 2);
      ctx.fillStyle = fillStyle;
      ctx.fill();
      ctx.strokeStyle = strokeStyle;
      ctx.setLineDash(dash);
      ctx.lineWidth = 1.2;
      ctx.stroke();
      ctx.restore();
    };

    // 3-Sigma Ellipse (99.7% confidence region)
    drawEllipse(3, 'rgba(244, 63, 94, 0.55)', 'rgba(244, 63, 94, 0.04)', [4, 4]);
    // 2-Sigma Ellipse (95.4% confidence region)
    drawEllipse(2, 'rgba(251, 191, 36, 0.65)', 'rgba(251, 191, 36, 0.08)');
    // 1-Sigma Ellipse (68.3% confidence region)
    drawEllipse(1, 'rgba(16, 185, 129, 0.85)', 'rgba(16, 185, 129, 0.14)');

    // Initial Secondary Object Position (#8921 Commercial Broadband)
    const initX = cx + encounter.initialMissVector.bDotT * zoomScale;
    const initY = cy - encounter.initialMissVector.bDotR * zoomScale; // Invert Y for radial

    // Collision Vector line from primary to secondary initial
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(initX, initY);
    ctx.strokeStyle = 'rgba(244, 63, 94, 0.65)';
    ctx.setLineDash([3, 3]);
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.setLineDash([]);

    // Combined Hard Body Radius (HBR) circle around secondary object
    const hbrPx = Math.max(3, encounter.hardBodyRadiusM * zoomScale);
    ctx.beginPath();
    ctx.arc(initX, initY, hbrPx, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(244, 63, 94, 0.35)';
    ctx.fill();
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Initial secondary point marker
    ctx.beginPath();
    ctx.arc(initX, initY, 5, 0, Math.PI * 2);
    ctx.fillStyle = '#fbbf24';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    ctx.fillStyle = '#fbbf24';
    ctx.font = 'bold 10px "JetBrains Mono", monospace';
    ctx.fillText('#8921 (Initial: 410m)', initX + 8, initY - 4);

    // Primary Object (#4092 Sovereign Recon) at Origin (0,0)
    ctx.beginPath();
    ctx.arc(cx, cy, 6, 0, Math.PI * 2);
    ctx.fillStyle = '#06b6d4';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 11px "JetBrains Mono", monospace';
    ctx.fillText('#4092 (Primary)', cx + 10, cy + 14);

    // If maneuver Δv > 0, draw perturbed post-burn position
    if (deltaVMs > 0) {
      // Calculate delta displacement
      const deltaT = maneuver.postMissDistanceM > encounter.initialMissDistanceM
        ? (maneuver.postMissDistanceM * 0.95 - encounter.initialMissDistanceM * 0.95)
        : 0;

      // Project perturbed relative encounter coordinates
      const postX = cx + (encounter.initialMissVector.bDotT + deltaT * 0.85) * zoomScale;
      const postY = cy - (encounter.initialMissVector.bDotR + deltaT * 0.35) * zoomScale;

      // Maneuver displacement vector (Arc / Arrow)
      ctx.beginPath();
      ctx.moveTo(initX, initY);
      ctx.lineTo(postX, postY);
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 2]);
      ctx.stroke();
      ctx.setLineDash([]);

      // Post-burn safety disc
      ctx.beginPath();
      ctx.arc(postX, postY, Math.max(4, hbrPx), 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(16, 185, 129, 0.4)';
      ctx.fill();
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Post-burn marker
      ctx.beginPath();
      ctx.arc(postX, postY, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#10b981';
      ctx.fill();

      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 10px "JetBrains Mono", monospace';
      ctx.fillText(
        `Post-Burn (${Math.round(maneuver.postMissDistanceM)}m)`,
        postX + 8,
        postY - 4
      );
    }
  }, [encounter, maneuver, deltaVMs, zoomScale]);

  useEffect(() => {
    if (isOpen) {
      drawCanvas();
    }
  }, [isOpen, drawCanvas]);

  if (!isOpen) return null;

  const handleCommit = () => {
    setIsCommitted(true);
    const nowUtc = new Date().toISOString();
    setCommittedTimestamp(nowUtc);
    if (onCommitManeuver) {
      onCommitManeuver(
        `Dispatched Enclave Avoidance Vector Δv = ${deltaVMs.toFixed(2)} m/s (${direction}) -> Post-miss: ${maneuver.postMissDistanceM.toFixed(0)}m, Pc: ${maneuver.postPc.toExponential(2)}`
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md select-none overflow-y-auto">
      <div className="w-full max-w-5xl max-h-[92vh] flex flex-col rounded-2xl border border-cyan-500/30 bg-[#08090d] shadow-2xl overflow-hidden">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-cyan-950/20">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg border border-cyan-500/40 bg-cyan-900/30 text-cyan-300">
              <Target className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                <span>In-Encounter B-Plane (Target Plane) & Maneuver Trade-Space Engine</span>
                <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  UVW FRAME
                </span>
              </div>
              <div className="text-[11px] font-mono text-slate-400">
                Asset #4092 (Sovereign Recon) vs Asset #8921 (Commercial Broadband)
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Main Body: 2-Column Aerospace Layout */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 gap-5 p-5 text-xs font-mono">
          {/* Left Column: 2D B-Plane Radar HUD (7 cols) */}
          <div className="lg:col-span-7 flex flex-col space-y-3">
            <div className="flex items-center justify-between text-[11px] text-slate-300">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400" />
                <span className="font-semibold text-white">Cross-Section Radar Target Plane</span>
                <span className="text-slate-400">(B·T vs B·R Frame)</span>
              </div>

              {/* Canvas Zoom Controls */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setZoomScale((prev) => Math.min(1.2, prev * 1.25))}
                  className="p-1 rounded bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Zoom In"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setZoomScale((prev) => Math.max(0.12, prev / 1.25))}
                  className="p-1 rounded bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setZoomScale(0.42)}
                  className="p-1 rounded bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Reset Scale"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Radar Canvas Surface */}
            <div className="relative rounded-xl border border-white/15 bg-black overflow-hidden flex items-center justify-center shadow-inner">
              <canvas
                ref={canvasRef}
                width={520}
                height={380}
                className="w-full h-auto max-h-[380px] object-contain block"
              />

              {/* Legend overlay */}
              <div className="absolute bottom-2 left-2 flex items-center gap-2.5 px-2.5 py-1 rounded bg-black/80 border border-white/10 text-[10px] text-slate-300">
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>1σ (68.3%)</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-500" />
                  <span>2σ (95.4%)</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-rose-500" />
                  <span>3σ (99.7%)</span>
                </div>
              </div>
            </div>

            {/* Covariance Matrix Spec Stream */}
            <div className="p-3 rounded-lg border border-white/10 bg-white/[0.02] space-y-1.5 text-[11px]">
              <div className="flex items-center justify-between text-slate-400">
                <span>Combined Covariance Eigenvalues:</span>
                <span className="text-white">
                  σ_major: {encounter.combinedCovariance.sigmaMajor.toFixed(1)}m · σ_minor:{' '}
                  {encounter.combinedCovariance.sigmaMinor.toFixed(1)}m (θ ={' '}
                  {encounter.combinedCovariance.thetaDeg.toFixed(1)}°)
                </span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Hard Body Collision Cross-Section:</span>
                <span className="text-cyan-300">R_HBR = {encounter.hardBodyRadiusM}m (Area ~78.5 m²)</span>
              </div>
            </div>
          </div>

          {/* Right Column: Maneuver Trade-Space Engine (5 cols) */}
          <div className="lg:col-span-5 flex flex-col space-y-4">
            {/* Encounter State Metrics */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg border border-rose-500/30 bg-rose-950/20 space-y-0.5">
                <div className="text-[10px] text-rose-300 uppercase font-semibold">Nominal Miss Distance</div>
                <div className="text-base font-bold text-rose-400 tabular-nums">
                  {encounter.initialMissDistanceM.toFixed(1)} m
                </div>
                <div className="text-[10px] text-slate-400">
                  Vector: [{encounter.initialMissVector.bDotT.toFixed(0)}, {encounter.initialMissVector.bDotR.toFixed(0)}] m
                </div>
              </div>

              <div className="p-2.5 rounded-lg border border-amber-500/30 bg-amber-950/20 space-y-0.5">
                <div className="text-[10px] text-amber-300 uppercase font-semibold">Collision Prob (Pc)</div>
                <div className="text-base font-bold text-amber-400 tabular-nums">
                  {encounter.initialPc.toExponential(3)}
                </div>
                <div className="text-[10px] text-rose-300 font-semibold">HIGH CONJUNCTION RISK</div>
              </div>
            </div>

            {/* Interactive Burn Calculator Controls */}
            <div className="p-3.5 rounded-xl border border-white/10 bg-white/[0.02] space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  <span>Interactive Micro-Thrust Delta-V</span>
                </div>
                <span className="text-cyan-300 font-bold text-sm tabular-nums">
                  Δv = {deltaVMs.toFixed(2)} m/s
                </span>
              </div>

              {/* Delta-V Slider */}
              <div className="space-y-1.5">
                <input
                  type="range"
                  min="0.01"
                  max="2.00"
                  step="0.01"
                  value={deltaVMs}
                  onChange={(e) => setDeltaVMs(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>0.01 m/s (Micro)</span>
                  <span>1.00 m/s</span>
                  <span>2.00 m/s (Max)</span>
                </div>
              </div>

              {/* Quick Preset Buttons */}
              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {[
                  { label: '0.05 m/s', val: 0.05 },
                  { label: '0.15 m/s', val: 0.15 },
                  { label: '0.45 m/s', val: 0.45, highlight: true },
                  { label: '1.00 m/s', val: 1.0 },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => setDeltaVMs(preset.val)}
                    className={`py-1 text-[10px] font-mono rounded border transition-colors cursor-pointer ${
                      deltaVMs === preset.val
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold'
                        : preset.highlight
                        ? 'bg-purple-950/40 text-purple-300 border-purple-500/30 hover:border-purple-500/60'
                        : 'bg-white/[0.03] text-slate-300 border-white/5 hover:border-white/15'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              {/* Thrust Vector Direction */}
              <div className="space-y-1.5 pt-1">
                <label className="text-[10px] text-slate-400 uppercase">Avoidance Vector Direction:</label>
                <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                  {[
                    { id: 'OPTIMAL_ENCLAVE', label: 'Enclave Optimized (Multi-Axis)' },
                    { id: 'PROGRADE', label: 'Prograde (+T Along-Track)' },
                    { id: 'RETROGRADE', label: 'Retrograde (-T)' },
                    { id: 'RADIAL_OUT', label: 'Radial-Out (+R)' },
                  ].map((dir) => (
                    <button
                      key={dir.id}
                      onClick={() => setDirection(dir.id as any)}
                      className={`p-1.5 text-left rounded border transition-colors cursor-pointer ${
                        direction === dir.id
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-semibold'
                          : 'bg-black/30 text-slate-400 border-white/5 hover:border-white/15'
                      }`}
                    >
                      {dir.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Lead Time Before Closest Approach */}
              <div className="flex items-center justify-between text-[11px] pt-1">
                <span className="text-slate-400">Burn Execution Lead Time:</span>
                <div className="flex items-center gap-1">
                  {[0.5, 1.0, 1.5, 3.0].map((hours) => (
                    <button
                      key={hours}
                      onClick={() => setLeadTimeHours(hours)}
                      className={`px-2 py-0.5 rounded text-[10px] transition-colors cursor-pointer ${
                        leadTimeHours === hours
                          ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      T-{hours}h
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Post-Maneuver Calculated Outcomes */}
            <div className="p-3.5 rounded-xl border border-emerald-500/30 bg-emerald-950/20 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wide">
                  Post-Maneuver Clearance
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  {maneuver.postPc < 1e-6 ? 'SAFE (Pc < 1e-6)' : 'CAUTION'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-400">Post-Miss Distance:</span>
                  <div className="text-sm font-bold text-white tabular-nums">
                    {maneuver.postMissDistanceM.toFixed(1)} m
                  </div>
                  <div className="text-[10px] text-emerald-400">
                    +{maneuver.safetyMarginMeters.toFixed(0)}m separation gained
                  </div>
                </div>

                <div>
                  <span className="text-slate-400">Post-Burn Pc:</span>
                  <div className="text-sm font-bold text-emerald-300 tabular-nums">
                    {maneuver.postPc.toExponential(2)}
                  </div>
                  <div className="text-[10px] text-slate-400">Target threshold: &lt; 1e-5</div>
                </div>
              </div>

              <div className="pt-1.5 border-t border-emerald-500/20 flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>Hydrazine Propellant Cost:</span>
                </div>
                <span className="font-bold text-amber-300 tabular-nums">
                  {(maneuver.fuelMassKg * 1000).toFixed(1)} g ({maneuver.fuelMassKg.toFixed(4)} kg)
                </span>
              </div>

              <div className="flex items-center gap-1.5 text-[10px] text-emerald-300 pt-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Zero Secondary Conjunctions Screened Over 72 Hours (Enclave-Verified)</span>
              </div>
            </div>

            {/* Dispatch / Commit Action */}
            <div className="pt-1">
              {!isCommitted ? (
                <button
                  onClick={handleCommit}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white font-bold text-xs shadow-lg transition-all cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Commit Avoidance Burn to Hardware Enclave</span>
                </button>
              ) : (
                <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/50 space-y-1 text-center">
                  <div className="flex items-center justify-center gap-1.5 text-emerald-400 font-bold text-xs">
                    <ShieldCheck className="w-4 h-4" />
                    <span>MANEUVER DISPATCHED TO ENCLAVE</span>
                  </div>
                  <div className="text-[10px] text-slate-300">
                    Signed by CPACF Enclave at {committedTimestamp?.slice(11, 19)} UTC. Zero ephemeris leaked.
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-white/10 bg-black/40 text-xs font-mono">
          <div className="text-[11px] text-slate-400 flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-purple-400" />
            <span>Multi-Party Enclave: Neither Operator A nor B reveals classified trajectory.</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors cursor-pointer"
          >
            Close Radar
          </button>
        </div>
      </div>
    </div>
  );
};
