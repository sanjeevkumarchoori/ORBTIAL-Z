import React, { useState } from 'react';
import {
  X,
  Wind,
  Sun,
  Flame,
  ArrowDown,
  RotateCcw,
  Zap,
  Gauge,
  Info,
  CheckCircle2,
} from 'lucide-react';
import {
  calculateAtmosphericDensity,
  ReentryWatchItem,
} from '../../services/atmosphericDrag';

interface AtmosphericDragPanelProps {
  isOpen: boolean;
  onClose: () => void;
  solarFlux: number;
  onSetSolarFlux: (flux: number) => void;
  enableDrag: boolean;
  onToggleDrag: () => void;
  reentryCount: number;
  watchlist: ReentryWatchItem[];
  onTriggerReboost: (item: ReentryWatchItem) => void;
  onResetAltitudes: () => void;
}

export const AtmosphericDragPanel: React.FC<AtmosphericDragPanelProps> = ({
  isOpen,
  onClose,
  solarFlux,
  onSetSolarFlux,
  enableDrag,
  onToggleDrag,
  reentryCount,
  watchlist,
  onTriggerReboost,
  onResetAltitudes,
}) => {
  const [selectedPreset, setSelectedPreset] = useState<'MIN' | 'MODERATE' | 'MAX'>('MODERATE');

  if (!isOpen) return null;

  const density300 = calculateAtmosphericDensity(300, solarFlux);
  const density400 = calculateAtmosphericDensity(400, solarFlux);
  const density500 = calculateAtmosphericDensity(500, solarFlux);

  const applyPreset = (preset: 'MIN' | 'MODERATE' | 'MAX') => {
    setSelectedPreset(preset);
    if (preset === 'MIN') onSetSolarFlux(72);
    if (preset === 'MODERATE') onSetSolarFlux(155);
    if (preset === 'MAX') onSetSolarFlux(240);
  };

  const getStatusBadge = (status: ReentryWatchItem['status']) => {
    switch (status) {
      case 'BURNING':
        return 'bg-rose-950/80 border-rose-500/50 text-rose-300';
      case 'CRITICAL_DECAY':
        return 'bg-amber-950/80 border-amber-500/50 text-amber-300';
      case 'STATION_KEEPING':
        return 'bg-purple-950/80 border-purple-500/50 text-purple-300';
      default:
        return 'bg-cyan-950/80 border-cyan-500/50 text-cyan-300';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-3xl max-h-[90vh] flex flex-col rounded-xl border border-cyan-500/30 bg-[#08090d] shadow-2xl overflow-hidden font-mono text-xs">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-cyan-950/20">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center w-8 h-8 rounded border border-cyan-500/40 bg-cyan-900/30 text-cyan-300">
              <Wind className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-tight">
                REAL-TIME ATMOSPHERIC DRAG & ORBITAL DECAY SIMULATOR
              </div>
              <div className="text-[11px] text-cyan-400">
                Thermospheric scale-height density with F10.7 solar radio flux scaling
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Top Control Grid: Solar Flux & Simulation Toggles */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Solar Activity & Flux Controller */}
            <div className="sm:col-span-2 p-3.5 rounded-lg border border-white/10 bg-white/[0.02] space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-amber-400 font-semibold text-[11px]">
                  <Sun className="w-3.5 h-3.5" />
                  <span>Solar Radio Flux Index (F10.7 SFU)</span>
                </div>
                <span className="text-white font-bold tabular-nums">
                  {solarFlux} SFU
                </span>
              </div>

              {/* Slider */}
              <input
                type="range"
                min="65"
                max="260"
                value={solarFlux}
                onChange={(e) => onSetSolarFlux(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />

              {/* Preset Buttons */}
              <div className="flex items-center gap-2 pt-1">
                {[
                  { id: 'MIN', label: 'Solar Min (72 SFU)' },
                  { id: 'MODERATE', label: 'Moderate Cycle (155 SFU)' },
                  { id: 'MAX', label: 'Solar Maximum (240 SFU)' },
                ].map((p) => {
                  const isSelected = selectedPreset === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => applyPreset(p.id as 'MIN' | 'MODERATE' | 'MAX')}
                      className={`flex-1 px-2 py-1 text-[10px] rounded border transition-colors cursor-pointer whitespace-nowrap ${
                        isSelected
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                          : 'bg-white/[0.03] text-slate-400 hover:text-white border-white/5'
                      }`}
                    >
                      {p.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Live Reentry Stats Card */}
            <div className="p-3.5 rounded-lg border border-rose-500/30 bg-rose-950/20 space-y-2 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 text-rose-400 text-[10px] uppercase font-semibold">
                  <Flame className="w-3.5 h-3.5" />
                  <span>Atmospheric Reentries</span>
                </div>
                <div className="text-2xl font-bold text-white tabular-nums pt-1">
                  {reentryCount} <span className="text-xs text-rose-300 font-normal">objects burned</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-rose-500/20 text-[10px]">
                <span className="text-slate-400">Simulation:</span>
                <button
                  onClick={onToggleDrag}
                  className={`px-2 py-0.5 rounded font-bold cursor-pointer transition-colors ${
                    enableDrag
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {enableDrag ? 'DRAG ACTIVE' : 'PAUSED'}
                </button>
              </div>
            </div>
          </div>

          {/* Thermospheric Density Gradient Cards */}
          <div className="grid grid-cols-3 gap-2 text-[11px]">
            <div className="p-2.5 rounded bg-white/[0.02] border border-white/10 space-y-0.5">
              <span className="text-slate-500 text-[10px] uppercase">Density at 300 km:</span>
              <div className="text-rose-400 font-bold tabular-nums">
                {density300.toExponential(3)} kg/m³
              </div>
              <div className="text-[10px] text-slate-400">Severe drag regime</div>
            </div>

            <div className="p-2.5 rounded bg-white/[0.02] border border-white/10 space-y-0.5">
              <span className="text-slate-500 text-[10px] uppercase">Density at 400 km (ISS):</span>
              <div className="text-amber-300 font-bold tabular-nums">
                {density400.toExponential(3)} kg/m³
              </div>
              <div className="text-[10px] text-slate-400">Periodic re-boost required</div>
            </div>

            <div className="p-2.5 rounded bg-white/[0.02] border border-white/10 space-y-0.5">
              <span className="text-slate-500 text-[10px] uppercase">Density at 500 km:</span>
              <div className="text-cyan-300 font-bold tabular-nums">
                {density500.toExponential(3)} kg/m³
              </div>
              <div className="text-[10px] text-slate-400">Extended 5–15 yr lifetime</div>
            </div>
          </div>

          {/* Reentry Watchlist Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <div className="flex items-center gap-1.5 text-slate-200 font-semibold">
                <Gauge className="w-3.5 h-3.5 text-cyan-400" />
                <span>Monitored Objects Reentry Watchlist & Decay Tracker</span>
              </div>
              <button
                onClick={onResetAltitudes}
                className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Altitudes</span>
              </button>
            </div>

            <div className="space-y-2">
              {watchlist.map((item) => {
                return (
                  <div
                    key={item.id}
                    className="p-3 rounded-lg border border-white/10 bg-white/[0.02] hover:bg-white/[0.04] transition-colors"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <ArrowDown className="w-3.5 h-3.5 text-rose-400" />
                        <span className="font-bold text-white text-xs">{item.name}</span>
                        <span className="text-[10px] text-slate-500">({item.orbitClass})</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] border font-semibold uppercase ${getStatusBadge(
                            item.status
                          )}`}
                        >
                          {item.status.replace('_', ' ')}
                        </span>

                        {item.status === 'STATION_KEEPING' && (
                          <button
                            onClick={() => onTriggerReboost(item)}
                            className="flex items-center gap-1 px-2 py-0.5 rounded bg-purple-600 hover:bg-purple-500 text-white font-semibold text-[10px] transition-colors cursor-pointer"
                            title="Fire Virtual Station-Keeping Thruster"
                          >
                            <Zap className="w-3 h-3" />
                            <span>Re-Boost</span>
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2 pt-2 border-t border-white/5 text-[11px]">
                      <div>
                        <span className="text-slate-500 text-[10px] uppercase">Current Alt:</span>
                        <div className="text-white font-bold tabular-nums">
                          {item.altitudeKm.toFixed(2)} km
                        </div>
                      </div>

                      <div>
                        <span className="text-slate-500 text-[10px] uppercase">Decay Speed:</span>
                        <div className="text-rose-400 font-bold tabular-nums">
                          -{item.decayRateMetersPerDay.toFixed(1)} m/day
                        </div>
                      </div>

                      <div>
                        <span className="text-slate-500 text-[10px] uppercase">Ballistic Coeff (B*):</span>
                        <div className="text-slate-300 font-mono">
                          {item.ballisticCoeff.toFixed(4)} m²/kg
                        </div>
                      </div>

                      <div>
                        <span className="text-slate-500 text-[10px] uppercase">Est. Reentry:</span>
                        <div className="text-amber-300 font-bold tabular-nums">
                          ~{Math.round(item.estimatedDaysToReentry).toLocaleString()} days
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-white/10 bg-[#030305] text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Physics Core: Barometric Scale-Height Decay Active</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-semibold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
