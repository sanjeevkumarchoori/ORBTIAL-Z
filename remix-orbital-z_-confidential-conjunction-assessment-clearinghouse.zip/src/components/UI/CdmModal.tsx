import React, { useState } from 'react';
import { X, FileText, Check, Copy, RefreshCw, AlertCircle } from 'lucide-react';
import { SAMPLE_CDM_RAW, parseCdmText } from '../../services/cdmParser';

interface CdmModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CdmModal: React.FC<CdmModalProps> = ({ isOpen, onClose }) => {
  const [cdmText, setCdmText] = useState(SAMPLE_CDM_RAW);
  const [copied, setCopied] = useState(false);
  const [parsed, setParsed] = useState(() => parseCdmText(SAMPLE_CDM_RAW));

  if (!isOpen) return null;

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    setCdmText(text);
    try {
      setParsed(parseCdmText(text));
    } catch (err) {
      console.error(err);
    }
  };

  const copyCdm = () => {
    navigator.clipboard.writeText(cdmText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const resetDefault = () => {
    setCdmText(SAMPLE_CDM_RAW);
    setParsed(parseCdmText(SAMPLE_CDM_RAW));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-3xl max-h-[90vh] flex flex-col rounded-xl border border-amber-500/30 bg-[#08090d] shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-amber-950/20">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center w-8 h-8 rounded border border-amber-500/40 bg-amber-900/30 text-amber-300">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold text-white tracking-tight">
                CCSDS Conjunction Data Message (CDM) Parser
              </div>
              <div className="text-[11px] font-mono text-amber-400">
                Space-Track / ESA DISCOS Compliant Format
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs font-mono">
          {/* Parsed Overview Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-2.5 rounded bg-white/[0.02] border border-white/10 space-y-0.5">
              <div className="text-[10px] text-slate-400 uppercase">Miss Distance</div>
              <div className="text-base font-bold text-rose-400 tabular-nums">
                {parsed.missDistanceM.toFixed(1)} m
              </div>
            </div>

            <div className="p-2.5 rounded bg-white/[0.02] border border-white/10 space-y-0.5">
              <div className="text-[10px] text-slate-400 uppercase">Relative Speed</div>
              <div className="text-base font-bold text-cyan-300 tabular-nums">
                {(parsed.relativeSpeedKms * 1000).toFixed(0)} m/s
              </div>
            </div>

            <div className="p-2.5 rounded bg-white/[0.02] border border-white/10 space-y-0.5">
              <div className="text-[10px] text-slate-400 uppercase">Collision Prob (Pc)</div>
              <div className="text-base font-bold text-amber-300 tabular-nums">
                {parsed.collisionProbability.toExponential(3)}
              </div>
            </div>

            <div className="p-2.5 rounded bg-white/[0.02] border border-white/10 space-y-0.5">
              <div className="text-[10px] text-slate-400 uppercase">Originator</div>
              <div className="text-xs font-bold text-purple-300 truncate">
                ORBITAL-Z
              </div>
            </div>
          </div>

          {/* Covariance RTN Comparison */}
          <div className="p-3 rounded-lg border border-white/10 bg-white/[0.02] space-y-2">
            <div className="text-[11px] font-semibold text-slate-300">
              Covariance Matrix Standard Deviation (Radial, In-track, Cross-track)
            </div>
            <div className="grid grid-cols-2 gap-3 text-[11px]">
              <div>
                <span className="text-rose-400">Object 1 ({parsed.primaryObject.name}):</span>
                <div className="text-slate-400 pl-2">
                  σR: 18.4m · σT: 42.1m · σN: 8.2m
                </div>
              </div>
              <div>
                <span className="text-amber-400">Object 2 ({parsed.secondaryObject.name}):</span>
                <div className="text-slate-400 pl-2">
                  σR: 24.2m · σT: 65.8m · σN: 11.5m
                </div>
              </div>
            </div>
          </div>

          {/* Raw CDM Telemetry Editor & Inspector */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>Raw Conjunction Data Stream (Editable Telemetry Feed)</span>
              </span>
              <button
                onClick={resetDefault}
                className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Reset Sample</span>
              </button>
            </div>

            <textarea
              value={cdmText}
              onChange={handleTextChange}
              rows={12}
              className="w-full p-3 rounded-lg bg-black/60 border border-white/15 text-[11px] font-mono text-slate-200 focus:outline-none focus:border-amber-500/50 resize-y leading-relaxed"
            />
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-white/10 bg-black/40">
          <div className="text-[11px] font-mono text-slate-400">
            Message Status: <span className="text-emerald-400 font-semibold">SYNCHRONIZED</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyCdm}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-white/10 rounded transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy CDM'}</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
