import React, { useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Globe2,
  Orbit,
  Radio,
  Sun,
  Layers,
  Camera,
  Play,
  Pause,
  Compass,
  Flame,
  Activity,
  Wind,
  Gauge,
  Clock,
  FastForward,
} from 'lucide-react';
import { SceneToggles, CameraPreset } from '../Earth3D/Earth3DScene';
import { GeodeticCoords } from '../../types/orbital';

interface ControlConsoleProps {
  toggles: SceneToggles;
  onUpdateToggles: (updater: (prev: SceneToggles) => SceneToggles) => void;
  cameraPreset: CameraPreset;
  onSelectPreset: (preset: CameraPreset) => void;
  timeSpeed: number;
  onSetTimeSpeed: (speed: number) => void;
  simulatedHoursOffset?: number;
  onSetSimulatedHoursOffset?: (hours: number) => void;
  issTelemetry: GeodeticCoords;
  sunAngleDeg: number;
  onOpenRiskPanel?: () => void;
  onOpenDragPanel?: () => void;
  onOpenBPlane?: () => void;
  solarFlux?: number;
  geomagneticKp?: number;
  reentryCount?: number;
}

export const ControlConsole: React.FC<ControlConsoleProps> = ({
  toggles,
  onUpdateToggles,
  cameraPreset,
  onSelectPreset,
  timeSpeed,
  onSetTimeSpeed,
  simulatedHoursOffset = 0,
  onSetSimulatedHoursOffset,
  issTelemetry,
  sunAngleDeg,
  onOpenRiskPanel,
  onOpenDragPanel,
  onOpenBPlane,
  solarFlux = 155,
  geomagneticKp = 3.2,
  reentryCount = 0,
}) => {
  const [collapsed, setCollapsed] = useState(false);
  const [timelineHours, setTimelineHours] = useState(simulatedHoursOffset);

  const toggleLayer = (key: keyof SceneToggles) => {
    onUpdateToggles((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleTimelineScrub = (hours: number) => {
    setTimelineHours(hours);
    if (onSetSimulatedHoursOffset) {
      onSetSimulatedHoursOffset(hours);
    }
  };

  const formatOffsetLabel = (hours: number) => {
    if (Math.abs(hours) < 0.05) return 'TCA (T=0)';
    const sign = hours > 0 ? '+' : '-';
    const absH = Math.abs(hours);
    const h = Math.floor(absH);
    const m = Math.round((absH - h) * 60);
    return `T${sign}${h}h ${m > 0 ? `${m}m` : ''}`;
  };

  return (
    <div className="fixed bottom-2 sm:bottom-3 left-1/2 -translate-x-1/2 z-20 w-[96vw] max-w-5xl select-none transition-transform duration-300 pointer-events-auto">
      {/* Collapse / Expand Tab Button */}
      <div className="flex justify-center -mb-px">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center gap-1.5 px-3 py-1 text-[11px] font-mono text-slate-400 hover:text-white bg-[#08090d]/95 border-t border-x border-white/10 rounded-t-lg shadow-lg transition-colors cursor-pointer"
        >
          {collapsed ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          <span>{collapsed ? 'Expand Mission Command Console' : 'Hide Console'}</span>
        </button>
      </div>

      {/* Main Console Box */}
      {!collapsed && (
        <div className="p-3 sm:p-4 rounded-2xl border border-white/10 bg-[#08090d]/95 shadow-2xl space-y-3 backdrop-blur-md">
          {/* Row 1: Camera Presets & Time Speed Stepper */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-2.5 border-b border-white/10 text-xs font-mono">
            {/* Camera View Presets */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="flex items-center gap-1 text-[11px] text-slate-400 mr-1">
                <Camera className="w-3.5 h-3.5 text-cyan-400" />
                <span>Camera:</span>
              </span>

              {[
                { id: 'GLOBAL', label: 'Global View' },
                { id: 'CONJUNCTION', label: 'Conjunction Zoom' },
                { id: 'GEO', label: 'Geostationary Belt' },
                { id: 'POLAR', label: 'Polar Trajectory' },
                { id: 'ISS', label: 'ISS Live Track' },
              ].map((p) => {
                const isActive = cameraPreset === p.id;
                return (
                  <button
                    key={p.id}
                    onClick={() => onSelectPreset(p.id as CameraPreset)}
                    className={`px-2.5 py-1 text-[11px] font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                      isActive
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                        : 'bg-white/[0.04] text-slate-300 hover:text-white border border-transparent hover:border-white/10'
                    }`}
                  >
                    {p.label}
                  </button>
                );
              })}
            </div>

            {/* Time Warp Speed Multipliers */}
            <div className="flex items-center gap-1 bg-white/[0.03] p-1 rounded-lg border border-white/10">
              <span className="text-[10px] text-slate-400 px-1.5 uppercase flex items-center gap-1">
                <FastForward className="w-3 h-3 text-purple-400" />
                <span>Rate:</span>
              </span>
              {[
                { speed: 0, label: 'Pause', icon: Pause },
                { speed: 1, label: '1x (Live)' },
                { speed: 60, label: '60x (Min)' },
                { speed: 3600, label: '3600x (Hr)' },
              ].map((t) => {
                const isSelected = timeSpeed === t.speed;
                return (
                  <button
                    key={t.speed}
                    onClick={() => onSetTimeSpeed(t.speed)}
                    className={`px-2 py-0.5 text-[11px] font-mono rounded transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-purple-600 text-white font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {t.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Row 2: Interactive Timeline & Pass Schedule Scrubber (T ± 72 hours) */}
          <div className="p-2 rounded-xl bg-white/[0.02] border border-white/10 space-y-1.5 font-mono text-[11px]">
            <div className="flex items-center justify-between text-slate-300">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-white font-semibold">Mission Timeline Scrubber (T ± 72h):</span>
                <span className="text-cyan-300 font-bold ml-1">
                  {formatOffsetLabel(timelineHours)}
                </span>
              </div>

              {/* Quick Jump Buttons */}
              <div className="flex items-center gap-1 flex-wrap">
                {[
                  { label: 'T-72h', h: -72 },
                  { label: 'T-24h', h: -24 },
                  { label: 'T-1h', h: -1 },
                  { label: 'TCA (0h)', h: 0, highlight: true },
                  { label: 'T+24h', h: 24 },
                  { label: 'T+72h', h: 72 },
                ].map((marker) => (
                  <button
                    key={marker.label}
                    onClick={() => handleTimelineScrub(marker.h)}
                    className={`px-1.5 py-0.5 text-[10px] rounded transition-colors cursor-pointer ${
                      Math.abs(timelineHours - marker.h) < 0.2
                        ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400/50 font-bold'
                        : marker.highlight
                        ? 'bg-rose-950/40 text-rose-300 border border-rose-500/30 hover:border-rose-500/50'
                        : 'text-slate-400 hover:text-white bg-white/[0.02]'
                    }`}
                  >
                    {marker.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Slider track */}
            <div className="px-1">
              <input
                type="range"
                min="-72"
                max="72"
                step="0.25"
                value={timelineHours}
                onChange={(e) => handleTimelineScrub(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-slate-400 pt-0.5">
                <span>-72h (Ingestion)</span>
                <span>-24h</span>
                <span className="text-rose-400 font-bold">TCA Close Encounter</span>
                <span>+24h</span>
                <span>+72h (Clearance Verified)</span>
              </div>
            </div>
          </div>

          {/* Row 3: Layer Toggles & Modal Launchers */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="flex items-center gap-1 text-[11px] font-mono text-slate-400 mr-1">
              <Layers className="w-3.5 h-3.5 text-purple-400" />
              <span>Layers:</span>
            </span>

            {[
              { key: 'showOrbits', label: 'Orbital Paths', icon: Orbit, active: toggles.showOrbits },
              { key: 'showDebris', label: 'Debris Field (12k+)', icon: Globe2, active: toggles.showDebris },
              { key: 'showRiskHeatmap', label: 'Risk Heatmap', icon: Flame, active: toggles.showRiskHeatmap },
              { key: 'showLaserLinks', label: 'Laser Crosslinks', icon: Radio, active: toggles.showLaserLinks },
              { key: 'showDayNight', label: 'Day/Night Terminator', icon: Sun, active: toggles.showDayNight },
              { key: 'showGroundStations', label: 'Ground Stations', icon: Compass, active: toggles.showGroundStations },
              { key: 'showAtmosphere', label: 'Atmospheric Rim', icon: Wind, active: toggles.showAtmosphere },
            ].map((layer) => {
              return (
                <button
                  key={layer.key}
                  onClick={() => toggleLayer(layer.key as keyof SceneToggles)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
                    layer.active
                      ? layer.key === 'showRiskHeatmap'
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                        : 'bg-white/[0.08] text-slate-100 border-cyan-500/40'
                      : 'bg-black/20 text-slate-400 border-white/5 hover:border-white/10 opacity-70'
                  }`}
                >
                  <layer.icon
                    className={`w-3 h-3 ${
                      layer.active
                        ? layer.key === 'showRiskHeatmap'
                          ? 'text-rose-400'
                          : 'text-cyan-400'
                        : 'text-slate-400'
                    }`}
                  />
                  <span>{layer.label}</span>
                </button>
              );
            })}

            {/* Quick Modals Launchers */}
            <div className="flex items-center gap-1.5 ml-auto flex-wrap">
              {onOpenBPlane && (
                <button
                  onClick={onOpenBPlane}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono rounded-lg border border-cyan-500/40 bg-cyan-950/40 hover:bg-cyan-900/60 text-cyan-300 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
                  title="Open B-Plane Radar & Maneuver Trade-Space"
                >
                  <Gauge className="w-3 h-3 text-cyan-400" />
                  <span>B-Plane Radar</span>
                </button>
              )}

              {onOpenDragPanel && (
                <button
                  onClick={onOpenDragPanel}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono rounded-lg border border-purple-500/40 bg-purple-950/40 hover:bg-purple-900/60 text-purple-300 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
                  title="Real-Time Atmospheric Drag & Decay Simulator"
                >
                  <Wind className="w-3 h-3 text-purple-400" />
                  <span>Solar Drag ({solarFlux} SFU)</span>
                </button>
              )}

              {onOpenRiskPanel && (
                <button
                  onClick={onOpenRiskPanel}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono rounded-lg border border-rose-500/40 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
                  title="Open D3 Spatial Risk Corridor Analysis"
                >
                  <Activity className="w-3 h-3 text-rose-400" />
                  <span>Risk Corridors (D3)</span>
                </button>
              )}
            </div>
          </div>

          {/* Row 4: Real-Time Telemetry Stream Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-white/10 text-[11px] font-mono text-slate-400">
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 uppercase">Sub-Sat (ISS):</span>
                <span className="text-white tabular-nums">
                  {issTelemetry.latitude >= 0 ? '+' : ''}
                  {issTelemetry.latitude.toFixed(2)}° / {issTelemetry.longitude >= 0 ? '+' : ''}
                  {issTelemetry.longitude.toFixed(2)}°
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 uppercase">Alt:</span>
                <span className="text-cyan-300 tabular-nums">
                  {issTelemetry.altitudeKm.toFixed(1)} km
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 uppercase">Ground Speed:</span>
                <span className="text-emerald-400 tabular-nums">
                  7.66 km/s (27,576 km/h)
                </span>
              </div>
            </div>

            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 uppercase">Solar Flux:</span>
                <span className="text-amber-300 tabular-nums font-semibold">
                  F10.7: {solarFlux} SFU
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 uppercase">Geomagnetic Kp:</span>
                <span className="text-cyan-300 tabular-nums font-semibold">
                  {geomagneticKp.toFixed(1)} (Quiet/Active)
                </span>
              </div>

              <div className="flex items-center gap-1.5 text-purple-300">
                <span className="text-slate-400 uppercase">Enclave Root:</span>
                <span className="text-purple-300 tabular-nums">
                  0x7e84f...c9a0 (Certified)
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
