import * as THREE from 'three';
import { GROUND_STATIONS } from '../../services/propagator';

export class OpticalLaserLinks {
  public group: THREE.Group;
  private linkCurves: THREE.CatmullRomCurve3[] = [];
  private pulsePoints: THREE.Points;
  private pulseGeometry: THREE.BufferGeometry;
  private numPulsesPerLink = 8;
  private earthRadius3D: number;

  constructor(earthRadius3D: number = 10.0) {
    this.earthRadius3D = earthRadius3D;
    this.group = new THREE.Group();

    // Convert lat/lon to 3D Cartesian coordinates
    const latLonToVec3 = (latDeg: number, lonDeg: number, radius: number): THREE.Vector3 => {
      const phi = (90 - latDeg) * (Math.PI / 180);
      const theta = (lonDeg + 180) * (Math.PI / 180);
      const x = -radius * Math.sin(phi) * Math.cos(theta);
      const z = radius * Math.sin(phi) * Math.sin(theta);
      const y = radius * Math.cos(phi);
      return new THREE.Vector3(x, y, z);
    };

    // Ground station pins and target overhead nodes
    GROUND_STATIONS.forEach((gs, i) => {
      const groundPos = latLonToVec3(gs.lat, gs.lon, earthRadius3D * 1.002);
      
      // Pin marker
      const pinGeom = new THREE.CylinderGeometry(0.04, 0.01, 0.25, 8);
      pinGeom.rotateX(Math.PI / 2);
      const pinMat = new THREE.MeshBasicMaterial({ color: 0x8b5cf6 }); // Cryptographic Violet
      const pinMesh = new THREE.Mesh(pinGeom, pinMat);
      pinMesh.position.copy(groundPos);
      pinMesh.lookAt(0, 0, 0);
      this.group.add(pinMesh);

      // Target satellite orbital node (LEO / GEO optical relay)
      const targetRadius = i % 2 === 0 ? earthRadius3D * 1.15 : earthRadius3D * 1.25;
      const targetPos = latLonToVec3(gs.lat + (i % 2 === 0 ? 12 : -15), gs.lon + (i * 25), targetRadius);

      // Spline curve for optical laser crosslink
      const midPos = new THREE.Vector3().addVectors(groundPos, targetPos).multiplyScalar(0.5);
      midPos.multiplyScalar(1.08); // Arched arc

      const curve = new THREE.CatmullRomCurve3([groundPos, midPos, targetPos]);
      this.linkCurves.push(curve);

      // Render static hairline laser guide beam
      const points = curve.getPoints(50);
      const lineGeom = new THREE.BufferGeometry().setFromPoints(points);
      const lineMat = new THREE.LineBasicMaterial({
        color: 0x8b5cf6,
        transparent: true,
        opacity: 0.35,
      });
      const line = new THREE.Line(lineGeom, lineMat);
      this.group.add(line);
    });

    // Animated photon pulse points
    const totalPulses = this.linkCurves.length * this.numPulsesPerLink;
    const pulsePositions = new Float32Array(totalPulses * 3);
    const pulseColors = new Float32Array(totalPulses * 3);

    for (let i = 0; i < totalPulses; i++) {
      pulsePositions[i * 3] = 0;
      pulsePositions[i * 3 + 1] = 0;
      pulsePositions[i * 3 + 2] = 0;

      // Cyan to Violet photon gradient
      pulseColors[i * 3] = 0.54;     // R
      pulseColors[i * 3 + 1] = 0.36; // G
      pulseColors[i * 3 + 2] = 0.96; // B
    }

    this.pulseGeometry = new THREE.BufferGeometry();
    this.pulseGeometry.setAttribute('position', new THREE.BufferAttribute(pulsePositions, 3));
    this.pulseGeometry.setAttribute('color', new THREE.BufferAttribute(pulseColors, 3));

    const pulseMaterial = new THREE.PointsMaterial({
      size: 0.12,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });

    this.pulsePoints = new THREE.Points(this.pulseGeometry, pulseMaterial);
    this.group.add(this.pulsePoints);
  }

  public update(elapsedSec: number) {
    const positions = this.pulseGeometry.attributes.position.array as Float32Array;
    let idx = 0;

    for (let c = 0; c < this.linkCurves.length; c++) {
      const curve = this.linkCurves[c];
      for (let p = 0; p < this.numPulsesPerLink; p++) {
        // Photon progression along the laser spline
        const speed = 0.45;
        const offset = p / this.numPulsesPerLink;
        const progress = ((elapsedSec * speed + offset) % 1.0);

        const point = curve.getPoint(progress);
        positions[idx * 3] = point.x;
        positions[idx * 3 + 1] = point.y;
        positions[idx * 3 + 2] = point.z;
        idx++;
      }
    }

    this.pulseGeometry.attributes.position.needsUpdate = true;
  }

  public dispose() {
    this.pulseGeometry.dispose();
    (this.pulsePoints.material as THREE.Material).dispose();
  }
}
