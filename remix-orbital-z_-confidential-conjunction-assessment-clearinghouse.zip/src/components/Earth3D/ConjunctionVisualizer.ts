import * as THREE from 'three';
import { OrbitalAsset, Vector3D } from '../../types/orbital';
import { propagateKeplerian, EARTH_RADIUS_KM } from '../../services/propagator';

export class ConjunctionVisualizer {
  public group: THREE.Group;
  private asset1Mesh: THREE.Mesh;
  private asset2Mesh: THREE.Mesh;
  private vectorLine: THREE.Line;
  private ellipsoidMesh: THREE.Mesh;
  private cone1Mesh: THREE.Mesh;
  private cone2Mesh: THREE.Mesh;
  private vectorGeometry: THREE.BufferGeometry;
  private vectorMaterial: THREE.LineBasicMaterial;
  private earthRadius3D: number;

  constructor(earthRadius3D: number = 10.0) {
    this.earthRadius3D = earthRadius3D;
    this.group = new THREE.Group();

    // 1. Asset #4092 (Sovereign Recon - Rose)
    const geom1 = new THREE.SphereGeometry(0.12, 16, 16);
    const mat1 = new THREE.MeshBasicMaterial({ color: 0xf43f5e });
    this.asset1Mesh = new THREE.Mesh(geom1, mat1);
    this.group.add(this.asset1Mesh);

    // 2. Asset #8921 (Commercial Broadband - Amber)
    const geom2 = new THREE.SphereGeometry(0.12, 16, 16);
    const mat2 = new THREE.MeshBasicMaterial({ color: 0xfbbf24 });
    this.asset2Mesh = new THREE.Mesh(geom2, mat2);
    this.group.add(this.asset2Mesh);

    // 3. Collision Vector Line (Miss Distance)
    this.vectorGeometry = new THREE.BufferGeometry();
    const positions = new Float32Array([0, 0, 0, 0, 0, 0]);
    this.vectorGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.vectorMaterial = new THREE.LineBasicMaterial({
      color: 0xf43f5e,
      linewidth: 2,
      transparent: true,
      opacity: 0.95,
    });
    this.vectorLine = new THREE.Line(this.vectorGeometry, this.vectorMaterial);
    this.group.add(this.vectorLine);

    // 4. 3D Bounding Safety Ellipsoid (Covariance B-Plane)
    const ellipsoidGeom = new THREE.SphereGeometry(0.35, 24, 24);
    ellipsoidGeom.scale(1.8, 0.7, 0.5); // RTN covariance scale
    const ellipsoidMat = new THREE.MeshBasicMaterial({
      color: 0xf43f5e,
      wireframe: true,
      transparent: true,
      opacity: 0.35,
    });
    this.ellipsoidMesh = new THREE.Mesh(ellipsoidGeom, ellipsoidMat);
    this.group.add(this.ellipsoidMesh);

    // 5. Animated Laser-like Interception Warning Cones
    const coneGeom = new THREE.ConeGeometry(0.16, 0.65, 16, 1, true);
    const coneMat = new THREE.MeshBasicMaterial({
      color: 0xf43f5e,
      wireframe: true,
      transparent: true,
      opacity: 0.4,
    });
    this.cone1Mesh = new THREE.Mesh(coneGeom, coneMat);
    this.cone2Mesh = new THREE.Mesh(coneGeom, coneMat.clone());
    this.group.add(this.cone1Mesh);
    this.group.add(this.cone2Mesh);
  }

  public update(asset1: OrbitalAsset, asset2: OrbitalAsset, elapsedSec: number, timeMultiplier: number = 1.0) {
    const scale = this.earthRadius3D / EARTH_RADIUS_KM;

    // Propagate positions
    const pos1 = propagateKeplerian(asset1, elapsedSec * timeMultiplier);
    const pos2 = propagateKeplerian(asset2, elapsedSec * timeMultiplier);

    const v1 = new THREE.Vector3(
      pos1.positionEci.x * scale,
      pos1.positionEci.y * scale,
      pos1.positionEci.z * scale
    );
    const v2 = new THREE.Vector3(
      pos2.positionEci.x * scale,
      pos2.positionEci.y * scale,
      pos2.positionEci.z * scale
    );

    this.asset1Mesh.position.copy(v1);
    this.asset2Mesh.position.copy(v2);

    // Update collision vector line
    const positions = this.vectorGeometry.attributes.position.array as Float32Array;
    positions[0] = v1.x;
    positions[1] = v1.y;
    positions[2] = v1.z;
    positions[3] = v2.x;
    positions[4] = v2.y;
    positions[5] = v2.z;
    this.vectorGeometry.attributes.position.needsUpdate = true;

    // Position safety ellipsoid at mid-point
    const midPoint = new THREE.Vector3().addVectors(v1, v2).multiplyScalar(0.5);
    this.ellipsoidMesh.position.copy(midPoint);
    this.ellipsoidMesh.lookAt(v2);

    // Point warning cones toward each other
    this.cone1Mesh.position.copy(v1);
    this.cone1Mesh.lookAt(v2);
    this.cone1Mesh.rotateX(Math.PI / 2);

    this.cone2Mesh.position.copy(v2);
    this.cone2Mesh.lookAt(v1);
    this.cone2Mesh.rotateX(Math.PI / 2);

    // Subtle sinusoidal opacity pulsation on warning cones
    const pulse = 0.35 + Math.sin(elapsedSec * 6.0) * 0.25;
    (this.ellipsoidMesh.material as THREE.MeshBasicMaterial).opacity = pulse * 0.8;
    (this.cone1Mesh.material as THREE.MeshBasicMaterial).opacity = pulse;
    (this.cone2Mesh.material as THREE.MeshBasicMaterial).opacity = pulse;
  }

  public getConjunctionCenter(): THREE.Vector3 {
    return this.ellipsoidMesh.position.clone();
  }

  public dispose() {
    this.asset1Mesh.geometry.dispose();
    this.asset2Mesh.geometry.dispose();
    this.vectorGeometry.dispose();
    this.vectorMaterial.dispose();
    this.ellipsoidMesh.geometry.dispose();
    (this.ellipsoidMesh.material as THREE.Material).dispose();
    this.cone1Mesh.geometry.dispose();
    (this.cone1Mesh.material as THREE.Material).dispose();
    this.cone2Mesh.geometry.dispose();
    (this.cone2Mesh.material as THREE.Material).dispose();
  }
}
