import * as THREE from 'three';
import { OrbitalAsset } from '../../types/orbital';
import { EARTH_RADIUS_KM, propagateKeplerian } from '../../services/propagator';

export class OrbitalRings {
  public group: THREE.Group;
  private ringObjects: THREE.Line[] = [];
  private earthRadius3D: number;

  constructor(earthRadius3D: number = 10.0) {
    this.earthRadius3D = earthRadius3D;
    this.group = new THREE.Group();

    // 1. GEO Geostationary Equatorial Belt Ring (at 35,786 km -> ~6.61 * Earth Radius)
    const geoRadius = earthRadius3D * (1 + 35786 / EARTH_RADIUS_KM);
    const geoPoints: THREE.Vector3[] = [];
    const segments = 128;
    for (let i = 0; i <= segments; i++) {
      const theta = (i / segments) * Math.PI * 2;
      geoPoints.push(new THREE.Vector3(geoRadius * Math.cos(theta), 0, geoRadius * Math.sin(theta)));
    }
    const geoGeom = new THREE.BufferGeometry().setFromPoints(geoPoints);
    const geoMat = new THREE.LineBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.25,
      linewidth: 1,
    });
    const geoLine = new THREE.Line(geoGeom, geoMat);
    this.group.add(geoLine);
    this.ringObjects.push(geoLine);

    // 2. MEO GPS Inclined Belts (55° inclination, ~20,200 km -> ~4.16 * Earth Radius)
    const meoRadius = earthRadius3D * (1 + 20180 / EARTH_RADIUS_KM);
    [0, 60, 120, 180, 240, 300].forEach((raanDeg) => {
      const meoPoints: THREE.Vector3[] = [];
      const raanRad = (raanDeg * Math.PI) / 180;
      const incRad = (55 * Math.PI) / 180;

      for (let i = 0; i <= 96; i++) {
        const u = (i / 96) * Math.PI * 2;
        const xOrb = meoRadius * Math.cos(u);
        const yOrb = meoRadius * Math.sin(u);

        const cosO = Math.cos(raanRad);
        const sinO = Math.sin(raanRad);
        const cosI = Math.cos(incRad);
        const sinI = Math.sin(incRad);

        const x = cosO * xOrb - sinO * yOrb * cosI;
        const y = sinI * yOrb;
        const z = sinO * xOrb + cosO * yOrb * cosI;
        meoPoints.push(new THREE.Vector3(x, y, z));
      }

      const meoGeom = new THREE.BufferGeometry().setFromPoints(meoPoints);
      const meoMat = new THREE.LineBasicMaterial({
        color: 0x8b5cf6,
        transparent: true,
        opacity: 0.18,
      });
      const meoLine = new THREE.Line(meoGeom, meoMat);
      this.group.add(meoLine);
      this.ringObjects.push(meoLine);
    });

    // 3. LEO Characteristic Reference Rings (400km, 550km, 800km shells)
    const leoAltitudes = [
      { alt: 420, color: 0x06b6d4, opacity: 0.22 }, // ISS shell
      { alt: 550, color: 0x10b981, opacity: 0.25 }, // Broadband constellation shell
      { alt: 800, color: 0xfbbf24, opacity: 0.20 }, // Sun-synchronous debris shell
    ];

    leoAltitudes.forEach((shell) => {
      const leoRadius = earthRadius3D * (1 + shell.alt / EARTH_RADIUS_KM);
      const leoPoints: THREE.Vector3[] = [];
      const segments = 120;
      for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * Math.PI * 2;
        leoPoints.push(new THREE.Vector3(leoRadius * Math.cos(theta), 0, leoRadius * Math.sin(theta)));
      }
      const leoGeom = new THREE.BufferGeometry().setFromPoints(leoPoints);
      const leoMat = new THREE.LineBasicMaterial({
        color: shell.color,
        transparent: true,
        opacity: shell.opacity,
      });
      const leoLine = new THREE.Line(leoGeom, leoMat);
      this.group.add(leoLine);
      this.ringObjects.push(leoLine);
    });
  }

  public addAssetOrbit(asset: OrbitalAsset, colorHex: number, opacity: number = 0.5): THREE.Line {
    const scale = this.earthRadius3D / EARTH_RADIUS_KM;
    const points: THREE.Vector3[] = [];
    const segments = 120;

    for (let i = 0; i <= segments; i++) {
      const frac = i / segments;
      const fakeSeconds = frac * asset.periodMinutes * 60;
      const prop = propagateKeplerian(asset, fakeSeconds);
      points.push(
        new THREE.Vector3(
          prop.positionEci.x * scale,
          prop.positionEci.y * scale,
          prop.positionEci.z * scale
        )
      );
    }

    const geom = new THREE.BufferGeometry().setFromPoints(points);
    const mat = new THREE.LineBasicMaterial({
      color: colorHex,
      transparent: true,
      opacity,
      linewidth: 1,
    });
    const line = new THREE.Line(geom, mat);
    this.group.add(line);
    this.ringObjects.push(line);
    return line;
  }

  public setVisibility(visible: boolean) {
    this.group.visible = visible;
  }

  public dispose() {
    this.ringObjects.forEach((ring) => {
      ring.geometry.dispose();
      (ring.material as THREE.Material).dispose();
    });
  }
}
