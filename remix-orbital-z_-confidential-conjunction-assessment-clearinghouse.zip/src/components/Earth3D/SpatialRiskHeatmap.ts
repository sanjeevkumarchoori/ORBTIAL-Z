import * as THREE from 'three';
import * as d3 from 'd3';
import { EARTH_RADIUS_KM } from '../../services/propagator';

export interface ConjunctionCorridor {
  id: string;
  name: string;
  altitudeKm: number;
  thicknessKm: number;
  riskLevel: 'CRITICAL' | 'HIGH' | 'MODERATE' | 'LOW';
  densityScore: number; // 0 to 100
  trackedObjects: number;
  colorHex: string;
}

export const CORRIDORS: ConjunctionCorridor[] = [
  {
    id: 'corridor-leo-broadband',
    name: '500–550 km Mega-Constellation Shell (Starlink/Broadband)',
    altitudeKm: 530,
    thicknessKm: 35,
    riskLevel: 'CRITICAL',
    densityScore: 94.2,
    trackedObjects: 6840,
    colorHex: '#f43f5e',
  },
  {
    id: 'corridor-cosmos-debris',
    name: '780–820 km Cosmos-2251 / Iridium Collision Debris Belt',
    altitudeKm: 790,
    thicknessKm: 40,
    riskLevel: 'CRITICAL',
    densityScore: 88.6,
    trackedObjects: 3120,
    colorHex: '#f43f5e',
  },
  {
    id: 'corridor-fengyun-shell',
    name: '840–880 km Fengyun-1C High-Inclination Fragment Shell',
    altitudeKm: 860,
    thicknessKm: 45,
    riskLevel: 'HIGH',
    densityScore: 76.4,
    trackedObjects: 2450,
    colorHex: '#fbbf24',
  },
  {
    id: 'corridor-sso-polar',
    name: '680–720 km Sun-Synchronous Polar Reconnaissance Corridor',
    altitudeKm: 700,
    thicknessKm: 30,
    riskLevel: 'HIGH',
    densityScore: 71.8,
    trackedObjects: 1890,
    colorHex: '#fbbf24',
  },
  {
    id: 'corridor-iss-safe',
    name: '415–425 km Human Spaceflight Protected Corridor (ISS/CSS)',
    altitudeKm: 420,
    thicknessKm: 20,
    riskLevel: 'MODERATE',
    densityScore: 38.5,
    trackedObjects: 420,
    colorHex: '#06b6d4',
  },
];

/**
 * Procedural Heatmap Texture Generation using D3 Interpolator
 */
export function createD3RiskHeatmapTexture(): THREE.CanvasTexture {
  const width = 1024;
  const height = 512;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Transparent dark base
  ctx.fillStyle = 'rgba(3, 3, 5, 0.4)';
  ctx.fillRect(0, 0, width, height);

  // Use d3.interpolateInferno or d3.interpolateTurbo for scientific density mapping
  const colorScale = d3.scaleSequential(d3.interpolateInferno).domain([0, 1]);

  const toX = (lonDeg: number) => ((lonDeg + 180) / 360) * width;
  const toY = (latDeg: number) => ((90 - latDeg) / 180) * height;

  // Render high-risk conjunction hot-zones (polar bottlenecks and orbital intersection bands)
  const renderHotZone = (lon: number, lat: number, rX: number, rY: number, intensity: number) => {
    const x = toX(lon);
    const y = toY(lat);
    const grad = ctx.createRadialGradient(x, y, 0, x, y, rX);

    const c1 = d3.color(colorScale(intensity))?.formatRgb() || 'rgba(244, 63, 94, 0.8)';
    const c2 = d3.color(colorScale(intensity * 0.5))?.formatRgb() || 'rgba(251, 191, 36, 0.4)';

    grad.addColorStop(0.0, c1);
    grad.addColorStop(0.4, c2);
    grad.addColorStop(1.0, 'rgba(0, 0, 0, 0)');

    ctx.save();
    ctx.beginPath();
    ctx.ellipse(x, y, rX, rY, 0, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.restore();
  };

  // High-density polar bottleneck rings (Sun-Synchronous 97-98° orbits all converge at poles)
  for (let lon = -180; lon < 180; lon += 45) {
    renderHotZone(lon, 78, 90, 45, 0.95);
    renderHotZone(lon, -78, 90, 45, 0.95);
  }

  // Mid-latitude constellation crossing clusters (53° inclination crossings)
  const midLatitudes = [53, -53, 42, -42];
  midLatitudes.forEach((lat) => {
    for (let lon = -160; lon < 180; lon += 60) {
      renderHotZone(lon, lat, 75, 40, 0.85);
    }
  });

  // Equatorial geostationary crossing nodes
  for (let lon = -140; lon < 180; lon += 80) {
    renderHotZone(lon, 0, 85, 30, 0.65);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.generateMipmaps = true;
  return texture;
}

export class SpatialRiskHeatmapLayer {
  public group: THREE.Group;
  private heatmapSphere: THREE.Mesh;
  private corridorMeshes: THREE.Mesh[] = [];
  private corridorRings: THREE.Line[] = [];
  private earthRadius3D: number;
  private heatmapTexture: THREE.CanvasTexture;

  constructor(earthRadius3D: number = 10.0) {
    this.earthRadius3D = earthRadius3D;
    this.group = new THREE.Group();

    // 1. Concentric Risk Heatmap Atmospheric Shell
    this.heatmapTexture = createD3RiskHeatmapTexture();
    const sphereGeom = new THREE.SphereGeometry(earthRadius3D * 1.085, 48, 48);
    const sphereMat = new THREE.MeshBasicMaterial({
      map: this.heatmapTexture,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.heatmapSphere = new THREE.Mesh(sphereGeom, sphereMat);
    this.group.add(this.heatmapSphere);

    // 2. High-Density 3D Corridor Bands (LEO 530km, 790km, 860km)
    CORRIDORS.forEach((corridor) => {
      const radius3D = earthRadius3D * (1 + corridor.altitudeKm / EARTH_RADIUS_KM);
      const tubeRadius = (corridor.thicknessKm / EARTH_RADIUS_KM) * earthRadius3D * 0.45;

      // Torus ring for corridor shell
      const torusGeom = new THREE.TorusGeometry(radius3D, tubeRadius, 12, 64);
      const torusMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(corridor.colorHex),
        transparent: true,
        opacity: corridor.riskLevel === 'CRITICAL' ? 0.28 : 0.16,
        wireframe: true,
        blending: THREE.AdditiveBlending,
      });

      const torusMesh = new THREE.Mesh(torusGeom, torusMat);
      torusMesh.rotation.x = Math.PI / 2;
      this.group.add(torusMesh);
      this.corridorMeshes.push(torusMesh);

      // Edge perimeter ring
      const ringPoints: THREE.Vector3[] = [];
      const segments = 96;
      for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * Math.PI * 2;
        ringPoints.push(new THREE.Vector3(radius3D * Math.cos(theta), 0, radius3D * Math.sin(theta)));
      }
      const ringGeom = new THREE.BufferGeometry().setFromPoints(ringPoints);
      const ringMat = new THREE.LineBasicMaterial({
        color: new THREE.Color(corridor.colorHex),
        transparent: true,
        opacity: 0.45,
      });
      const ringLine = new THREE.Line(ringGeom, ringMat);
      this.group.add(ringLine);
      this.corridorRings.push(ringLine);
    });

    this.group.visible = false; // Toggled via user controls
  }

  public update(elapsedSec: number) {
    // Subtle breathing pulse on the risk heatmap shell
    const pulse = 0.5 + Math.sin(elapsedSec * 2.5) * 0.1;
    (this.heatmapSphere.material as THREE.MeshBasicMaterial).opacity = pulse;

    // Slow rotation of risk corridors
    this.heatmapSphere.rotation.y = elapsedSec * 0.015;
  }

  public setVisibility(visible: boolean) {
    this.group.visible = visible;
  }

  public dispose() {
    this.heatmapSphere.geometry.dispose();
    (this.heatmapSphere.material as THREE.Material).dispose();
    this.heatmapTexture.dispose();
    this.corridorMeshes.forEach((m) => {
      m.geometry.dispose();
      (m.material as THREE.Material).dispose();
    });
    this.corridorRings.forEach((r) => {
      r.geometry.dispose();
      (r.material as THREE.Material).dispose();
    });
  }
}
