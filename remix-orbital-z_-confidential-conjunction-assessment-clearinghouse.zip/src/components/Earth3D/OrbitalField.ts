import * as THREE from 'three';
import { EARTH_RADIUS_KM } from '../../services/propagator';
import { calculateAtmosphericDensity } from '../../services/atmosphericDrag';

export interface OrbitalParticleConfig {
  count: number;
}

export class OrbitalField {
  public mesh: THREE.InstancedMesh;
  public totalReentries: number = 0;
  private dummy: THREE.Object3D;
  private earthRadius3D: number;
  private particleData: Array<{
    radius: number;
    initialRadius: number;
    inclination: number;
    raan: number;
    speed: number;
    phase: number;
    eccentricity: number;
    type: 'OPERATIONAL' | 'INACTIVE' | 'DEBRIS';
    ballisticCoeff: number; // m^2 / kg
    decayRateKmPerSec: number;
  }> = [];

  constructor(count: number = 12500, earthRadius: number = 10.0) {
    this.dummy = new THREE.Object3D();
    this.earthRadius3D = earthRadius;

    // Octahedron geometry is crisp, lightweight, and renders with sharp facets
    const geometry = new THREE.OctahedronGeometry(0.045, 0);
    const material = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.85,
    });

    this.mesh = new THREE.InstancedMesh(geometry, material, count);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.frustumCulled = false;

    // Strict color coding per mission requirements:
    // Emerald / Cyan for nominal operational assets
    const colorOperationalCyan = new THREE.Color('#06b6d4');
    const colorOperationalEmerald = new THREE.Color('#10b981');
    // Amber / Crimson for high-risk conjunction pairs
    const colorHighRiskAmber = new THREE.Color('#fbbf24');
    const colorHighRiskCrimson = new THREE.Color('#f43f5e');
    // Cryptographic Violet for confidential enclave assets
    const colorEnclaveViolet = new THREE.Color('#8b5cf6');
    // Muted slate for inactive orbital hardware
    const colorInactive = new THREE.Color('#64748b');

    // Generate 12,500+ realistic orbital objects
    for (let i = 0; i < count; i++) {
      let r: number;
      let inc: number;
      let speed: number;
      let type: 'OPERATIONAL' | 'INACTIVE' | 'DEBRIS';
      let col: THREE.Color;
      let ballisticCoeff = 0.01;

      const roll = Math.random();

      if (roll < 0.68) {
        // LEO (Low Earth Orbit): 300km - 1,200km -> 1.045 to 1.19 * Earth Radius
        r = earthRadius * (1.045 + Math.random() * 0.16);
        inc = (Math.random() > 0.4 ? 50 + Math.random() * 48 : Math.random() * 35) * (Math.PI / 180);
        speed = 0.45 + (1.2 - (r / earthRadius)) * 0.5;

        const subType = Math.random();
        if (subType < 0.32) {
          type = 'OPERATIONAL';
          col = Math.random() > 0.5 ? colorOperationalCyan : colorOperationalEmerald;
          ballisticCoeff = 0.008; // Streamlined active sat
        } else if (subType < 0.45) {
          type = 'OPERATIONAL';
          col = colorEnclaveViolet; // Confidential enclave assets
          ballisticCoeff = 0.009;
        } else if (subType < 0.65) {
          type = 'INACTIVE';
          col = colorInactive;
          ballisticCoeff = 0.025; // Spent upper stage / dead payload
        } else {
          type = 'DEBRIS';
          col = Math.random() > 0.5 ? colorHighRiskCrimson : colorHighRiskAmber;
          ballisticCoeff = 0.05 + Math.random() * 0.07; // High area-to-mass fragment
        }
      } else if (roll < 0.85) {
        // MEO (Medium Earth Orbit / Navigation & Enclave Relays): 2.0 to 4.2 * Earth Radius
        r = earthRadius * (2.2 + Math.random() * 1.8);
        inc = (55 + (Math.random() - 0.5) * 10) * (Math.PI / 180);
        speed = 0.16;
        type = 'OPERATIONAL';
        col = Math.random() > 0.3 ? colorEnclaveViolet : colorOperationalCyan;
        ballisticCoeff = 0.005;
      } else {
        // GEO (Geostationary Belt at ~35,786 km): ~6.6 * Earth Radius
        r = earthRadius * (6.55 + (Math.random() - 0.5) * 0.12);
        inc = (Math.random() * 4) * (Math.PI / 180); // Near equatorial
        speed = 0.045;
        type = 'OPERATIONAL';
        col = colorOperationalEmerald;
        ballisticCoeff = 0.005;
      }

      const raan = Math.random() * Math.PI * 2;
      const phase = Math.random() * Math.PI * 2;
      const eccentricity = type === 'DEBRIS' ? Math.random() * 0.04 : Math.random() * 0.005;

      this.particleData.push({
        radius: r,
        initialRadius: r,
        inclination: inc,
        raan,
        speed,
        phase,
        eccentricity,
        type,
        ballisticCoeff,
        decayRateKmPerSec: 0,
      });

      this.mesh.setColorAt(i, col);
    }

    if (this.mesh.instanceColor) {
      this.mesh.instanceColor.needsUpdate = true;
    }

    // Initial position update
    this.update(0, 1.0, true, 155, 0.016);
  }

  public update(
    elapsedSeconds: number,
    timeMultiplier: number = 1.0,
    enableDrag: boolean = true,
    solarFlux: number = 155,
    deltaSec: number = 0.016
  ) {
    const t = elapsedSeconds * timeMultiplier;
    const simDt = deltaSec * Math.max(1, timeMultiplier);

    for (let i = 0; i < this.particleData.length; i++) {
      const p = this.particleData[i];

      // Atmospheric Drag Decay for LEO Objects (< 1.15 * Earth Radius, ~950 km)
      if (enableDrag && p.radius < this.earthRadius3D * 1.15) {
        // Convert 3D scene radius to real altitude in km
        const altitudeKm = (p.radius / this.earthRadius3D - 1.0) * EARTH_RADIUS_KM;

        if (altitudeKm < 800) {
          const rho = calculateAtmosphericDensity(altitudeKm, solarFlux);
          // Scaled decay for visual animation
          const decayScale = 1.8e6; // Visual simulation amplification
          const deltaR3D = (rho * p.ballisticCoeff * decayScale * simDt * (this.earthRadius3D / EARTH_RADIUS_KM));
          
          p.radius -= deltaR3D;

          // Keplerian velocity increase as orbital radius decreases: v ~ r^(-1/2)
          p.speed = (0.45 + (1.2 - (p.radius / this.earthRadius3D)) * 0.5) * Math.pow(p.initialRadius / p.radius, 1.2);

          // Karman line terminal reentry check (~105 km -> radius <= earthRadius * 1.016)
          if (p.radius <= this.earthRadius3D * 1.016) {
            this.totalReentries++;
            // Re-spawn debris at upper thermosphere injection belt
            p.radius = this.earthRadius3D * (1.075 + Math.random() * 0.08);
            p.initialRadius = p.radius;
            p.phase = Math.random() * Math.PI * 2;
          }
        }
      }

      const theta = p.phase + t * p.speed * 0.2;
      const currentR = p.radius * (1 - p.eccentricity * Math.cos(theta));

      // Orbital plane coords
      const xOrb = currentR * Math.cos(theta);
      const yOrb = currentR * Math.sin(theta);

      // Rotate by inclination and RAAN
      const cosO = Math.cos(p.raan);
      const sinO = Math.sin(p.raan);
      const cosI = Math.cos(p.inclination);
      const sinI = Math.sin(p.inclination);

      const x = cosO * xOrb - sinO * yOrb * cosI;
      const y = sinI * yOrb;
      const z = sinO * xOrb + cosO * yOrb * cosI;

      this.dummy.position.set(x, y, z);
      this.dummy.updateMatrix();
      this.mesh.setMatrixAt(i, this.dummy.matrix);
    }

    this.mesh.instanceMatrix.needsUpdate = true;
  }

  public setFilter(showDebris: boolean, showOperational: boolean) {
    // If filtered out, scale down to 0
    for (let i = 0; i < this.particleData.length; i++) {
      const p = this.particleData[i];
      let visible = true;
      if (p.type === 'DEBRIS' && !showDebris) visible = false;
      if (p.type === 'OPERATIONAL' && !showOperational) visible = false;

      if (!visible) {
        this.dummy.position.set(0, 0, 0);
        this.dummy.scale.set(0, 0, 0);
        this.dummy.updateMatrix();
        this.mesh.setMatrixAt(i, this.dummy.matrix);
      }
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }

  public resetDecay() {
    for (let i = 0; i < this.particleData.length; i++) {
      const p = this.particleData[i];
      p.radius = p.initialRadius;
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }

  public dispose() {
    this.mesh.geometry.dispose();
    if (Array.isArray(this.mesh.material)) {
      this.mesh.material.forEach((m) => m.dispose());
    } else {
      this.mesh.material.dispose();
    }
  }
}
