import * as THREE from 'three';

/**
 * Custom GLSL Shaders for Photorealistic Planetary Rendering.
 */

// Earth Surface Multi-Pass Shader (Day / Night Terminator + Specular Glint + Night Lights)
export const EarthSurfaceShader = {
  uniforms: {
    dayTexture: { value: null as THREE.Texture | null },
    nightTexture: { value: null as THREE.Texture | null },
    specularTexture: { value: null as THREE.Texture | null },
    bumpTexture: { value: null as THREE.Texture | null },
    sunDirection: { value: new THREE.Vector3(1.0, 0.2, 0.5).normalize() },
    bumpScale: { value: 0.05 },
    ambientLight: { value: 0.08 },
  },
  vertexShader: `
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vWorldPosition;
    varying vec3 vViewPosition;

    void main() {
      vUv = uv;
      vNormal = normalize(normalMatrix * normal);
      vec4 worldPosition = modelMatrix * vec4(position, 1.0);
      vWorldPosition = worldPosition.xyz;
      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      vViewPosition = -mvPosition.xyz;
      gl_Position = projectionMatrix * mvPosition;
    }
  `,
  fragmentShader: `
    uniform sampler2D dayTexture;
    uniform sampler2D nightTexture;
    uniform sampler2D specularTexture;
    uniform sampler2D bumpTexture;
    uniform vec3 sunDirection;
    uniform float bumpScale;
    uniform float ambientLight;

    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vWorldPosition;
    varying vec3 vViewPosition;

    void main() {
      vec3 normal = normalize(vNormal);
      vec3 viewDir = normalize(vViewPosition);
      vec3 lightDir = normalize(sunDirection);

      // Sun dot product for terminator
      float NdotL = dot(normal, lightDir);
      
      // Smooth twilight transition band between day and night (-0.15 to +0.15)
      float dayFactor = smoothstep(-0.12, 0.18, NdotL);
      float nightFactor = 1.0 - dayFactor;

      // Sample textures
      vec4 dayColor = texture2D(dayTexture, vUv);
      vec4 nightColor = texture2D(nightTexture, vUv);
      float specMap = texture2D(specularTexture, vUv).r;
      float bumpVal = texture2D(bumpTexture, vUv).r;

      // Grazing sunlight topography shading
      float relief = 1.0 + (bumpVal - 0.5) * bumpScale * clamp(NdotL * 2.0, 0.0, 1.0);

      // Specular highlight on oceans (Blinn-Phong)
      vec3 halfDir = normalize(lightDir + viewDir);
      float specAngle = max(dot(normal, halfDir), 0.0);
      float specular = pow(specAngle, 32.0) * specMap * dayFactor * 1.4;

      // Day hemisphere diffuse with ambient space fill
      vec3 diffuseDay = dayColor.rgb * relief * (max(NdotL, 0.0) + ambientLight);

      // Night hemisphere city lights (boosted radiance)
      vec3 emissiveNight = nightColor.rgb * nightFactor * 2.2;

      // Composite final planetary surface
      vec3 finalColor = diffuseDay + emissiveNight + vec3(0.35, 0.7, 1.0) * specular;

      gl_FragColor = vec4(finalColor, 1.0);
    }
  `,
};

// Multi-Tier Rayleigh/Mie Atmospheric Scattering Rim Shader
export const AtmosphereRimShader = {
  uniforms: {
    sunDirection: { value: new THREE.Vector3(1.0, 0.2, 0.5).normalize() },
    atmosphereColor: { value: new THREE.Color('#38bdf8') }, // Electric Cyan-Blue
    deepAtmosphereColor: { value: new THREE.Color('#1d4ed8') }, // Deep Cobalt
    rimPower: { value: 3.5 },
    rimIntensity: { value: 1.25 },
  },
  vertexShader: `
    varying vec3 vNormal;
    varying vec3 vWorldPosition;
    varying vec3 vViewPosition;

    void main() {
      vNormal = normalize(normalMatrix * normal);
      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      vViewPosition = -mvPosition.xyz;
      gl_Position = projectionMatrix * mvPosition;
    }
  `,
  fragmentShader: `
    uniform vec3 sunDirection;
    uniform vec3 atmosphereColor;
    uniform vec3 deepAtmosphereColor;
    uniform float rimPower;
    uniform float rimIntensity;

    varying vec3 vNormal;
    varying vec3 vViewPosition;

    void main() {
      vec3 normal = normalize(vNormal);
      vec3 viewDir = normalize(vViewPosition);
      vec3 lightDir = normalize(sunDirection);

      // Fresnel rim factor (glancing angle relative to camera view)
      float fresnel = 1.0 - max(dot(viewDir, normal), 0.0);
      fresnel = pow(fresnel, rimPower);

      // Sun illumination factor: atmosphere is significantly brighter on the sunward limb
      float sunFacing = dot(normal, lightDir);
      float sunLit = smoothstep(-0.3, 0.5, sunFacing);

      // Rayleigh wavelength color blend
      vec3 color = mix(deepAtmosphereColor, atmosphereColor, fresnel * 0.8 + 0.2);

      // Alpha falloff toward vacuum
      float alpha = fresnel * rimIntensity * (0.35 + 0.65 * sunLit);

      gl_FragColor = vec4(color, alpha);
    }
  `,
};
