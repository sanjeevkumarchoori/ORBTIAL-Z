import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import {
  createEarthAlbedoTexture,
  createEarthBumpTexture,
  createEarthSpecularTexture,
  createEarthNightLightsTexture,
  createEarthCloudsTexture,
} from './earthTextures';
import { EarthSurfaceShader, AtmosphereRimShader } from './earthShaders';
import { OrbitalField } from './OrbitalField';
import { ConjunctionVisualizer } from './ConjunctionVisualizer';
import { OpticalLaserLinks } from './OpticalLaserLinks';
import { OrbitalRings } from './OrbitalRings';
import { SpatialRiskHeatmapLayer } from './SpatialRiskHeatmap';
import { SEED_CATALOG, propagateKeplerian, EARTH_RADIUS_KM } from '../../services/propagator';
import { OrbitalAsset, GeodeticCoords } from '../../types/orbital';

export interface SceneToggles {
  showOrbits: boolean;
  showDebris: boolean;
  showLaserLinks: boolean;
  showDayNight: boolean;
  showGroundStations: boolean;
  showAtmosphere: boolean;
  showRiskHeatmap: boolean;
}

export type CameraPreset = 'GLOBAL' | 'CONJUNCTION' | 'GEO' | 'POLAR' | 'ISS';

interface Earth3DSceneProps {
  toggles: SceneToggles;
  cameraPreset: CameraPreset;
  timeSpeed: number;
  solarFlux?: number;
  enableDrag?: boolean;
  selectedAsset: OrbitalAsset | null;
  onSelectAsset: (asset: OrbitalAsset | null) => void;
  onReentryTick?: (reentryCount: number) => void;
  onTelemetryTick: (telemetry: {
    issCoords: GeodeticCoords;
    conjunctionMissMeters: number;
    sunAngleDeg: number;
    simulatedUtc: string;
  }) => void;
}

export const Earth3DScene: React.FC<Earth3DSceneProps> = ({
  toggles,
  cameraPreset,
  timeSpeed,
  solarFlux = 155,
  enableDrag = true,
  selectedAsset,
  onSelectAsset,
  onReentryTick,
  onTelemetryTick,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const solarFluxRef = useRef(solarFlux);
  solarFluxRef.current = solarFlux;

  const enableDragRef = useRef(enableDrag);
  enableDragRef.current = enableDrag;

  const onReentryTickRef = useRef(onReentryTick);
  onReentryTickRef.current = onReentryTick;
  const sceneRef = useRef<{
    renderer: THREE.WebGLRenderer;
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    earthMesh: THREE.Mesh;
    cloudMesh: THREE.Mesh;
    atmosphereMesh: THREE.Mesh;
    orbitalField: OrbitalField;
    conjunctionVis: ConjunctionVisualizer;
    laserLinks: OpticalLaserLinks;
    orbitalRings: OrbitalRings;
    sunDirection: THREE.Vector3;
    targetCamPos: THREE.Vector3;
    targetLookAt: THREE.Vector3;
    currentLookAt: THREE.Vector3;
    animFrameId: number;
    clock: THREE.Clock;
    cleanup: () => void;
  } | null>(null);

  // References for live prop values inside animation loop
  const togglesRef = useRef(toggles);
  togglesRef.current = toggles;

  const timeSpeedRef = useRef(timeSpeed);
  timeSpeedRef.current = timeSpeed;

  const cameraPresetRef = useRef(cameraPreset);
  cameraPresetRef.current = cameraPreset;

  const selectedAssetRef = useRef(selectedAsset);
  selectedAssetRef.current = selectedAsset;

  const onTelemetryTickRef = useRef(onTelemetryTick);
  onTelemetryTickRef.current = onTelemetryTick;

  useEffect(() => {
    if (!mountRef.current) return;

    const container = mountRef.current;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // 1. Scene & Renderer Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#030305');

    const isHeadless = typeof navigator !== 'undefined' && (navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent));

    const renderer = new THREE.WebGLRenderer({
      antialias: !isHeadless,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isHeadless ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    container.appendChild(renderer.domElement);

    // 2. Camera Setup with adaptive aspect ratio
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    const initialCamPos = new THREE.Vector3(0, 8, 28);
    camera.position.copy(initialCamPos);

    const targetCamPos = initialCamPos.clone();
    const currentLookAt = new THREE.Vector3(0, 0, 0);
    const targetLookAt = new THREE.Vector3(0, 0, 0);

    // 3. Deep Space Stars Particle Background
    const starCount = 3500;
    const starGeometry = new THREE.BufferGeometry();
    const starPositions = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);

    for (let i = 0; i < starCount; i++) {
      const radius = 250 + Math.random() * 250;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      starPositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      starPositions[i * 3 + 2] = radius * Math.cos(phi);

      const brightness = 0.5 + Math.random() * 0.5;
      starColors[i * 3] = brightness * 0.9;
      starColors[i * 3 + 1] = brightness * 0.95;
      starColors[i * 3 + 2] = brightness;
    }

    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeometry.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    const starMaterial = new THREE.PointsMaterial({
      size: 1.2,
      vertexColors: true,
      transparent: true,
      opacity: 0.8,
    });
    const starField = new THREE.Points(starGeometry, starMaterial);
    scene.add(starField);

    // 4. Sun Direction & Lighting
    const sunDirection = new THREE.Vector3(1.0, 0.25, 0.7).normalize();
    const sunLight = new THREE.DirectionalLight(0xfffdfa, 2.4);
    sunLight.position.copy(sunDirection).multiplyScalar(80);
    scene.add(sunLight);

    const ambientLight = new THREE.AmbientLight(0x0c1524, 0.4);
    scene.add(ambientLight);

    // 5. High-Fidelity Earth Geometry & Textures
    const earthRadius3D = 10.0;
    const earthGeom = new THREE.SphereGeometry(earthRadius3D, 64, 64);

    const dayTexture = createEarthAlbedoTexture();
    const nightTexture = createEarthNightLightsTexture();
    const specularTexture = createEarthSpecularTexture();
    const bumpTexture = createEarthBumpTexture();

    const earthMaterial = new THREE.ShaderMaterial({
      uniforms: {
        dayTexture: { value: dayTexture },
        nightTexture: { value: nightTexture },
        specularTexture: { value: specularTexture },
        bumpTexture: { value: bumpTexture },
        sunDirection: { value: sunDirection },
        bumpScale: { value: 0.06 },
        ambientLight: { value: 0.08 },
      },
      vertexShader: EarthSurfaceShader.vertexShader,
      fragmentShader: EarthSurfaceShader.fragmentShader,
    });

    const earthMesh = new THREE.Mesh(earthGeom, earthMaterial);
    scene.add(earthMesh);

    // 6. Volumetric Cloud Layer Sphere
    const cloudTexture = createEarthCloudsTexture();
    const cloudGeom = new THREE.SphereGeometry(earthRadius3D * 1.008, 64, 64);
    const cloudMaterial = new THREE.MeshStandardMaterial({
      map: cloudTexture,
      transparent: true,
      opacity: 0.62,
      blending: THREE.NormalBlending,
      depthWrite: false,
      roughness: 0.9,
    });
    const cloudMesh = new THREE.Mesh(cloudGeom, cloudMaterial);
    scene.add(cloudMesh);

    // 7. Multi-Tier Rayleigh Atmosphere Scattering Rim Sphere
    const atmosphereGeom = new THREE.SphereGeometry(earthRadius3D * 1.028, 64, 64);
    const atmosphereMaterial = new THREE.ShaderMaterial({
      uniforms: {
        sunDirection: { value: sunDirection },
        atmosphereColor: { value: new THREE.Color('#38bdf8') },
        deepAtmosphereColor: { value: new THREE.Color('#1d4ed8') },
        rimPower: { value: 3.2 },
        rimIntensity: { value: 1.4 },
      },
      vertexShader: AtmosphereRimShader.vertexShader,
      fragmentShader: AtmosphereRimShader.fragmentShader,
      transparent: true,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      depthWrite: false,
    });
    const atmosphereMesh = new THREE.Mesh(atmosphereGeom, atmosphereMaterial);
    scene.add(atmosphereMesh);

    // 8. Orbital Constellations (InstancedMesh with 12,500+ objects)
    const orbitalField = new OrbitalField(12500, earthRadius3D);
    scene.add(orbitalField.mesh);

    // 9. Conjunction Warning Visualizer
    const conjunctionVis = new ConjunctionVisualizer(earthRadius3D);
    scene.add(conjunctionVis.group);

    // 10. Optical Ground Stations & Laser Crosslinks
    const laserLinks = new OpticalLaserLinks(earthRadius3D);
    scene.add(laserLinks.group);

    // 11. Orbital Rings (LEO, MEO, GEO & Key Asset paths)
    const orbitalRings = new OrbitalRings(earthRadius3D);
    const asset4092 = SEED_CATALOG.find((a) => a.id === 'asset-4092')!;
    const asset8921 = SEED_CATALOG.find((a) => a.id === 'asset-8921')!;
    const issAsset = SEED_CATALOG.find((a) => a.id === 'iss-25544')!;

    orbitalRings.addAssetOrbit(asset4092, 0xf43f5e, 0.7);
    orbitalRings.addAssetOrbit(asset8921, 0xfbbf24, 0.6);
    orbitalRings.addAssetOrbit(issAsset, 0x06b6d4, 0.5);
    scene.add(orbitalRings.group);

    // 12. Spatial Conjunction Risk Heatmap & Corridor Shells (D3 procedural)
    const spatialRiskLayer = new SpatialRiskHeatmapLayer(earthRadius3D);
    scene.add(spatialRiskLayer.group);

    // 13. Interactive Mouse / Touch Orbit Controls (Zero-Dependency Custom Damped Arcball)
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let spherical = {
      radius: 28,
      theta: 0.15,
      phi: 1.25,
    };
    let targetSpherical = { ...spherical };
    let touchStartDist = 0;

    const onPointerDown = (e: PointerEvent) => {
      // Don't drag if clicking UI overlays
      if ((e.target as HTMLElement).tagName !== 'CANVAS') return;
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onPointerMove = (e: PointerEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;

      targetSpherical.theta -= deltaX * 0.005;
      targetSpherical.phi = Math.max(0.08, Math.min(Math.PI - 0.08, targetSpherical.phi - deltaY * 0.005));
    };

    const onPointerUp = () => {
      isDragging = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      targetSpherical.radius = Math.max(13.5, Math.min(95, targetSpherical.radius + e.deltaY * 0.025));
    };

    // Touch pinch-to-zoom
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        touchStartDist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        const dist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        const diff = touchStartDist - dist;
        targetSpherical.radius = Math.max(13.5, Math.min(95, targetSpherical.radius + diff * 0.05));
        touchStartDist = dist;
      }
    };

    window.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    container.addEventListener('wheel', onWheel, { passive: false });
    container.addEventListener('touchstart', onTouchStart, { passive: true });
    container.addEventListener('touchmove', onTouchMove, { passive: true });

    // 13. Window Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth || window.innerWidth;
      const newHeight = container.clientHeight || window.innerHeight;

      camera.aspect = newWidth / newHeight;
      // Adaptive FOV: widen FOV on narrow portrait mobile screens so full Earth remains visible
      if (newWidth < 768) {
        camera.fov = 55;
      } else {
        camera.fov = 42;
      }
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    // 14. 60Hz Render & Telemetry Interpolation Loop
    const clock = new THREE.Clock();
    let totalSimulationSeconds = 0;
    let animFrameId: number;

    const animate = () => {
      animFrameId = requestAnimationFrame(animate);
      const delta = Math.min(clock.getDelta(), 0.1);
      const activeSpeed = timeSpeedRef.current;
      totalSimulationSeconds += delta * activeSpeed;

      // Earth sidereal rotation
      const earthAngularSpeed = 0.025 * activeSpeed;
      earthMesh.rotation.y += earthAngularSpeed * delta;
      
      // Differential cloud rotation (creates authentic parallax)
      cloudMesh.rotation.y += (earthAngularSpeed * 1.15) * delta;

      // Update orbital constellations with atmospheric drag simulation
      orbitalField.update(
        totalSimulationSeconds,
        activeSpeed,
        enableDragRef.current,
        solarFluxRef.current,
        delta
      );
      orbitalField.setFilter(togglesRef.current.showDebris, true);

      if (onReentryTickRef.current) {
        onReentryTickRef.current(orbitalField.totalReentries);
      }

      // Update Conjunction Visualizer
      conjunctionVis.update(asset4092, asset8921, totalSimulationSeconds, activeSpeed);

      // Update Laser Links
      laserLinks.update(totalSimulationSeconds);

      // Visibility toggles
      orbitalRings.setVisibility(togglesRef.current.showOrbits);
      conjunctionVis.group.visible = true;
      laserLinks.group.visible = togglesRef.current.showLaserLinks;
      atmosphereMesh.visible = togglesRef.current.showAtmosphere;
      spatialRiskLayer.update(totalSimulationSeconds);
      spatialRiskLayer.setVisibility(togglesRef.current.showRiskHeatmap);

      // Sun terminator toggle (if disabled, points straight at camera)
      if (!togglesRef.current.showDayNight) {
        (earthMaterial.uniforms.sunDirection.value as THREE.Vector3).copy(camera.position).normalize();
      } else {
        (earthMaterial.uniforms.sunDirection.value as THREE.Vector3).copy(sunDirection);
      }

      // Camera Preset Handling
      const preset = cameraPresetRef.current;
      if (preset === 'CONJUNCTION') {
        const conjCenter = conjunctionVis.getConjunctionCenter();
        targetLookAt.copy(conjCenter);
        targetCamPos.set(conjCenter.x * 1.25, conjCenter.y + 1.2, conjCenter.z * 1.25 + 3.2);
        // Exponential damping
        camera.position.lerp(targetCamPos, 0.08);
        currentLookAt.lerp(targetLookAt, 0.08);
        camera.lookAt(currentLookAt);
      } else if (preset === 'GEO') {
        targetLookAt.set(0, 0, 0);
        targetCamPos.set(0, 52, 65);
        camera.position.lerp(targetCamPos, 0.06);
        currentLookAt.lerp(targetLookAt, 0.06);
        camera.lookAt(currentLookAt);
      } else if (preset === 'POLAR') {
        targetLookAt.set(0, 0, 0);
        targetCamPos.set(0, 36, 4);
        camera.position.lerp(targetCamPos, 0.06);
        currentLookAt.lerp(targetLookAt, 0.06);
        camera.lookAt(currentLookAt);
      } else if (preset === 'ISS') {
        const issProp = propagateKeplerian(issAsset, totalSimulationSeconds);
        const scale = earthRadius3D / EARTH_RADIUS_KM;
        const issPos = new THREE.Vector3(
          issProp.positionEci.x * scale,
          issProp.positionEci.y * scale,
          issProp.positionEci.z * scale
        );
        targetLookAt.copy(issPos);
        targetCamPos.set(issPos.x * 1.15 + 1.5, issPos.y * 1.15 + 1.2, issPos.z * 1.15 + 2.0);
        camera.position.lerp(targetCamPos, 0.08);
        currentLookAt.lerp(targetLookAt, 0.08);
        camera.lookAt(currentLookAt);
      } else {
        // GLOBAL free damped arcball
        spherical.radius += (targetSpherical.radius - spherical.radius) * 0.1;
        spherical.theta += (targetSpherical.theta - spherical.theta) * 0.1;
        spherical.phi += (targetSpherical.phi - spherical.phi) * 0.1;

        const x = spherical.radius * Math.sin(spherical.phi) * Math.sin(spherical.theta);
        const y = spherical.radius * Math.cos(spherical.phi);
        const z = spherical.radius * Math.sin(spherical.phi) * Math.cos(spherical.theta);

        targetLookAt.set(0, 0, 0);
        currentLookAt.lerp(targetLookAt, 0.1);
        camera.position.set(x, y, z);
        camera.lookAt(currentLookAt);
      }

      // Propagate telemetry for UI callbacks
      const issTelemetry = propagateKeplerian(issAsset, totalSimulationSeconds);
      const sunAngle = (Math.atan2(sunDirection.z, sunDirection.x) * 180) / Math.PI;

      onTelemetryTickRef.current({
        issCoords: issTelemetry.geodetic,
        conjunctionMissMeters: 410.2,
        sunAngleDeg: (sunAngle + 360) % 360,
        simulatedUtc: new Date(Date.now() + totalSimulationSeconds * 1000).toISOString(),
      });

      renderer.render(scene, camera);
    };

    animFrameId = requestAnimationFrame(animate);

    // Store cleanup handle
    sceneRef.current = {
      renderer,
      scene,
      camera,
      earthMesh,
      cloudMesh,
      atmosphereMesh,
      orbitalField,
      conjunctionVis,
      laserLinks,
      orbitalRings,
      sunDirection,
      targetCamPos,
      targetLookAt,
      currentLookAt,
      animFrameId,
      clock,
      cleanup: () => {
        cancelAnimationFrame(animFrameId);
        window.removeEventListener('pointerdown', onPointerDown);
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        container.removeEventListener('wheel', onWheel);
        container.removeEventListener('touchstart', onTouchStart);
        container.removeEventListener('touchmove', onTouchMove);
        window.removeEventListener('resize', handleResize);

        orbitalField.dispose();
        conjunctionVis.dispose();
        laserLinks.dispose();
        orbitalRings.dispose();
        spatialRiskLayer.dispose();
        earthGeom.dispose();
        earthMaterial.dispose();
        cloudGeom.dispose();
        cloudMaterial.dispose();
        atmosphereGeom.dispose();
        atmosphereMaterial.dispose();
        starGeometry.dispose();
        starMaterial.dispose();
        dayTexture.dispose();
        nightTexture.dispose();
        specularTexture.dispose();
        bumpTexture.dispose();
        cloudTexture.dispose();
        renderer.dispose();
        if (renderer.domElement && container.contains(renderer.domElement)) {
          container.removeChild(renderer.domElement);
        }
      },
    };

    return () => {
      sceneRef.current?.cleanup();
      sceneRef.current = null;
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="absolute inset-0 w-full h-full overflow-hidden cursor-grab active:cursor-grabbing touch-none select-none"
    />
  );
};
