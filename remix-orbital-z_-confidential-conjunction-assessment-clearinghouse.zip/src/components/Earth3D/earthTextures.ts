import * as THREE from 'three';

/**
 * Procedural High-Fidelity Earth Texture Synthesis.
 * Generates 2048x1024 or 4096x2048 equirectangular maps for:
 * 1. Albedo (Day terrain, bathymetry, biomes, ice caps)
 * 2. Bump / Elevation (Mountain chains, plateaus)
 * 3. Specular / Roughness (Glossy oceans vs matte landmass)
 * 4. Night Lights (Black Marble urban radiance)
 * 5. Volumetric Cloud Cover (Cyclones, ITCZ bands, feathered alpha)
 */

// Helper to draw continent landmass paths onto a 2D canvas (Equirectangular)
function drawContinents(ctx: CanvasRenderingContext2D, width: number, height: number, fillStyle: string | CanvasGradient) {
  ctx.fillStyle = fillStyle;

  const toX = (lonDeg: number) => ((lonDeg + 180) / 360) * width;
  const toY = (latDeg: number) => ((90 - latDeg) / 180) * height;

  const drawPoly = (points: [number, number][]) => {
    ctx.beginPath();
    points.forEach(([lon, lat], idx) => {
      const x = toX(lon);
      const y = toY(lat);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.fill();
  };

  // North America
  drawPoly([
    [-168, 65], [-160, 71], [-140, 70], [-120, 69], [-85, 70], [-65, 62], [-55, 50],
    [-65, 43], [-75, 35], [-80, 25], [-97, 26], [-90, 30], [-82, 28], [-80, 25],
    [-87, 21], [-96, 16], [-88, 15], [-83, 9], [-77, 8], [-80, 14], [-88, 16],
    [-105, 23], [-110, 30], [-117, 32], [-124, 40], [-125, 49], [-135, 57], [-150, 60],
    [-165, 60], [-168, 65],
  ]);

  // South America
  drawPoly([
    [-77, 8], [-72, 11], [-62, 10], [-50, 0], [-35, -5], [-35, -10], [-39, -15],
    [-42, -23], [-50, -30], [-58, -35], [-65, -42], [-68, -55], [-75, -50], [-73, -40],
    [-71, -30], [-76, -15], [-81, -5], [-80, 2], [-77, 8],
  ]);

  // Eurasia
  drawPoly([
    [-9, 36], [0, 44], [-4, 48], [2, 51], [8, 54], [10, 58], [25, 71], [30, 70],
    [60, 73], [100, 77], [140, 73], [170, 67], [179, 65], [170, 60], [140, 50],
    [130, 42], [122, 30], [108, 20], [103, 10], [100, 2], [98, 10], [90, 22],
    [80, 13], [75, 20], [68, 24], [60, 25], [50, 30], [45, 13], [35, 32], [28, 41],
    [15, 40], [0, 38], [-9, 36],
  ]);

  // Africa
  drawPoly([
    [-9, 36], [10, 37], [32, 31], [43, 12], [51, 10], [42, -4], [40, -15], [35, -25],
    [28, -33], [18, -34], [12, -20], [9, 0], [4, 6], [-10, 5], [-17, 15], [-13, 28],
    [-9, 36],
  ]);

  // Australia
  drawPoly([
    [114, -22], [125, -15], [135, -12], [142, -11], [150, -22], [153, -28], [150, -37],
    [140, -38], [130, -32], [115, -34], [113, -26], [114, -22],
  ]);

  // Greenland
  drawPoly([
    [-45, 60], [-35, 65], [-20, 75], [-30, 83], [-55, 82], [-60, 76], [-50, 68], [-45, 60],
  ]);

  // Antarctica
  drawPoly([
    [-180, -68], [-120, -74], [-60, -64], [0, -68], [60, -66], [120, -65], [180, -68],
    [180, -90], [-180, -90],
  ]);

  // Great Britain & Ireland
  drawPoly([[-5, 50], [1, 52], [0, 58], [-4, 58], [-5, 55], [-5, 50]]);
  // Japan
  drawPoly([[130, 32], [136, 35], [142, 43], [140, 36], [131, 33]]);
}

/**
 * 1. Albedo / Diffuse Texture (Daylight Earth)
 */
export function createEarthAlbedoTexture(): THREE.CanvasTexture {
  const width = 2048;
  const height = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Deep oceanic bathymetry gradient
  const oceanGrad = ctx.createLinearGradient(0, 0, 0, height);
  oceanGrad.addColorStop(0.0, '#0a2342'); // Arctic shelf
  oceanGrad.addColorStop(0.3, '#04132b'); // North Atlantic / Pacific deep
  oceanGrad.addColorStop(0.5, '#020b1a'); // Equatorial abyss
  oceanGrad.addColorStop(0.7, '#04132b'); // Southern ocean
  oceanGrad.addColorStop(1.0, '#0a2342'); // Antarctic shelf
  ctx.fillStyle = oceanGrad;
  ctx.fillRect(0, 0, width, height);

  // Continental shelf cyan glow near shores
  ctx.shadowColor = '#065a82';
  ctx.shadowBlur = 18;
  drawContinents(ctx, width, height, '#133a25');
  ctx.shadowBlur = 0;

  // Landmass Base: Biome layers (Temperate vegetation, Sahara/Arabian desert, Savannah)
  drawContinents(ctx, width, height, '#1a4224');

  // Paint arid deserts (Sahara, Arabian Peninsula, Gobi, Australian Outback)
  const toX = (lonDeg: number) => ((lonDeg + 180) / 360) * width;
  const toY = (latDeg: number) => ((90 - latDeg) / 180) * height;

  const paintDesert = (xDeg: number, yDeg: number, radiusX: number, radiusY: number, color: string) => {
    ctx.save();
    ctx.beginPath();
    ctx.ellipse(toX(xDeg), toY(yDeg), radiusX, radiusY, 0, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.filter = 'blur(14px)';
    ctx.fill();
    ctx.restore();
  };

  paintDesert(15, 23, 140, 50, '#9a7b4f'); // Sahara
  paintDesert(45, 22, 60, 35, '#8c6d40');  // Arabian desert
  paintDesert(95, 42, 70, 30, '#7c6543');  // Gobi desert
  paintDesert(133, -25, 75, 40, '#a56838'); // Australian outback
  paintDesert(-105, 33, 40, 25, '#8c764e'); // US Southwest desert

  // Mountain ridges (Himalayas, Andes, Rockies, Alps)
  const paintMountain = (xDeg: number, yDeg: number, rX: number, rY: number, rot: number) => {
    ctx.save();
    ctx.translate(toX(xDeg), toY(yDeg));
    ctx.rotate((rot * Math.PI) / 180);
    ctx.beginPath();
    ctx.ellipse(0, 0, rX, rY, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#655745';
    ctx.filter = 'blur(6px)';
    ctx.fill();
    // Snow-covered peaks
    ctx.beginPath();
    ctx.ellipse(0, 0, rX * 0.45, rY * 0.45, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#e2e8f0';
    ctx.filter = 'blur(2px)';
    ctx.fill();
    ctx.restore();
  };

  paintMountain(86, 30, 75, 16, 15);   // Himalayas / Tibetan plateau
  paintMountain(-69, -20, 20, 110, 5); // Andes
  paintMountain(-115, 45, 24, 85, -15);// Rocky mountains
  paintMountain(10, 46, 25, 10, -5);   // Alps

  // Polar Ice Caps (Arctic and Antarctica)
  ctx.save();
  ctx.fillStyle = '#f8fafc';
  ctx.filter = 'blur(8px)';
  ctx.fillRect(0, 0, width, height * 0.08); // Arctic
  ctx.fillRect(0, height * 0.88, width, height * 0.12); // Antarctic
  ctx.restore();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.generateMipmaps = true;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  return texture;
}

/**
 * 2. Bump / Normal Elevation Texture
 */
export function createEarthBumpTexture(): THREE.CanvasTexture {
  const width = 1024;
  const height = 512;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Neutral ocean floor (level 0)
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, width, height);

  // Landmass baseline (slightly elevated)
  drawContinents(ctx, width, height, '#9a9a9a');

  const toX = (lonDeg: number) => ((lonDeg + 180) / 360) * width;
  const toY = (latDeg: number) => ((90 - latDeg) / 180) * height;

  const paintRidge = (xDeg: number, yDeg: number, rX: number, rY: number, rot: number, brightness: string) => {
    ctx.save();
    ctx.translate(toX(xDeg), toY(yDeg));
    ctx.rotate((rot * Math.PI) / 180);
    ctx.beginPath();
    ctx.ellipse(0, 0, rX, rY, 0, 0, Math.PI * 2);
    ctx.fillStyle = brightness;
    ctx.filter = 'blur(4px)';
    ctx.fill();
    ctx.restore();
  };

  paintRidge(86, 30, 45, 12, 15, '#ffffff'); // Himalayas (highest)
  paintRidge(-69, -20, 12, 60, 5, '#e0e0e0'); // Andes
  paintRidge(-115, 45, 14, 50, -15, '#dedede'); // Rockies
  paintRidge(10, 46, 16, 6, -5, '#cccccc');  // Alps

  const texture = new THREE.CanvasTexture(canvas);
  texture.generateMipmaps = true;
  return texture;
}

/**
 * 3. Specular / Water Roughness Texture
 * Oceans are pure white (high specular reflection), continents are dark matte (roughness).
 */
export function createEarthSpecularTexture(): THREE.CanvasTexture {
  const width = 1024;
  const height = 512;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Oceans reflective white
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  // Landmass non-reflective dark
  drawContinents(ctx, width, height, '#0d0d0d');

  const texture = new THREE.CanvasTexture(canvas);
  texture.generateMipmaps = true;
  return texture;
}

/**
 * 4. Night Lights (Black Marble Radiance) Texture
 * Ultra-crisp urban radiance glowing on the dark hemisphere.
 */
export function createEarthNightLightsTexture(): THREE.CanvasTexture {
  const width = 2048;
  const height = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Pure dark space
  ctx.fillStyle = '#010204';
  ctx.fillRect(0, 0, width, height);

  const toX = (lonDeg: number) => ((lonDeg + 180) / 360) * width;
  const toY = (latDeg: number) => ((90 - latDeg) / 180) * height;

  // Function to render luminous metropolitan cluster
  const addCityCluster = (lonDeg: number, latDeg: number, intensity: number, spreadPx: number) => {
    const x = toX(lonDeg);
    const y = toY(latDeg);

    // Warm radial core
    const radGrad = ctx.createRadialGradient(x, y, 0, x, y, spreadPx);
    radGrad.addColorStop(0.0, `rgba(255, 240, 180, ${intensity})`);
    radGrad.addColorStop(0.3, `rgba(245, 158, 11, ${intensity * 0.75})`);
    radGrad.addColorStop(0.7, `rgba(217, 119, 6, ${intensity * 0.3})`);
    radGrad.addColorStop(1.0, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = radGrad;
    ctx.beginPath();
    ctx.arc(x, y, spreadPx, 0, Math.PI * 2);
    ctx.fill();

    // Fine pinpoint urban lights
    ctx.fillStyle = 'rgba(255, 255, 230, 0.9)';
    const pointsCount = Math.floor(intensity * 18);
    for (let i = 0; i < pointsCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const dist = Math.random() * (spreadPx * 0.7);
      const px = x + Math.cos(angle) * dist;
      const py = y + Math.sin(angle) * dist;
      ctx.fillRect(px, py, 1.2, 1.2);
    }
  };

  // Major global metropolitan corridors
  // North America
  addCityCluster(-74, 40.7, 1.0, 32);  // NYC / Bos-Wash corridor
  addCityCluster(-87.6, 41.8, 0.9, 26); // Chicago / Great Lakes
  addCityCluster(-118.2, 34.0, 0.95, 28); // Los Angeles
  addCityCluster(-122.4, 37.7, 0.85, 22); // SF Bay Area
  addCityCluster(-95.3, 29.7, 0.8, 22);  // Houston / Texas triangle
  addCityCluster(-80.2, 25.8, 0.8, 20);  // Miami / Florida

  // Europe
  addCityCluster(-0.1, 51.5, 1.0, 30);  // London / UK
  addCityCluster(2.3, 48.8, 0.95, 26);  // Paris
  addCityCluster(6.9, 51.2, 1.0, 32);   // Rhine-Ruhr / Benelux
  addCityCluster(9.2, 45.4, 0.9, 24);   // Po Valley / Milan
  addCityCluster(37.6, 55.7, 0.85, 22); // Moscow
  addCityCluster(-3.7, 40.4, 0.8, 20);  // Madrid

  // Asia
  addCityCluster(139.7, 35.6, 1.0, 36); // Tokyo / Kanto Megalopolis
  addCityCluster(126.9, 37.5, 0.95, 26); // Seoul
  addCityCluster(121.4, 31.2, 1.0, 32); // Shanghai / Yangtze Delta
  addCityCluster(113.2, 23.1, 1.0, 34); // Pearl River / Hong Kong / Shenzhen
  addCityCluster(116.4, 39.9, 0.9, 28); // Beijing
  addCityCluster(77.2, 28.6, 0.95, 30); // Delhi / Indo-Gangetic corridor
  addCityCluster(72.8, 19.0, 0.9, 25);  // Mumbai
  addCityCluster(103.8, 1.3, 0.85, 20); // Singapore / Malacca Strait

  // Middle East & Africa
  addCityCluster(55.3, 25.2, 0.9, 22);  // Dubai / Persian Gulf
  addCityCluster(31.2, 30.0, 0.95, 24); // Nile River Delta / Cairo
  addCityCluster(28.0, -26.2, 0.75, 20);// Johannesburg / Gauteng

  // South America & Oceania
  addCityCluster(-46.6, -23.5, 0.9, 28); // São Paulo
  addCityCluster(-58.4, -34.6, 0.85, 24); // Buenos Aires
  addCityCluster(151.2, -33.8, 0.85, 22); // Sydney

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.generateMipmaps = true;
  return texture;
}

/**
 * 5. Volumetric Cloud Layer Texture
 * Generates realistic weather patterns with cyclone vortexes and trade-wind bands.
 */
export function createEarthCloudsTexture(): THREE.CanvasTexture {
  const width = 2048;
  const height = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Transparent background
  ctx.clearRect(0, 0, width, height);

  // Cloud bands (Intertropical Convergence Zone + Mid-latitude jet streams)
  const drawCloudBand = (yRatio: number, bandHeight: number, opacity: number, waviness: number) => {
    ctx.save();
    ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
    ctx.filter = 'blur(10px)';

    ctx.beginPath();
    const yCenter = yRatio * height;
    ctx.moveTo(0, yCenter);

    for (let x = 0; x <= width; x += 40) {
      const wave = Math.sin(x * 0.015 * waviness) * (bandHeight * 0.6) + Math.cos(x * 0.035) * (bandHeight * 0.3);
      ctx.lineTo(x, yCenter + wave);
    }
    for (let x = width; x >= 0; x -= 40) {
      const wave = Math.sin(x * 0.015 * waviness) * (bandHeight * 0.6) - Math.cos(x * 0.02) * (bandHeight * 0.4);
      ctx.lineTo(x, yCenter + wave + bandHeight);
    }
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  };

  // Tropical ITCZ band
  drawCloudBand(0.48, 55, 0.45, 1.2);
  drawCloudBand(0.52, 45, 0.4, 1.8);

  // Northern Mid-latitude storms
  drawCloudBand(0.28, 80, 0.55, 2.2);
  drawCloudBand(0.22, 60, 0.45, 3.1);

  // Southern Roaring Forties
  drawCloudBand(0.72, 90, 0.6, 2.5);
  drawCloudBand(0.78, 70, 0.5, 3.0);

  // Cyclone vortex helper
  const drawCyclone = (centerX: number, centerY: number, radius: number, arms: number) => {
    ctx.save();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
    ctx.filter = 'blur(6px)';

    for (let a = 0; a < arms; a++) {
      const baseAngle = (a * 2 * Math.PI) / arms;
      ctx.beginPath();
      for (let r = 8; r < radius; r += 6) {
        const theta = baseAngle + (r / radius) * 4.5;
        const px = centerX + Math.cos(theta) * r;
        const py = centerY + Math.sin(theta) * (r * 0.7);
        if (r === 8) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.lineWidth = 14;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.stroke();
    }
    ctx.restore();
  };

  drawCyclone(width * 0.22, height * 0.32, 70, 3); // North Atlantic hurricane
  drawCyclone(width * 0.75, height * 0.28, 85, 4); // West Pacific typhoon
  drawCyclone(width * 0.42, height * 0.72, 65, 3); // Southern Ocean low

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.generateMipmaps = true;
  return texture;
}
