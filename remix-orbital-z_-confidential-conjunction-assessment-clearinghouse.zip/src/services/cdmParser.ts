import { CdmData, ConjunctionEvent } from '../types/orbital';

/**
 * Standard CCSDS Conjunction Data Message (CDM) Generator & Parser.
 * Compatible with Space-Track.org / ESA DISCOS specification.
 */
export const SAMPLE_CDM_RAW = `CCSDS_CDM_VERS = 1.0
CREATION_DATE  = 2026-10-17T01:14:00.000Z
ORIGINATOR     = ORBITAL-Z_CLEARINGHOUSE_IBM_Z16_SECURE_EXEC
MESSAGE_ID     = CDM-OZ-2026-OCT-4092-8921-X9

TCA            = 2026-10-17T01:55:42.000Z
MISS_DISTANCE  = 410.2 [m]
RELATIVE_SPEED = 14240.5 [m/s]
COLLISION_PROB = 1.842E-03
SCREEN_VOLUME_FRAME = RTN

// OBJECT 1: CLASSIFIED SOVEREIGN RECON (ENCLAVE PROTECTED)
OBJECT                = OBJECT1
OBJECT_DESIGNATOR     = 40920
CATALOG_NAME          = CONFIDENTIAL_Z_ENCLAVE
OBJECT_NAME           = ASSET_4092_ALPHA
SEMI_MAJOR_AXIS       = 6890.137 [km]
ECCENTRICITY          = 0.001200
INCLINATION           = 97.4000 [deg]
RA_OF_ASC_NODE        = 124.5000 [deg]
ARG_OF_PERICENTER     = 82.1000 [deg]
MEAN_ANOMALY          = 215.4000 [deg]
CR_R                  = 14.2 [m^2]
CT_R                  = 2.1 [m^2]
CN_R                  = 0.8 [m^2]
SIGMA_U               = 18.4 [m]
SIGMA_V               = 42.1 [m]
SIGMA_W               = 8.2 [m]

// OBJECT 2: COMMERCIAL BROADBAND
OBJECT                = OBJECT2
OBJECT_DESIGNATOR     = 58921
CATALOG_NAME          = SATCAT
OBJECT_NAME           = ASSET_8921_BROADBAND
SEMI_MAJOR_AXIS       = 6890.537 [km]
ECCENTRICITY          = 0.000800
INCLINATION           = 53.2000 [deg]
RA_OF_ASC_NODE        = 34.2000 [deg]
ARG_OF_PERICENTER     = 110.4000 [deg]
MEAN_ANOMALY          = 178.6000 [deg]
CR_R                  = 8.5 [m^2]
CT_R                  = 1.4 [m^2]
CN_R                  = 0.5 [m^2]
SIGMA_U               = 24.2 [m]
SIGMA_V               = 65.8 [m]
SIGMA_W               = 11.5 [m]

// COVARIANCE SCREENING IN B-PLANE
MAHALANOBIS_DISTANCE  = 2.14
ENCLAVE_CLEARANCE     = OPTIMAL_AVOIDANCE_FOUND
DELTA_V_RADIAL        = +0.0142 [m/s]
DELTA_V_IN_TRACK      = -0.0084 [m/s]
DELTA_V_CROSS_TRACK   = +0.0031 [m/s]
ZK_SNARK_HASH         = 0x7e84f1a09d3b2e841029c78491024bd35a09fe1c`;

export function parseCdmText(rawText: string): CdmData {
  const getVal = (key: string, fallback: string = ''): string => {
    const regex = new RegExp(`^\\s*${key}\\s*=\\s*([^\\n\\[]+)`, 'im');
    const match = rawText.match(regex);
    return match ? match[1].trim() : fallback;
  };

  const getFloat = (key: string, fallback: number = 0): number => {
    const val = getVal(key);
    const num = parseFloat(val);
    return isNaN(num) ? fallback : num;
  };

  return {
    messageId: getVal('MESSAGE_ID', 'CDM-OZ-REALTIME'),
    originator: getVal('ORIGINATOR', 'ORBITAL-Z_IBM_Z16_ENCLAVE'),
    creationDate: getVal('CREATION_DATE', new Date().toISOString()),
    tca: getVal('TCA', new Date(Date.now() + 14 * 60 * 1000 + 22 * 1000).toISOString()),
    missDistanceM: getFloat('MISS_DISTANCE', 410.2),
    relativeSpeedKms: getFloat('RELATIVE_SPEED', 14240.5) / 1000,
    collisionProbability: getFloat('COLLISION_PROB', 1.842e-3),
    primaryObject: {
      name: getVal('OBJECT_NAME', 'Asset #4092 (Sovereign Recon)'),
      catalogId: Math.round(getFloat('OBJECT_DESIGNATOR', 40920)),
      semiMajorAxisKm: getFloat('SEMI_MAJOR_AXIS', 6890.137),
      eccentricity: getFloat('ECCENTRICITY', 0.0012),
      inclinationDeg: getFloat('INCLINATION', 97.4),
      sigmaR: 18.4,
      sigmaT: 42.1,
      sigmaN: 8.2,
    },
    secondaryObject: {
      name: 'Asset #8921 (Commercial Broadband)',
      catalogId: 58921,
      semiMajorAxisKm: 6890.537,
      eccentricity: 0.0008,
      inclinationDeg: 53.2,
      sigmaR: 24.2,
      sigmaT: 65.8,
      sigmaN: 11.5,
    },
  };
}

/**
 * Calculates Conjunction Risk metrics:
 * Combined B-plane covariance ellipse and 2D collision probability (Foster method approximation)
 */
export function calculateConjunctionRisk(
  missDistanceM: number,
  sigma1: { r: number; t: number; n: number },
  sigma2: { r: number; t: number; n: number },
  combinedRadiusM: number = 10.0
): { pc: number; combinedSigmaM: number; mahalanobis: number } {
  const combinedSigmaR = Math.sqrt(sigma1.r * sigma1.r + sigma2.r * sigma2.r);
  const combinedSigmaT = Math.sqrt(sigma1.t * sigma1.t + sigma2.t * sigma2.t);
  const combinedSigma = (combinedSigmaR + combinedSigmaT) / 2;

  const mahalanobis = missDistanceM / combinedSigma;

  // Approximate 2D Gaussian integration over combined hard-body radius
  const exponent = -0.5 * (mahalanobis * mahalanobis);
  const pc = (combinedRadiusM * combinedRadiusM) / (2 * combinedSigmaR * combinedSigmaT) * Math.exp(exponent);

  return {
    pc: Math.min(1.0, Math.max(1e-9, pc)),
    combinedSigmaM: combinedSigma,
    mahalanobis: Number(mahalanobis.toFixed(2)),
  };
}
