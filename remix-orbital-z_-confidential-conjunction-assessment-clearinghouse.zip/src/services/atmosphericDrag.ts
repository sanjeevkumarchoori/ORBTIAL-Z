import { EARTH_RADIUS_KM, EARTH_MU } from './propagator';

/**
 * Atmospheric drag and orbital decay physics service
 * Implements exponential thermospheric density with solar activity scaling (F10.7 flux index)
 */

export interface DragModelParams {
  solarFluxF107: number; // Standard Solar Flux Units (70 = Solar Min, 150 = Moderate, 240 = Solar Max)
  geomagneticAp: number; // Geomagnetic planetary index (4 = quiet, 15 = active, 50+ = storm)
}

export const DEFAULT_DRAG_PARAMS: DragModelParams = {
  solarFluxF107: 155, // Moderate-high solar cycle 25
  geomagneticAp: 12,
};

// Atmospheric layer scale heights (km) and reference densities (kg/m^3)
// Derived from US Standard Atmosphere / Jacchia-Roberts thermosphere approximations
interface DensityBand {
  altMin: number;
  altMax: number;
  baseAlt: number;
  baseDensity: number; // kg/m^3
  scaleHeight: number; // km
}

const THERMOSPHERE_BANDS: DensityBand[] = [
  { altMin: 100, altMax: 150, baseAlt: 100, baseDensity: 5.297e-7, scaleHeight: 5.8 },
  { altMin: 150, altMax: 200, baseAlt: 150, baseDensity: 2.076e-9, scaleHeight: 18.2 },
  { altMin: 200, altMax: 300, baseAlt: 200, baseDensity: 2.541e-10, scaleHeight: 37.1 },
  { altMin: 300, altMax: 400, baseAlt: 300, baseDensity: 1.916e-11, scaleHeight: 53.3 },
  { altMin: 400, altMax: 500, baseAlt: 400, baseDensity: 2.803e-12, scaleHeight: 58.2 },
  { altMin: 500, altMax: 600, baseAlt: 500, baseDensity: 5.215e-13, scaleHeight: 63.8 },
  { altMin: 600, altMax: 700, baseAlt: 600, baseDensity: 1.137e-13, scaleHeight: 71.0 },
  { altMin: 700, altMax: 800, baseAlt: 700, baseDensity: 3.070e-14, scaleHeight: 88.0 },
  { altMin: 800, altMax: 1200, baseAlt: 800, baseDensity: 1.136e-14, scaleHeight: 124.0 },
];

/**
 * Computes atmospheric density rho (kg/m^3) at a given geodetic altitude
 * Scales with the 10.7cm solar radio flux (thermospheric thermal expansion)
 */
export function calculateAtmosphericDensity(
  altitudeKm: number,
  solarFluxF107: number = DEFAULT_DRAG_PARAMS.solarFluxF107
): number {
  if (altitudeKm < 100) {
    // Dense mesosphere
    return 5.297e-7 * Math.exp(-(altitudeKm - 100) / 6.0);
  }

  if (altitudeKm > 1200) {
    // Exosphere negligible drag
    return 1e-17;
  }

  const band = THERMOSPHERE_BANDS.find(
    (b) => altitudeKm >= b.altMin && altitudeKm < b.altMax
  ) || THERMOSPHERE_BANDS[THERMOSPHERE_BANDS.length - 1];

  const deltaH = altitudeKm - band.baseAlt;
  const baseDensity = band.baseDensity * Math.exp(-deltaH / band.scaleHeight);

  // Solar flux scaling factor: thermospheric heating expands atmosphere upwards
  // Normalizing around 100 sfu
  const solarScale = Math.pow(Math.max(60, solarFluxF107) / 100.0, 1.45);

  return baseDensity * solarScale;
}

/**
 * Calculates instantaneous circular orbital velocity (km/s) from altitude
 * v = sqrt(mu / (R_E + h))
 */
export function circularVelocityKms(altitudeKm: number): number {
  const rKm = EARTH_RADIUS_KM + Math.max(0, altitudeKm);
  return Math.sqrt(EARTH_MU / rKm);
}

export interface DecayStepResult {
  newAltitudeKm: number;
  newVelocityKms: number;
  altitudeLossMeters: number;
  decayRateMetersPerDay: number;
  densityKgM3: number;
  isReentered: boolean;
  reboostApplied: boolean;
}

/**
 * Ballistic decay evaluation
 *
 * da/dt = - sqrt(mu * a) * (Cd * A / m) * rho
 *
 * @param altitudeKm - current altitude in kilometers
 * @param ballisticCoeff - Area-to-mass ratio times Cd (m^2 / kg)
 * @param dtSeconds - simulation time elapsed
 * @param solarFlux - F10.7 index
 * @param hasActivePropulsion - if true, executes automated station-keeping burn when below limit
 */
export function stepOrbitalDecay(
  altitudeKm: number,
  ballisticCoeff: number, // m^2 / kg, typical range: 0.005 (dense sat) to 0.12 (light debris)
  dtSeconds: number,
  solarFlux: number = DEFAULT_DRAG_PARAMS.solarFluxF107,
  hasActivePropulsion: boolean = false,
  nominalStationAltKm: number = 418.0
): DecayStepResult {
  if (altitudeKm > 1200) {
    return {
      newAltitudeKm: altitudeKm,
      newVelocityKms: circularVelocityKms(altitudeKm),
      altitudeLossMeters: 0,
      decayRateMetersPerDay: 0.001,
      densityKgM3: 1e-17,
      isReentered: false,
      reboostApplied: false,
    };
  }

  const rho = calculateAtmosphericDensity(altitudeKm, solarFlux);
  const aKm = EARTH_RADIUS_KM + altitudeKm;
  const aMeters = aKm * 1000.0;
  const muM3S2 = EARTH_MU * 1e9; // m^3 / s^2

  // Drag decay formula in meters/sec: da/dt = - sqrt(mu * a) * B * rho
  const da_dt_ms = -Math.sqrt(muM3S2 * aMeters) * ballisticCoeff * rho;

  // Rate in meters/day
  const decayRateMetersPerDay = Math.abs(da_dt_ms * 86400);

  // Delta altitude in km over dt
  const deltaAltitudeKm = (da_dt_ms * dtSeconds) / 1000.0;
  let newAltKm = altitudeKm + deltaAltitudeKm;
  let reboost = false;

  // Active satellite station-keeping threshold (e.g. ISS or Starlink autonomous electric propulsion)
  if (hasActivePropulsion && newAltKm < nominalStationAltKm - 0.4) {
    // Autonomous micro-thrust re-boost restoring nominal orbit
    newAltKm = nominalStationAltKm;
    reboost = true;
  }

  // Karman line / catastrophic mesospheric burn-up threshold (~100km)
  const isReentered = newAltKm <= 105.0;

  return {
    newAltitudeKm: Math.max(0, newAltKm),
    newVelocityKms: circularVelocityKms(newAltKm),
    altitudeLossMeters: Math.abs(deltaAltitudeKm * 1000.0),
    decayRateMetersPerDay,
    densityKgM3: rho,
    isReentered,
    reboostApplied: reboost,
  };
}

export interface ReentryWatchItem {
  id: string;
  name: string;
  altitudeKm: number;
  decayRateMetersPerDay: number;
  ballisticCoeff: number;
  orbitClass: string;
  estimatedDaysToReentry: number;
  status: 'BURNING' | 'CRITICAL_DECAY' | 'STABLE_DRAG' | 'STATION_KEEPING';
}

export const SEED_REENTRY_WATCHLIST: ReentryWatchItem[] = [
  {
    id: 'deb-cosmos-348',
    name: 'Cosmos 2251 Frag #348 (Solar Panel Shard)',
    altitudeKm: 342.1,
    decayRateMetersPerDay: 580.4,
    ballisticCoeff: 0.085,
    orbitClass: 'LEO Debris',
    estimatedDaysToReentry: 416,
    status: 'CRITICAL_DECAY',
  },
  {
    id: 'deb-sl4-booster',
    name: 'SL-4 Rocket Body Spent Upper Stage',
    altitudeKm: 285.4,
    decayRateMetersPerDay: 1240.2,
    ballisticCoeff: 0.035,
    orbitClass: 'LEO Rocket Body',
    estimatedDaysToReentry: 145,
    status: 'CRITICAL_DECAY',
  },
  {
    id: 'iss-active',
    name: 'International Space Station (ISS)',
    altitudeKm: 418.2,
    decayRateMetersPerDay: 68.2,
    ballisticCoeff: 0.0075,
    orbitClass: 'LEO Station',
    estimatedDaysToReentry: 4600,
    status: 'STATION_KEEPING',
  },
  {
    id: 'deb-fengyun-891',
    name: 'Fengyun-1C Debris Fragment #891',
    altitudeKm: 485.6,
    decayRateMetersPerDay: 14.8,
    ballisticCoeff: 0.055,
    orbitClass: 'LEO Debris',
    estimatedDaysToReentry: 26000,
    status: 'STABLE_DRAG',
  },
  {
    id: 'starlink-3129',
    name: 'Starlink-3129 (Active Argon Ion Thruster)',
    altitudeKm: 531.0,
    decayRateMetersPerDay: 4.1,
    ballisticCoeff: 0.012,
    orbitClass: 'LEO Commercial',
    estimatedDaysToReentry: 104000,
    status: 'STATION_KEEPING',
  },
];
