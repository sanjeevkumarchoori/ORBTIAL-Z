import { OrbitalAsset, GeodeticCoords, Vector3D } from '../types/orbital';

// Standard WGS84 & Gravitational Constants
export const EARTH_RADIUS_KM = 6378.137;
export const EARTH_MU = 398600.4418; // km^3 / s^2
export const EARTH_ROTATION_RATE_DEG_SEC = 360 / 86164.0905; // Sidereal day in seconds

/**
 * Solves Kepler's equation M = E - e*sin(E) using Newton-Raphson iteration.
 */
export function solveKepler(meanAnomalyRad: number, eccentricity: number): number {
  let e = meanAnomalyRad;
  const tolerance = 1e-6;
  const maxIter = 30;

  for (let i = 0; i < maxIter; i++) {
    const delta = (e - eccentricity * Math.sin(e) - meanAnomalyRad) / (1 - eccentricity * Math.cos(e));
    e -= delta;
    if (Math.abs(delta) < tolerance) {
      break;
    }
  }
  return e;
}

/**
 * Computes instantaneous ECI position and velocity vectors from Keplerian orbital elements.
 */
export function propagateKeplerian(
  asset: OrbitalAsset,
  elapsedSeconds: number
): { positionEci: Vector3D; velocityKms: number; geodetic: GeodeticCoords; trueAnomalyDeg: number } {
  const semiMajorAxisKm = EARTH_RADIUS_KM + asset.altitudeKm;
  const meanMotionRadSec = Math.sqrt(EARTH_MU / Math.pow(semiMajorAxisKm, 3));
  
  // Mean Anomaly advances with time
  const currentMeanAnomalyRad = ((asset.meanAnomalyDeg * Math.PI) / 180 + meanMotionRadSec * elapsedSeconds) % (2 * Math.PI);
  
  // Solve for Eccentric Anomaly
  const eccAnomalyRad = solveKepler(currentMeanAnomalyRad, asset.eccentricity);
  
  // True Anomaly
  const sinNu = (Math.sqrt(1 - asset.eccentricity * asset.eccentricity) * Math.sin(eccAnomalyRad)) / (1 - asset.eccentricity * Math.cos(eccAnomalyRad));
  const cosNu = (Math.cos(eccAnomalyRad) - asset.eccentricity) / (1 - asset.eccentricity * Math.cos(eccAnomalyRad));
  const trueAnomalyRad = Math.atan2(sinNu, cosNu);
  const trueAnomalyDeg = ((trueAnomalyRad * 180) / Math.PI + 360) % 360;

  // Radius from Earth center
  const rKm = semiMajorAxisKm * (1 - asset.eccentricity * Math.cos(eccAnomalyRad));
  
  // Instantaneous orbital speed via Vis-Viva equation
  const velocityKms = Math.sqrt(EARTH_MU * (2 / rKm - 1 / semiMajorAxisKm));

  // Position in orbital plane (perifocal coordinates)
  const xOrb = rKm * Math.cos(trueAnomalyRad);
  const yOrb = rKm * Math.sin(trueAnomalyRad);

  // Rotation angles to ECI (Earth-Centered Inertial)
  const iRad = (asset.inclinationDeg * Math.PI) / 180;
  const raanRad = (asset.raanDeg * Math.PI) / 180;
  const argPerRad = (asset.argPerigeeDeg * Math.PI) / 180;

  // Coordinate transformation matrix from Perifocal to ECI
  const cosO = Math.cos(raanRad);
  const sinO = Math.sin(raanRad);
  const cosI = Math.cos(iRad);
  const sinI = Math.sin(iRad);
  const cosW = Math.cos(argPerRad);
  const sinW = Math.sin(argPerRad);

  // Basis vectors P and Q
  const Px = cosO * cosW - sinO * sinW * cosI;
  const Py = sinO * cosW + cosO * sinW * cosI;
  const Pz = sinW * sinI;

  const Qx = -cosO * sinW - sinO * cosW * cosI;
  const Qy = -sinO * sinW + cosO * cosW * cosI;
  const Qz = cosW * sinI;

  const xEci = xOrb * Px + yOrb * Qx;
  const yEci = xOrb * Py + yOrb * Qy;
  const zEci = xOrb * Pz + yOrb * Qz;

  // Conversion from ECI to Geodetic (Lat, Lon, Alt)
  // Accounting for Earth's sidereal rotation
  const gmstDeg = (elapsedSeconds * EARTH_ROTATION_RATE_DEG_SEC) % 360;
  const gmstRad = (gmstDeg * Math.PI) / 180;

  // Rotate ECI to ECEF (Earth-Centered Earth-Fixed)
  const xEcef = xEci * Math.cos(gmstRad) + yEci * Math.sin(gmstRad);
  const yEcef = -xEci * Math.sin(gmstRad) + yEci * Math.cos(gmstRad);
  const zEcef = zEci;

  const lonRad = Math.atan2(yEcef, xEcef);
  const latRad = Math.atan2(zEcef, Math.sqrt(xEcef * xEcef + yEcef * yEcef));
  const altitudeKm = Math.sqrt(xEci * xEci + yEci * yEci + zEci * zEci) - EARTH_RADIUS_KM;

  return {
    positionEci: { x: xEci, y: yEci, z: zEci },
    velocityKms,
    geodetic: {
      latitude: (latRad * 180) / Math.PI,
      longitude: (lonRad * 180) / Math.PI,
      altitudeKm: Math.max(0, altitudeKm),
    },
    trueAnomalyDeg,
  };
}

/**
 * Key Benchmark Orbital Catalog (Active Assets, Debris, and Critical Conjunction Pair)
 */
export const SEED_CATALOG: OrbitalAsset[] = [
  {
    id: 'asset-4092',
    name: 'Asset #4092 (Sovereign Recon)',
    noradId: 40920,
    type: 'CONJUNCTION_TARGET',
    orbitClass: 'LEO',
    altitudeKm: 512,
    inclinationDeg: 97.4,
    periodMinutes: 94.8,
    velocityKms: 7.61,
    eccentricity: 0.0012,
    raanDeg: 124.5,
    argPerigeeDeg: 82.1,
    meanAnomalyDeg: 215.4,
    color: '#f43f5e', // Critical Rose
    size: 2.2,
    operator: 'Classified Sovereign Enclave',
    country: 'Sovereign-Alpha',
    launchDate: '2023-04-18',
  },
  {
    id: 'asset-8921',
    name: 'Asset #8921 (Commercial Broadband)',
    noradId: 58921,
    type: 'CONJUNCTION_TARGET',
    orbitClass: 'LEO',
    altitudeKm: 512.4,
    inclinationDeg: 53.2,
    periodMinutes: 94.9,
    velocityKms: 7.61,
    eccentricity: 0.0008,
    raanDeg: 34.2,
    argPerigeeDeg: 110.4,
    meanAnomalyDeg: 178.6,
    color: '#fbbf24', // Amber Alert
    size: 2.0,
    operator: 'Constellation Telecom Global',
    country: 'Commercial',
    launchDate: '2024-01-12',
  },
  {
    id: 'iss-25544',
    name: 'International Space Station (ISS)',
    noradId: 25544,
    type: 'OPERATIONAL',
    orbitClass: 'LEO',
    altitudeKm: 418,
    inclinationDeg: 51.64,
    periodMinutes: 92.9,
    velocityKms: 7.66,
    eccentricity: 0.0005,
    raanDeg: 245.1,
    argPerigeeDeg: 145.2,
    meanAnomalyDeg: 62.4,
    color: '#06b6d4', // Cyan
    size: 2.5,
    operator: 'NASA / ESA / JAXA / CSA',
    country: 'Multinational',
    launchDate: '1998-11-20',
  },
  {
    id: 'hubble-20580',
    name: 'Hubble Space Telescope',
    noradId: 20580,
    type: 'OPERATIONAL',
    orbitClass: 'LEO',
    altitudeKm: 535,
    inclinationDeg: 28.47,
    periodMinutes: 95.3,
    velocityKms: 7.59,
    eccentricity: 0.0003,
    raanDeg: 88.2,
    argPerigeeDeg: 210.5,
    meanAnomalyDeg: 130.8,
    color: '#38bdf8',
    size: 1.8,
    operator: 'NASA / STScI',
    country: 'USA',
    launchDate: '1990-04-24',
  },
  {
    id: 'starlink-3129',
    name: 'Starlink-3129',
    noradId: 48992,
    type: 'OPERATIONAL',
    orbitClass: 'LEO',
    altitudeKm: 550,
    inclinationDeg: 53.05,
    periodMinutes: 95.6,
    velocityKms: 7.58,
    eccentricity: 0.0001,
    raanDeg: 310.8,
    argPerigeeDeg: 45.0,
    meanAnomalyDeg: 90.0,
    color: '#10b981',
    size: 1.4,
    operator: 'SpaceX',
    country: 'USA',
    launchDate: '2022-07-11',
  },
  {
    id: 'tiangong-48274',
    name: 'Tiangong Space Station',
    noradId: 48274,
    type: 'OPERATIONAL',
    orbitClass: 'LEO',
    altitudeKm: 389,
    inclinationDeg: 41.47,
    periodMinutes: 92.3,
    velocityKms: 7.68,
    eccentricity: 0.0004,
    raanDeg: 195.4,
    argPerigeeDeg: 80.2,
    meanAnomalyDeg: 280.1,
    color: '#06b6d4',
    size: 2.2,
    operator: 'CMSA',
    country: 'China',
    launchDate: '2021-04-29',
  },
  {
    id: 'debris-cosmos-2251',
    name: 'Cosmos 2251 Debris (Frag #348)',
    noradId: 34182,
    type: 'DEBRIS',
    orbitClass: 'LEO',
    altitudeKm: 785,
    inclinationDeg: 74.04,
    periodMinutes: 100.5,
    velocityKms: 7.46,
    eccentricity: 0.015,
    raanDeg: 55.4,
    argPerigeeDeg: 290.1,
    meanAnomalyDeg: 15.2,
    color: '#f87171',
    size: 1.1,
    operator: 'Uncontrolled Debris',
    country: 'Russia',
    launchDate: '1993-06-16',
  },
  {
    id: 'debris-fengyun-1c',
    name: 'Fengyun-1C Debris (Frag #891)',
    noradId: 30129,
    type: 'DEBRIS',
    orbitClass: 'LEO',
    altitudeKm: 860,
    inclinationDeg: 98.6,
    periodMinutes: 102.1,
    velocityKms: 7.41,
    eccentricity: 0.021,
    raanDeg: 170.2,
    argPerigeeDeg: 110.8,
    meanAnomalyDeg: 340.5,
    color: '#f87171',
    size: 1.0,
    operator: 'Uncontrolled Debris',
    country: 'China',
    launchDate: '1999-05-10',
  },
  {
    id: 'gps-navstar-72',
    name: 'GPS BIIF-11 (NAVSTAR 72)',
    noradId: 40994,
    type: 'OPERATIONAL',
    orbitClass: 'MEO',
    altitudeKm: 20180,
    inclinationDeg: 55.0,
    periodMinutes: 717.9,
    velocityKms: 3.87,
    eccentricity: 0.005,
    raanDeg: 280.0,
    argPerigeeDeg: 15.0,
    meanAnomalyDeg: 45.0,
    color: '#8b5cf6',
    size: 1.9,
    operator: 'US Space Force',
    country: 'USA',
    launchDate: '2015-10-31',
  },
  {
    id: 'goes-16-geo',
    name: 'GOES-16 (East)',
    noradId: 41866,
    type: 'OPERATIONAL',
    orbitClass: 'GEO',
    altitudeKm: 35786,
    inclinationDeg: 0.05,
    periodMinutes: 1436.1,
    velocityKms: 3.07,
    eccentricity: 0.0001,
    raanDeg: 0.0,
    argPerigeeDeg: 0.0,
    meanAnomalyDeg: 284.8, // 75.2° W
    color: '#10b981',
    size: 2.3,
    operator: 'NOAA / NASA',
    country: 'USA',
    launchDate: '2016-11-19',
  },
];

/**
 * Optical Ground Stations for Enclave Telemetry Uplink
 */
export const GROUND_STATIONS = [
  {
    id: 'gs-svalbard',
    name: 'Svalbard Satellite Station (SvalSat)',
    lat: 78.23,
    lon: 15.4,
    country: 'Norway',
    frequency: 'Optical Laser 1550nm / X-Band',
    elevationM: 450,
    opticalUplinkActive: true,
  },
  {
    id: 'gs-hawaii',
    name: 'Haleakala Optical Station',
    lat: 20.71,
    lon: -156.26,
    country: 'USA (Hawaii)',
    frequency: 'Deep Space Optical Comm (DSOC)',
    elevationM: 3055,
    opticalUplinkActive: true,
  },
  {
    id: 'gs-hartbeeshoek',
    name: 'HartRAO Space Geodesy',
    lat: -25.88,
    lon: 27.71,
    country: 'South Africa',
    frequency: 'Satellite Laser Ranging (SLR)',
    elevationM: 1415,
    opticalUplinkActive: true,
  },
  {
    id: 'gs-madrid',
    name: 'Robledo de Chavela DSN',
    lat: 40.43,
    lon: -4.25,
    country: 'Spain',
    frequency: 'Deep Space Network / Ka-Band',
    elevationM: 780,
    opticalUplinkActive: true,
  },
  {
    id: 'gs-canberra',
    name: 'Tidbinbilla DSN Complex',
    lat: -35.4,
    lon: 148.98,
    country: 'Australia',
    frequency: 'Deep Space Network / Optical',
    elevationM: 650,
    opticalUplinkActive: true,
  },
];

/**
 * Live ISS Ephemeris Fetcher with graceful fallback to analytical propagation.
 */
export async function fetchLiveIssEphemeris(): Promise<{
  latitude: number;
  longitude: number;
  altitudeKm: number;
  velocityKmh: number;
  visibility: string;
  timestamp: number;
  isLive: boolean;
}> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const res = await fetch('https://api.wheretheiss.at/v1/satellites/25544', {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (!res.ok) {
      throw new Error(`HTTP error ${res.status}`);
    }

    const data = await res.json();
    return {
      latitude: data.latitude,
      longitude: data.longitude,
      altitudeKm: data.altitude,
      velocityKmh: data.velocity,
      visibility: data.visibility || 'daylight',
      timestamp: data.timestamp * 1000,
      isLive: true,
    };
  } catch {
    // Fallback gracefully to high-precision SGP4/Keplerian simulation
    const issAsset = SEED_CATALOG.find((a) => a.noradId === 25544)!;
    const nowSec = Date.now() / 1000;
    const prop = propagateKeplerian(issAsset, nowSec);
    return {
      latitude: prop.geodetic.latitude,
      longitude: prop.geodetic.longitude,
      altitudeKm: prop.geodetic.altitudeKm,
      velocityKmh: prop.velocityKms * 3600,
      visibility: 'simulated',
      timestamp: Date.now(),
      isLive: false,
    };
  }
}
