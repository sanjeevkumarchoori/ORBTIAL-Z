import React, { useState, useEffect, useCallback } from 'react';
import { Earth3DScene, SceneToggles, CameraPreset } from './components/Earth3D/Earth3DScene';
import { Header } from './components/UI/Header';
import { HeroHUD } from './components/UI/HeroHUD';
import { ConjunctionCard } from './components/UI/ConjunctionCard';
import { ControlConsole } from './components/UI/ControlConsole';
import { ZkProofModal } from './components/UI/ZkProofModal';
import { CdmModal } from './components/UI/CdmModal';
import { CatalogDrawer } from './components/UI/CatalogDrawer';
import { AssetDetailModal } from './components/UI/AssetDetailModal';
import { MissionLogModal } from './components/UI/MissionLogModal';
import { SpatialRiskPanel } from './components/UI/SpatialRiskPanel';
import { AtmosphericDragPanel } from './components/UI/AtmosphericDragPanel';
import { BPlaneVisualizerModal } from './components/UI/BPlaneVisualizerModal';
import { fetchLiveIssEphemeris, SEED_CATALOG } from './services/propagator';
import { INITIAL_MISSION_LOGS, createNewScreeningLog } from './services/missionLogService';
import {
  SEED_REENTRY_WATCHLIST,
  stepOrbitalDecay,
  ReentryWatchItem,
} from './services/atmosphericDrag';
import { ConjunctionCorridor } from './components/Earth3D/SpatialRiskHeatmap';
import { OrbitalAsset, GeodeticCoords } from './types/orbital';
import { MissionLogEntry } from './types/missionLog';

export default function App() {
  // Scene Toggles
  const [toggles, setToggles] = useState<SceneToggles>({
    showOrbits: true,
    showDebris: true,
    showRiskHeatmap: true,
    showLaserLinks: true,
    showDayNight: true,
    showGroundStations: true,
    showAtmosphere: true,
  });

  // Viewport camera preset & time speed
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('GLOBAL');
  const [timeSpeed, setTimeSpeed] = useState<number>(1);

  // Atmospheric Drag & Solar Flux State
  const [solarFlux, setSolarFlux] = useState<number>(155);
  const [enableDrag, setEnableDrag] = useState<boolean>(true);
  const [reentryCount, setReentryCount] = useState<number>(0);
  const [reentryWatchlist, setReentryWatchlist] = useState<ReentryWatchItem[]>(SEED_REENTRY_WATCHLIST);

  // Selected asset
  const [selectedAsset, setSelectedAsset] = useState<OrbitalAsset | null>(null);

  // Modals state
  const [isZkProofOpen, setIsZkProofOpen] = useState(false);
  const [isCdmOpen, setIsCdmOpen] = useState(false);
  const [isCatalogOpen, setIsCatalogOpen] = useState(false);
  const [isMissionLogOpen, setIsMissionLogOpen] = useState(false);
  const [isRiskPanelOpen, setIsRiskPanelOpen] = useState(false);
  const [isDragPanelOpen, setIsDragPanelOpen] = useState(false);
  const [isBPlaneOpen, setIsBPlaneOpen] = useState(false);

  // Timeline scrubber offset (T ± 72 hours) & Space weather
  const [simulatedHoursOffset, setSimulatedHoursOffset] = useState<number>(0);
  const [geomagneticKp, setGeomagneticKp] = useState<number>(3.2);

  // Mission Logs state
  const [missionLogs, setMissionLogs] = useState<MissionLogEntry[]>(INITIAL_MISSION_LOGS);

  // Live ISS coordinates (initially standard LEO)
  const [issCoords, setIssCoords] = useState<GeodeticCoords>({
    latitude: 51.64,
    longitude: -0.12,
    altitudeKm: 418.0,
  });
  const [sunAngleDeg, setSunAngleDeg] = useState(45.0);

  // Notification Banner
  const [toastMessage, setToastMessage] = useState<string | null>(
    'IBM z16 CPACF Enclave: Ingested 48,210 ephemeris vectors into hardware memory enclave'
  );

  // Periodically fetch live ISS ephemeris from wheretheiss.at
  useEffect(() => {
    let isMounted = true;
    const fetchIss = async () => {
      try {
        const live = await fetchLiveIssEphemeris();
        if (isMounted) {
          setIssCoords({
            latitude: live.latitude,
            longitude: live.longitude,
            altitudeKm: live.altitudeKm,
          });
        }
      } catch {
        // Handled silently with analytical propagation
      }
    };

    fetchIss();
    const interval = setInterval(fetchIss, 5000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // Periodic atmospheric drag decay simulation for monitored watchlist
  useEffect(() => {
    if (!enableDrag) return;

    const decayInterval = setInterval(() => {
      setReentryWatchlist((prevList) => {
        return prevList.map((item) => {
          // Accelerated visual simulation dt (10 minutes per tick scaled by timeSpeed)
          const dtSeconds = 600 * Math.max(1, timeSpeed);
          const decayResult = stepOrbitalDecay(
            item.altitudeKm,
            item.ballisticCoeff,
            dtSeconds,
            solarFlux,
            item.status === 'STATION_KEEPING'
          );

          let newStatus = item.status;
          if (decayResult.isReentered) {
            newStatus = 'BURNING';
          } else if (decayResult.decayRateMetersPerDay > 500 && item.status !== 'STATION_KEEPING') {
            newStatus = 'CRITICAL_DECAY';
          }

          // Recalculate days to reentry
          const altRemainingMeters = Math.max(0, (decayResult.newAltitudeKm - 105) * 1000);
          const daysEst = Math.max(1, altRemainingMeters / Math.max(1, decayResult.decayRateMetersPerDay));

          return {
            ...item,
            altitudeKm: decayResult.newAltitudeKm,
            decayRateMetersPerDay: decayResult.decayRateMetersPerDay,
            estimatedDaysToReentry: daysEst,
            status: newStatus,
          };
        });
      });
    }, 1500);

    return () => clearInterval(decayInterval);
  }, [enableDrag, solarFlux, timeSpeed]);

  // Dismiss toast after 7s
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 7000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const handleTelemetryTick = useCallback(
    (telemetry: {
      issCoords: GeodeticCoords;
      conjunctionMissMeters: number;
      sunAngleDeg: number;
      simulatedUtc: string;
    }) => {
      setSunAngleDeg(telemetry.sunAngleDeg);
    },
    []
  );

  const focusConjunction = () => {
    setCameraPreset('CONJUNCTION');
    setToastMessage('Camera locked onto Conjunction Ellipsoid: Asset #4092 vs #8921 (T-00:14:22)');
  };

  const triggerGlobalScreening = () => {
    const newLog = createNewScreeningLog('All Monitored Assets (Global Pairwise Sweep)');
    setMissionLogs((prev) => [newLog, ...prev]);
    setToastMessage('Triggered on-demand pairwise screening inside IBM z16 enclave: 0 collisions detected.');
  };

  const handleScreenConjunction = (asset: OrbitalAsset) => {
    const newLog = createNewScreeningLog(asset.name);
    setMissionLogs((prev) => [newLog, ...prev]);
    setToastMessage(`Hardware Enclave: Screening Asset ${asset.name} against entire 48,210 catalog... 0 collisions detected.`);
  };

  const handleTriggerReboost = (item: ReentryWatchItem) => {
    setReentryWatchlist((prev) =>
      prev.map((i) =>
        i.id === item.id
          ? {
              ...i,
              altitudeKm: i.id === 'iss-active' ? 418.5 : 531.0,
              status: 'STATION_KEEPING',
            }
          : i
      )
    );
    setToastMessage(`Autonomous Station-Keeping: Fired micro-thrust burn on ${item.name} (+400m altitude restored).`);
  };

  const handleResetAltitudes = () => {
    setReentryWatchlist(SEED_REENTRY_WATCHLIST);
    setToastMessage('Orbital decay state reset to initial catalog values.');
  };

  const handleFocusAsset = (asset: OrbitalAsset) => {
    if (asset.noradId === 25544) {
      setCameraPreset('ISS');
    } else if (asset.id.includes('4092') || asset.id.includes('8921')) {
      setCameraPreset('CONJUNCTION');
    } else if (asset.orbitClass === 'GEO') {
      setCameraPreset('GEO');
    } else if (asset.orbitClass === 'POLAR') {
      setCameraPreset('POLAR');
    } else {
      setCameraPreset('GLOBAL');
    }
    setToastMessage(`Camera tracking targeted asset: ${asset.name}`);
  };

  const handleCommitAvoidanceBurn = (summary: string) => {
    const newLog: MissionLogEntry = {
      id: `log-burn-${Date.now()}`,
      timestampUtc: new Date().toISOString(),
      category: 'CONJUNCTION',
      severity: 'RESOLVED',
      title: 'Autonomous Avoidance Burn Dispatched: Asset #4092 vs #8921',
      description: summary,
      details: {
        assetName: 'Asset #4092 (Sovereign Recon)',
        noradId: 40920,
        enclaveExecutionTimeMs: 0.88,
        zkProofHash: '0x3a9f82d1c98e104b90aef8410293847a19283740',
        ephemerisExposureBytes: 0,
        avoidanceVectorDeltaV: '+0.45 m/s (Optimal Multi-Axis)',
      },
    };
    setMissionLogs((prev) => [newLog, ...prev]);
    setToastMessage(`Hardware Enclave: Avoidance burn committed. Conjunction Pc dropped to < 1e-7.`);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#030305] text-slate-100 font-sans">
      {/* 3D WebGL Three.js Earth Scene Viewport */}
      <Earth3DScene
        toggles={toggles}
        cameraPreset={cameraPreset}
        timeSpeed={timeSpeed}
        solarFlux={solarFlux}
        enableDrag={enableDrag}
        selectedAsset={selectedAsset}
        onSelectAsset={setSelectedAsset}
        onReentryTick={setReentryCount}
        onTelemetryTick={handleTelemetryTick}
      />

      {/* Top Global Navigation Bar */}
      <Header
        onOpenZkProof={() => setIsZkProofOpen(true)}
        onOpenCdm={() => setIsCdmOpen(true)}
        onOpenCatalog={() => setIsCatalogOpen(true)}
        onOpenMissionLog={() => setIsMissionLogOpen(true)}
        onOpenBPlane={() => setIsBPlaneOpen(true)}
        logCount={missionLogs.length}
      />

      {/* Mission Critical Overview HUD (Collapsible) */}
      <HeroHUD onFocusConjunction={focusConjunction} />

      {/* Floating Emergency Conjunction Incident Card */}
      <ConjunctionCard
        onInspectProof={() => setIsZkProofOpen(true)}
        onFocusConjunction={focusConjunction}
        onOpenBPlane={() => setIsBPlaneOpen(true)}
      />

      {/* Ephemeral Enclave Notification Toast */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-30 max-w-lg px-4 py-2 rounded-full border border-violet-500/40 bg-violet-950/80 text-violet-200 text-xs font-mono shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-violet-400" />
            <span className="truncate">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Bottom Floating Control Console Dock */}
      <ControlConsole
        toggles={toggles}
        onUpdateToggles={setToggles}
        cameraPreset={cameraPreset}
        onSelectPreset={setCameraPreset}
        timeSpeed={timeSpeed}
        onSetTimeSpeed={setTimeSpeed}
        simulatedHoursOffset={simulatedHoursOffset}
        onSetSimulatedHoursOffset={setSimulatedHoursOffset}
        issTelemetry={issCoords}
        sunAngleDeg={sunAngleDeg}
        onOpenRiskPanel={() => setIsRiskPanelOpen(true)}
        onOpenDragPanel={() => setIsDragPanelOpen(true)}
        onOpenBPlane={() => setIsBPlaneOpen(true)}
        solarFlux={solarFlux}
        geomagneticKp={geomagneticKp}
        reentryCount={reentryCount}
      />

      {/* Interactive Modals & Drawers */}
      <AtmosphericDragPanel
        isOpen={isDragPanelOpen}
        onClose={() => setIsDragPanelOpen(false)}
        solarFlux={solarFlux}
        onSetSolarFlux={setSolarFlux}
        enableDrag={enableDrag}
        onToggleDrag={() => setEnableDrag(!enableDrag)}
        reentryCount={reentryCount}
        watchlist={reentryWatchlist}
        onTriggerReboost={handleTriggerReboost}
        onResetAltitudes={handleResetAltitudes}
      />
      <SpatialRiskPanel
        isOpen={isRiskPanelOpen}
        onClose={() => setIsRiskPanelOpen(false)}
        onSelectCorridor={(corridor) => {
          setToastMessage(`Spatial Corridor Monitored: ${corridor.name} (Risk Score: ${corridor.densityScore}/100)`);
        }}
      />
      <MissionLogModal
        isOpen={isMissionLogOpen}
        onClose={() => setIsMissionLogOpen(false)}
        logs={missionLogs}
        onTriggerScreening={triggerGlobalScreening}
      />
      <BPlaneVisualizerModal
        isOpen={isBPlaneOpen}
        onClose={() => setIsBPlaneOpen(false)}
        onCommitManeuver={handleCommitAvoidanceBurn}
      />
      <ZkProofModal isOpen={isZkProofOpen} onClose={() => setIsZkProofOpen(false)} />
      <CdmModal isOpen={isCdmOpen} onClose={() => setIsCdmOpen(false)} />
      <CatalogDrawer
        isOpen={isCatalogOpen}
        onClose={() => setIsCatalogOpen(false)}
        onSelectAsset={(asset) => {
          setSelectedAsset(asset);
          handleFocusAsset(asset);
        }}
      />
      <AssetDetailModal
        asset={selectedAsset}
        onClose={() => setSelectedAsset(null)}
        onFocusAsset={handleFocusAsset}
        onScreenConjunction={handleScreenConjunction}
      />
    </div>
  );
}
