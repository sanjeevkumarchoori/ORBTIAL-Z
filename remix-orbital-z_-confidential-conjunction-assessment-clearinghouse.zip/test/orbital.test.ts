import test from 'node:test';
import assert from 'node:assert/strict';
import { solveKepler, propagateKeplerian, SEED_CATALOG, EARTH_RADIUS_KM } from '../src/services/propagator.ts';
import { parseCdmText, calculateConjunctionRisk, SAMPLE_CDM_RAW } from '../src/services/cdmParser.ts';
import { generateEnclaveAttestation } from '../src/services/zkEnclave.ts';

test('solveKepler solves mean to eccentric anomaly', () => {
  const e = 0.05;
  const M = 1.2;
  const E = solveKepler(M, e);
  const diff = Math.abs(E - e * Math.sin(E) - M);
  assert.ok(diff < 1e-5, `Kepler residual must be < 1e-5, got ${diff}`);
});

test('propagateKeplerian returns valid ECI and geodetic coords', () => {
  const iss = SEED_CATALOG.find((a) => a.noradId === 25544)!;
  const result = propagateKeplerian(iss, 0);

  // ISS velocity in LEO should be approximately 7.6 km/s
  assert.ok(result.velocityKms > 7.0 && result.velocityKms < 8.0, `ISS velocity should be ~7.6 km/s, got ${result.velocityKms}`);
  
  // Geodetic altitude should be approximately 418 km
  assert.ok(result.geodetic.altitudeKm > 350 && result.geodetic.altitudeKm < 500, `Altitude should be in LEO range, got ${result.geodetic.altitudeKm}`);
  
  // Latitude must be within [-90, 90]
  assert.ok(result.geodetic.latitude >= -90 && result.geodetic.latitude <= 90);
  // Longitude must be within [-180, 180]
  assert.ok(result.geodetic.longitude >= -180 && result.geodetic.longitude <= 180);
});

test('parseCdmText accurately extracts CCSDS CDM parameters', () => {
  const parsed = parseCdmText(SAMPLE_CDM_RAW);
  assert.equal(parsed.primaryObject.catalogId, 40920);
  assert.equal(parsed.secondaryObject.catalogId, 58921);
  assert.equal(parsed.missDistanceM, 410.2);
  assert.equal(parsed.collisionProbability, 1.842e-3);
  assert.ok(parsed.relativeSpeedKms > 10.0, 'Relative speed in LEO collision should be > 10 km/s');
});

test('calculateConjunctionRisk computes Mahalanobis distance & collision probability', () => {
  const risk = calculateConjunctionRisk(
    410.2,
    { r: 18.4, t: 42.1, n: 8.2 },
    { r: 24.2, t: 65.8, n: 11.5 }
  );

  assert.ok(risk.mahalanobis > 0);
  assert.ok(risk.pc > 0 && risk.pc <= 1.0);
});

test('generateEnclaveAttestation generates valid s390x proof metadata', () => {
  const attestation = generateEnclaveAttestation({ id: 'test-event' });
  assert.equal(attestation.ephemerisLeakageBytes, 0);
  assert.ok(attestation.platform.includes('IBM z16'));
  assert.ok(attestation.proofSnark.pi_a.length === 2);
  assert.ok(attestation.proofSnark.pi_b.length === 2);
  assert.ok(attestation.proofSnark.pi_c.length === 2);
});

test('missionLogService has initial logs across conjunction, enclave, and screening', async () => {
  const { INITIAL_MISSION_LOGS, createNewScreeningLog } = await import('../src/services/missionLogService.ts');
  assert.ok(INITIAL_MISSION_LOGS.length >= 8);
  
  const categories = new Set(INITIAL_MISSION_LOGS.map((l) => l.category));
  assert.ok(categories.has('CONJUNCTION'));
  assert.ok(categories.has('ENCLAVE'));
  assert.ok(categories.has('SCREENING'));

  const dynamicLog = createNewScreeningLog('Test Satellite');
  assert.equal(dynamicLog.category, 'SCREENING');
  assert.ok(dynamicLog.title.includes('Test Satellite'));
  assert.ok(dynamicLog.details?.zkProofHash);
});

test('spatial risk corridors contain critical altitude zones', async () => {
  const { CORRIDORS } = await import('../src/components/Earth3D/SpatialRiskHeatmap.ts');
  assert.ok(CORRIDORS.length >= 4);
  const critical = CORRIDORS.filter((c) => c.riskLevel === 'CRITICAL');
  assert.ok(critical.length >= 2, 'Must have at least 2 critical corridors');
  const altitudes = CORRIDORS.map((c) => c.altitudeKm);
  assert.ok(altitudes.includes(530), 'Must include Starlink 530km shell');
  assert.ok(altitudes.includes(790), 'Must include Cosmos 790km shell');
});

test('atmospheric drag physics computes exponential density and solar flux scaling', async () => {
  const { calculateAtmosphericDensity, circularVelocityKms, stepOrbitalDecay } = await import('../src/services/atmosphericDrag.ts');

  // Density decreases with altitude
  const rho300 = calculateAtmosphericDensity(300, 150);
  const rho500 = calculateAtmosphericDensity(500, 150);
  assert.ok(rho300 > rho500, `Density at 300km (${rho300}) must exceed 500km (${rho500})`);

  // Solar maximum expands thermosphere, increasing density
  const rhoLowSolar = calculateAtmosphericDensity(400, 70);
  const rhoHighSolar = calculateAtmosphericDensity(400, 240);
  assert.ok(rhoHighSolar > rhoLowSolar, 'Higher solar flux must increase thermospheric density');

  // Circular velocity: lower orbits travel faster
  const v300 = circularVelocityKms(300);
  const v800 = circularVelocityKms(800);
  assert.ok(v300 > v800, 'Orbital speed at 300km must be higher than at 800km');
  assert.ok(v300 > 7.5 && v300 < 8.0, 'LEO speed should be ~7.7 km/s');

  // Decay step reduces altitude for debris
  const result = stepOrbitalDecay(350, 0.08, 86400, 155, false);
  assert.ok(result.newAltitudeKm < 350, 'Altitude must decrease after decay step');
  assert.ok(result.decayRateMetersPerDay > 0, 'Decay rate must be positive');
  assert.ok(result.newVelocityKms > circularVelocityKms(350), 'Velocity must increase as altitude decays');
});

test('B-Plane encounter geometry and covariance ellipse eigenvalues', async () => {
  const { calculateBPlaneEncounter, calculate2DGaussianPc } = await import('../src/services/bPlaneService.ts');
  const encounter = calculateBPlaneEncounter();

  assert.equal(encounter.primaryId, 4092);
  assert.equal(encounter.secondaryId, 8921);
  assert.ok(encounter.initialMissDistanceM > 400 && encounter.initialMissDistanceM < 420);
  assert.equal(encounter.relativeVelocityKms, 14.2);
  assert.ok(encounter.combinedCovariance.sigmaMajor > encounter.combinedCovariance.sigmaMinor);
  assert.ok(encounter.ellipses.sigma1.semiMajorM < encounter.ellipses.sigma2.semiMajorM);
  assert.ok(encounter.ellipses.sigma2.semiMajorM < encounter.ellipses.sigma3.semiMajorM);

  // Initial Pc should be on order of 10^-3
  assert.ok(encounter.initialPc > 1e-4 && encounter.initialPc < 1e-2);

  // Test 2D Gaussian Pc integration
  const pcTest = calculate2DGaussianPc(285.4, -294.6, 6100, 920, 460, 5.0);
  assert.ok(pcTest > 0 && pcTest < 0.1);
});

test('Maneuver Trade-Space calculates fuel penalty and drops Pc below threshold', async () => {
  const { simulateAvoidanceManeuver, calculateHydrazinePenalty } = await import('../src/services/bPlaneService.ts');
  
  // Hydrazine penalty test
  const fuel05 = calculateHydrazinePenalty(0.5);
  assert.ok(fuel05 > 0.1 && fuel05 < 0.3, `0.5 m/s burn should consume ~0.16kg hydrazine, got ${fuel05}`);

  // Simulate 0.45 m/s optimal enclave maneuver
  const maneuver = simulateAvoidanceManeuver(0.45, 'OPTIMAL_ENCLAVE', 1.5);
  assert.ok(maneuver.postMissDistanceM > 3000, `Post-burn miss distance should exceed 3,000m, got ${maneuver.postMissDistanceM}`);
  assert.ok(maneuver.postPc < 1e-6, `Post-burn Pc must drop below 1e-6, got ${maneuver.postPc}`);
  assert.equal(maneuver.secondaryConjunctions72h, 0);
  assert.equal(maneuver.isEnclaveVerified, true);
});

test('IBM z16 PCR registers and client-side proof verifier', async () => {
  const { generateEnclaveAttestation, verifyProofClientSide } = await import('../src/services/zkEnclave.ts');
  const attestation = generateEnclaveAttestation({ id: 'test-conjunction' });

  // 8 Platform Configuration Registers PCR0-PCR7
  assert.equal(Object.keys(attestation.pcrRegisters).length, 8);
  assert.ok(attestation.pcrRegisters.PCR0.startsWith('0x'));
  assert.ok(attestation.pcrRegisters.PCR7.startsWith('0x'));

  // Post-quantum signature presence
  assert.ok(attestation.postQuantum.mlKem1024Ciphertext.startsWith('0x'));
  assert.ok(attestation.postQuantum.mlDsa87Signature.startsWith('0x'));

  // Client verification
  const verification = verifyProofClientSide(attestation);
  assert.equal(verification.isValid, true);
  assert.equal(verification.snarkPairingValid, true);
  assert.equal(verification.pcrIntegrityVerified, true);
  assert.equal(verification.postQuantumSignatureValid, true);
  assert.equal(verification.ephemerisLeakageBytes, 0);
});

test('generate72hPcEvolution models 72h prediction curve and identifies moment of maximum risk at TCA', async () => {
  const { generate72hPcEvolution } = await import('../src/services/bPlaneService.ts');
  const evo = generate72hPcEvolution();

  assert.ok(evo.points.length >= 25);
  assert.equal(evo.maxRiskPoint.hoursOffset, 0);
  assert.equal(evo.maxRiskPoint.isMaximumRisk, true);
  assert.equal(evo.maxRiskPoint.riskLevel, 'CRITICAL');
  assert.ok(evo.maxRiskPoint.pc > 1e-3, `Peak Pc should be ~1.84e-3, got ${evo.maxRiskPoint.pc}`);

  // Background risk far from TCA should be negligible
  const p72hBefore = evo.points.find((p) => p.hoursOffset === -72)!;
  assert.ok(p72hBefore.pc < 1e-6);
  assert.equal(p72hBefore.riskLevel, 'NEGLIGIBLE');

  // Verify curve increases monotonically towards TCA from both sides
  const p24h = evo.points.find((p) => p.hoursOffset === -24)!;
  const p6h = evo.points.find((p) => p.hoursOffset === -6)!;
  const p1h = evo.points.find((p) => p.hoursOffset === -1.5 || p.hoursOffset === -1)!;
  assert.ok(p6h.pc > p24h.pc);
  if (p1h) {
    assert.ok(p1h.pc > p6h.pc);
  }
});


